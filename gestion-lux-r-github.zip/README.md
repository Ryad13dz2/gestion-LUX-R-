# Gestion.LUX-R - Application de Gestion

Ce projet est une application web Next.js qui propose des fonctionnalités de gestion pour la banque et la bibliothèque, avec intégration de l'IA via Gemini API.

## Fonctionnalités

### Module Banque
- Consultation des comptes
- Historique des transactions
- Analyse budgétaire
- Gestion des cartes
- Initiation de virements
- Traitement des retraits
- Enregistrement des dépôts
- Génération de relevés
- Suivi des prêts
- Alertes de sécurité
- Rapports d'audit
- Convertisseur de devises

### Module Bibliothèque
- Gestion des livres (ajout, modification, suppression)
- Gestion des emprunts
- Gestion des lecteurs
- Statistiques
- Paramètres

## Technologies utilisées

- **Frontend**: Next.js 15, React 18, TypeScript
- **UI**: Tailwind CSS, Radix UI
- **IA**: Gemini API via Genkit
- **Stockage local**: LocalStorage pour la persistance des données
- **Graphiques**: Recharts pour les visualisations de données

## Prérequis

- Node.js 18+ 
- npm ou yarn

## Installation

1. Clonez ce dépôt
   ```bash
   git clone https://github.com/votre-nom/gestion-lux-r.git
   cd gestion-lux-r
   ```

2. Installez les dépendances
   ```bash
   npm install
   # ou
   yarn install
   ```

3. Créez un fichier `.env` à la racine du projet avec votre clé API Gemini
   ```
   GEMINI_API_KEY=votre_clé_api_gemini
   ```

4. Lancez le serveur de développement
   ```bash
   npm run dev
   # ou
   yarn dev
   ```

5. Ouvrez [http://localhost:9002](http://localhost:9002) dans votre navigateur

## Construction pour la production

```bash
npm run build
# ou
yarn build
```

## Déploiement

Cette application peut être déployée sur des plateformes compatibles avec Next.js comme Vercel ou Netlify.

### Déploiement sur Vercel

1. Créez un compte sur [Vercel](https://vercel.com)
2. Connectez votre dépôt GitHub
3. Configurez la variable d'environnement `GEMINI_API_KEY`
4. Déployez

### Déploiement sur Netlify

1. Créez un compte sur [Netlify](https://netlify.com)
2. Connectez votre dépôt GitHub
3. Configurez la commande de build: `npm run build`
4. Configurez le répertoire de publication: `.next`
5. Configurez la variable d'environnement `GEMINI_API_KEY`
6. Déployez

## Structure du projet

```
/
├── .next/               # Fichiers compilés (générés)
├── docs/                # Documentation
├── node_modules/        # Dépendances (générées)
├── public/              # Fichiers statiques
├── src/
│   ├── ai/              # Intégration Gemini API
│   ├── app/             # Pages et routes Next.js
│   │   ├── banque/      # Module de gestion bancaire
│   │   └── bibliotheque/# Module de gestion de bibliothèque
│   ├── components/      # Composants React réutilisables
│   ├── contexts/        # Contextes React
│   ├── hooks/           # Hooks personnalisés
│   └── lib/             # Utilitaires et fonctions
├── .env                 # Variables d'environnement
├── .gitignore           # Fichiers ignorés par Git
├── next.config.ts       # Configuration Next.js
├── package.json         # Dépendances et scripts
├── postcss.config.mjs   # Configuration PostCSS
├── tailwind.config.ts   # Configuration Tailwind CSS
└── tsconfig.json        # Configuration TypeScript
```

## Contribution

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir une issue ou à soumettre une pull request.

## Licence

Ce projet est sous licence [MIT](LICENSE).
