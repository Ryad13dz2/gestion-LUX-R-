
'use client';

import type { PropsWithChildren} from 'react';
import React, { createContext, useContext, useState, useCallback } from 'react';

export interface Notification {
  id: string;
  title: string;
  description: string;
  timestamp: Date;
  read: boolean; 
}

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (title: string, description: string) => void;
  unreadCount: number;
  // clearAllNotifications: () => void; // Future
  // markNotificationAsRead: (id: string) => void; // Future
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<PropsWithChildren> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: 'init1', title: 'Bienvenue dans LUX-R Biblio!', description: 'Ceci est une notification initiale.', timestamp: new Date(Date.now() - 86400000 * 1), read: true },
    { id: 'init2', title: 'Système de notification actif', description: 'Vous recevrez des mises à jour ici.', timestamp: new Date(Date.now() - 86400000 * 0.5), read: true },
  ]);

  const addNotification = useCallback((title: string, description: string) => {
    const newNotification: Notification = {
      id: Date.now().toString(),
      title,
      description,
      timestamp: new Date(),
      read: false, // Nouvelles notifications sont non lues
    };
    // Ajoute la nouvelle notification au début et garde les 20 dernières.
    setNotifications(prev => [newNotification, ...prev.slice(0, 19)]); 
  }, []);

  // Calcule le nombre de notifications non lues
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider value={{ notifications, addNotification, unreadCount }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
