
"use client";
import * as React from 'react';
import type { PropsWithChildren} from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarFooter, SidebarProvider } from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Bell, Book, Users, ArrowRightLeft, BarChart3, Settings, UserCircle, LogOut, LayoutDashboard, ArrowLeft, Search, Edit2, ShieldCheck, Save, UploadCloud } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { useNotifications, type Notification } from '@/contexts/NotificationContext';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const LOCAL_STORAGE_PROFILE_USERNAME_KEY = 'luxr_profile_username';
const LOCAL_STORAGE_PROFILE_EMAIL_KEY = 'luxr_profile_email';
const LOCAL_STORAGE_PROFILE_ROLE_KEY = 'luxr_profile_role';
const LOCAL_STORAGE_PROFILE_PHOTO_KEY = 'luxr_profile_photo';

export default function BibliothequeLayout({ children }: PropsWithChildren) {
  const pathname = usePathname();
  const { notifications, unreadCount, addNotification } = useNotifications();
  const { toast } = useToast();
  const [isClient, setIsClient] = React.useState(false);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = React.useState(false);

  const defaultUsername = "Bibliothécaire Principal";
  const defaultEmail = "admin@example.com";
  const defaultRole = "Administrateur";
  const defaultPhotoUrl = `https://placehold.co/100x100.png?text=${defaultUsername.substring(0,1)}${defaultUsername.split(' ')[1]?.[0] || ''}`;

  const [profileUsername, setProfileUsername] = React.useState(defaultUsername);
  const [profileEmail, setProfileEmail] = React.useState(defaultEmail);
  const [profileRole, setProfileRole] = React.useState(defaultRole);
  const [profilePhotoUrl, setProfilePhotoUrl] = React.useState<string | undefined>(undefined);

  const [tempProfileUsername, setTempProfileUsername] = React.useState(profileUsername);
  const [tempProfileEmail, setTempProfileEmail] = React.useState(profileEmail);
  const [tempProfileRole, setTempProfileRole] = React.useState(profileRole);
  const [tempProfilePhotoUrl, setTempProfilePhotoUrl] = React.useState<string | undefined>(profilePhotoUrl);

  React.useEffect(() => {
    setIsClient(true);
    try {
      const storedUsername = localStorage.getItem(LOCAL_STORAGE_PROFILE_USERNAME_KEY);
      if (storedUsername) {
        setProfileUsername(storedUsername);
        setTempProfileUsername(storedUsername); // Initialize temp state
      }
      const storedEmail = localStorage.getItem(LOCAL_STORAGE_PROFILE_EMAIL_KEY);
      if (storedEmail) {
        setProfileEmail(storedEmail);
        setTempProfileEmail(storedEmail); // Initialize temp state
      }
      const storedRole = localStorage.getItem(LOCAL_STORAGE_PROFILE_ROLE_KEY);
      if (storedRole) {
        setProfileRole(storedRole);
        setTempProfileRole(storedRole); // Initialize temp state
      } else {
        localStorage.setItem(LOCAL_STORAGE_PROFILE_ROLE_KEY, defaultRole); // Save default if not present
        setTempProfileRole(defaultRole);
      }
      const storedPhoto = localStorage.getItem(LOCAL_STORAGE_PROFILE_PHOTO_KEY);
      if (storedPhoto) {
        setProfilePhotoUrl(storedPhoto);
        setTempProfilePhotoUrl(storedPhoto); // Initialize temp state
      }

    } catch (error) {
      console.error("Erreur de chargement du profil depuis localStorage:", error);
      toast({
        title: "Erreur de Profil",
        description: "Impossible de charger les informations du profil localement.",
        variant: "destructive",
      });
    }
  }, [toast]);

  const handleGenericProfileOptionClick = (option: string) => {
    toast({
      title: "Fonctionnalité de Profil",
      description: `${option} n'est pas encore implémenté.`,
    });
  };
  
  const handleOpenProfileDialog = () => {
    // Ensure temp states are synced with current profile states when opening
    setTempProfileUsername(profileUsername);
    setTempProfileEmail(profileEmail);
    setTempProfileRole(profileRole);
    setTempProfilePhotoUrl(profilePhotoUrl);
    setIsProfileDialogOpen(true);
  };

  const handleProfilePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempProfilePhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProfileSave = () => {
    if (!tempProfileUsername.trim() || !tempProfileEmail.trim()) {
      toast({
        title: "Champs Requis",
        description: "Le nom d'utilisateur et l'email ne peuvent pas être vides.",
        variant: "destructive",
      });
      return;
    }
    try {
      localStorage.setItem(LOCAL_STORAGE_PROFILE_USERNAME_KEY, tempProfileUsername);
      localStorage.setItem(LOCAL_STORAGE_PROFILE_EMAIL_KEY, tempProfileEmail);
      localStorage.setItem(LOCAL_STORAGE_PROFILE_ROLE_KEY, tempProfileRole);
      if (tempProfilePhotoUrl) {
        localStorage.setItem(LOCAL_STORAGE_PROFILE_PHOTO_KEY, tempProfilePhotoUrl);
      } else {
        localStorage.removeItem(LOCAL_STORAGE_PROFILE_PHOTO_KEY);
      }

      setProfileUsername(tempProfileUsername);
      setProfileEmail(tempProfileEmail);
      setProfileRole(tempProfileRole);
      setProfilePhotoUrl(tempProfilePhotoUrl);

      toast({
        title: "Profil Mis à Jour",
        description: "Vos informations de profil ont été sauvegardées localement.",
      });
      addNotification("Profil Mis à Jour", "Les informations du profil ont été modifiées.");
      setIsProfileDialogOpen(false);
    } catch (error) {
       console.error("Erreur de sauvegarde du profil dans localStorage:", error);
       toast({
        title: "Erreur de Sauvegarde",
        description: "Impossible de sauvegarder les modifications du profil. Vérifiez l'espace de stockage de votre navigateur.",
        variant: "destructive",
      });
    }
  };

  const handleCancelProfileEdit = () => {
    setIsProfileDialogOpen(false);
    // Reset temp values to actual profile values
    setTempProfileUsername(profileUsername);
    setTempProfileEmail(profileEmail);
    setTempProfileRole(profileRole);
    setTempProfilePhotoUrl(profilePhotoUrl);
  }

  const menuItems = [
    { href: '/bibliotheque', label: 'Accueil', icon: LayoutDashboard },
    { href: '/bibliotheque/livres', label: 'Livres', icon: Book },
    { href: '/bibliotheque/lecteurs', label: 'Lecteurs', icon: Users },
    { href: '/bibliotheque/emprunts', label: 'Emprunts/Retours', icon: ArrowRightLeft },
    { href: '/bibliotheque/statistiques', label: 'Statistiques', icon: BarChart3 },
    { href: '/bibliotheque/parametres', label: 'Paramètres', icon: Settings },
  ];

  return (
    <SidebarProvider>
      <div className={cn("flex min-h-screen w-full force-light-theme")}>
        <Sidebar side="left" variant="sidebar" collapsible="icon">
          <SidebarHeader className="p-4">
            <Link href="/bibliotheque" className="flex items-center gap-2">
              <Image src="https://placehold.co/40x40.png?text=LR" alt="LUX-R Biblio Logo" width={40} height={40} className="rounded-md" data-ai-hint="logo abstract"/>
              <h1 className="text-xl font-semibold text-primary group-data-[collapsible=icon]:hidden">LUX-R Biblio</h1>
            </Link>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    href={item.href}
                    isActive={pathname === item.href}
                    tooltip={item.label}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter className="mt-auto p-2">
             <SidebarMenu>
                <SidebarMenuItem>
                    <SidebarMenuButton href="/" tooltip="Quitter la Bibliothèque">
                        <LogOut className="h-5 w-5" />
                        <span>Quitter</span>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            </SidebarMenu>
          </SidebarFooter>
        </Sidebar>
        
        <div className="flex flex-1 flex-col">
          <header className="sticky top-0 z-10 flex h-16 items-center justify-between gap-4 border-b bg-card px-6 shadow-sm shrink-0">
            <div className="flex-1">
              <Link href="/" className="text-2xl font-bold text-foreground">LUX-R</Link>
            </div>
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative rounded-full">
                    <Bell className="h-5 w-5" />
                    {isClient && unreadCount > 0 && (
                      <span className="absolute top-0 right-0 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500 text-xs text-white items-center justify-center">
                          {unreadCount > 9 ? '9+' : unreadCount}
                        </span>
                      </span>
                    )}
                    <span className="sr-only">Notifications</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0">
                  <div className="p-3 font-medium border-b">Notifications ({notifications.length})</div>
                  <ScrollArea className="h-[300px]">
                    {notifications.length === 0 ? (
                      <p className="p-4 text-sm text-muted-foreground">Aucune nouvelle notification.</p>
                    ) : (
                      <ul className="divide-y">
                        {notifications.map((notif) => (
                          <li key={notif.id} className={cn("p-3 hover:bg-accent", !notif.read && "bg-primary/5")}>
                            <h4 className="text-sm font-semibold">{notif.title}</h4>
                            <p className="text-xs text-muted-foreground">{notif.description}</p>
                            <p className="text-xs text-muted-foreground/80 mt-1">
                              {isClient ? formatDistanceToNow(notif.timestamp, { addSuffix: true, locale: fr }) : '...'}
                            </p>
                          </li>
                        ))}
                      </ul>
                    )}
                  </ScrollArea>
                  {notifications.length > 0 && (
                    <div className="p-2 border-t">
                      <Button variant="link" size="sm" className="w-full" onClick={() => toast({title: "Action", description: "Voir toutes les notifications (à venir)"})}>
                        Voir toutes les notifications
                      </Button>
                    </div>
                  )}
                </PopoverContent>
              </Popover>

              <Popover>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full">
                        {isClient && profilePhotoUrl ? (
                            <Image src={profilePhotoUrl} alt="Photo de profil" width={24} height={24} className="rounded-full h-6 w-6 object-cover" data-ai-hint="person avatar"/>
                        ) : (
                            <UserCircle className="h-6 w-6" />
                        )}
                        <span className="sr-only">Profil utilisateur</span>
                    </Button>
                </PopoverTrigger>
                <PopoverContent className="w-56 p-0">
                   <div className="p-3 border-b">
                     <p className="text-sm font-medium">{isClient ? profileUsername : defaultUsername}</p>
                     <p className="text-xs text-muted-foreground">{isClient ? profileEmail : defaultEmail}</p>
                   </div>
                   <ul className="py-1">
                     <li>
                       <Button variant="ghost" className="w-full justify-start px-3 py-1.5 text-sm" onClick={handleOpenProfileDialog}>Mon Profil</Button>
                     </li>
                     <li>
                       <Button variant="ghost" className="w-full justify-start px-3 py-1.5 text-sm" onClick={() => handleGenericProfileOptionClick("Paramètres du Compte")}>Paramètres du Compte</Button>
                     </li>
                     <li>
                       <Button variant="ghost" className="w-full justify-start px-3 py-1.5 text-sm text-destructive hover:text-destructive" onClick={() => handleGenericProfileOptionClick("Déconnexion")}>Déconnexion</Button>
                     </li>
                   </ul>
                </PopoverContent>
              </Popover>
            </div>
          </header>
          
          <div className="flex-1 overflow-y-auto">
            {children}
          </div>

          <footer className="border-t p-4 text-center text-xs text-muted-foreground shrink-0">
            LUX-R Bibliothèque &copy; {new Date().getFullYear()}
          </footer>
        </div>
      </div>

      <Dialog 
        open={isProfileDialogOpen} 
        onOpenChange={(open) => {
          setIsProfileDialogOpen(open);
          if (!open) { // Reset temp values if dialog is closed without saving
            handleCancelProfileEdit();
          }
        }}
      >
        <DialogContent className="sm:max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center">
              <UserCircle className="mr-2 h-6 w-6" /> Mon Profil
            </DialogTitle>
            <DialogDescription>
              Modifiez vos informations de profil. Sauvegarde locale dans le navigateur.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="flex flex-col items-center space-y-2">
                <div className="relative w-24 h-24 rounded-full border border-border overflow-hidden bg-muted">
                <Image 
                    src={tempProfilePhotoUrl || defaultPhotoUrl} 
                    alt="Photo de profil" 
                    fill 
                    style={{objectFit: 'cover'}}
                    data-ai-hint="person avatar" 
                    onError={(e) => { e.currentTarget.src = defaultPhotoUrl; }}
                />
                </div>
                 <Input
                    id="profile-photo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleProfilePhotoChange}
                    className="text-sm file:mr-2 file:py-1 file:px-2 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                  />
                  <Label htmlFor="profile-photo-upload" className="sr-only">Changer la photo</Label>
            </div>
            <div className="space-y-1">
              <Label htmlFor="profile-username-edit">Nom d'utilisateur</Label>
              <Input 
                id="profile-username-edit" 
                value={tempProfileUsername} 
                onChange={(e) => setTempProfileUsername(e.target.value)}
                className="bg-background text-foreground border-border" 
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="profile-email-edit">Email</Label>
              <Input 
                id="profile-email-edit" 
                type="email"
                value={tempProfileEmail} 
                onChange={(e) => setTempProfileEmail(e.target.value)}
                className="bg-background text-foreground border-border"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="profile-role">Rôle</Label>
              <Input id="profile-role" value={tempProfileRole} disabled className="bg-muted/50" />
            </div>
            <Button variant="outline" className="w-full" disabled>
              <ShieldCheck className="mr-2 h-4 w-4" /> Changer le mot de passe (Bientôt)
            </Button>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={handleCancelProfileEdit}>Annuler</Button>
            <Button onClick={handleProfileSave}>
                <Save className="mr-2 h-4 w-4" /> Sauvegarder les modifications
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SidebarProvider>
  );
}
