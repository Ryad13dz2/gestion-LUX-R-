
"use client";
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, BookOpen, Users, MessageSquare, Send, Search as SearchIcon, Activity as ActivityIcon } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import React, { useState, useEffect, FormEvent, useRef } from 'react';
import { summarizeLibraryActivity } from '@/ai/flows/summarize-library-flow.ts';
import type { LibrarySummaryInput } from '@/ai/schemas/library-summary-schemas';
import { useNotifications, type Notification as NotificationType } from '@/contexts/NotificationContext';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Separator } from '@/components/ui/separator';

const LOCAL_STORAGE_BOOKS_KEY = 'luxr_library_books';
const LOCAL_STORAGE_LECTEURS_KEY = 'luxr_library_lecteurs';
const LOCAL_STORAGE_LOANS_KEY = 'luxr_library_loans'; // Key for loans

interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  readerId: string;
  readerName: string;
  loanDate: string;
  dueDate: string;
  returnDate?: string | null;
}

interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ia';
  timestamp: Date;
}

export default function BibliothequeDashboardPage() {
  const [totalBooks, setTotalBooks] = useState(0);
  const [totalLecteurs, setTotalLecteurs] = useState(0);
  const [currentLoansCount, setCurrentLoansCount] = useState(0); // State for current loans
  const [isClient, setIsClient] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const [iaQuery, setIaQuery] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: Date.now().toString(), text: "Bonjour ! Comment puis-je vous aider à gérer votre bibliothèque aujourd'hui ?", sender: 'ia', timestamp: new Date() }
  ]);
  const [isIaLoading, setIsIaLoading] = useState(false);
  const chatScrollAreaRef = useRef<HTMLDivElement>(null);

  const { notifications } = useNotifications();
  const latestNotifications = notifications.slice(0, 5);

  useEffect(() => {
    setIsClient(true);
    try {
      const storedBooks = localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY);
      if (storedBooks) {
        const parsedBooks = JSON.parse(storedBooks);
        if (Array.isArray(parsedBooks)) {
          setTotalBooks(parsedBooks.length);
        }
      }
      const storedLecteurs = localStorage.getItem(LOCAL_STORAGE_LECTEURS_KEY);
      if (storedLecteurs) {
        const parsedLecteurs = JSON.parse(storedLecteurs);
        if (Array.isArray(parsedLecteurs)) {
          setTotalLecteurs(parsedLecteurs.length);
        }
      }
      const storedLoans = localStorage.getItem(LOCAL_STORAGE_LOANS_KEY);
      if (storedLoans) {
        const parsedLoans: Loan[] = JSON.parse(storedLoans);
        if (Array.isArray(parsedLoans)) {
          const activeLoans = parsedLoans.filter(loan => !loan.returnDate);
          setCurrentLoansCount(activeLoans.length);
        }
      }
    } catch (error) {
      console.error("Erreur de chargement des données depuis localStorage:", error);
      setTotalBooks(0);
      setTotalLecteurs(0);
      setCurrentLoansCount(0);
    }
  }, []);

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (searchQuery.trim()) {
      // Redirect to the books page with the search query
      window.location.href = `/bibliotheque/livres?q=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  const handleIaSubmit = async (event?: FormEvent<HTMLFormElement>) => {
    event?.preventDefault();
    if (!iaQuery.trim()) return;

    const userMessage: ChatMessage = { id: Date.now().toString(), text: iaQuery, sender: 'user', timestamp: new Date() };
    setChatMessages(prev => [...prev, userMessage]);
    setIsIaLoading(true);
    const currentQuery = iaQuery;
    setIaQuery('');

    try {
      console.log("[DASHBOARD PAGE] Calling summarizeLibraryActivity with query:", currentQuery);
      const input: LibrarySummaryInput = { query: currentQuery };
      const result = await summarizeLibraryActivity(input);
      console.log("[DASHBOARD PAGE] Received summary from IA:", result.summary);
      const iaMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: result.summary || "Je n'ai pas pu générer de réponse.", sender: 'ia', timestamp: new Date() };
      setChatMessages(prev => [...prev, iaMessage]);
    } catch (error) {
      console.error("[DASHBOARD PAGE] Error calling IA for summary:", error);
      const errorMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: "Désolé, une erreur est survenue lors de la communication avec l'IA.", sender: 'ia', timestamp: new Date() };
      setChatMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsIaLoading(false);
    }
  };

  useEffect(() => {
    if (chatScrollAreaRef.current) {
      const viewport = chatScrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  }, [chatMessages]);


  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-card text-card-foreground">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="shadow-lg hover:shadow-primary/20 transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-semibold text-primary">Total des Livres</CardTitle>
            <BookOpen className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isClient ? totalBooks : "..."}</div>
            <p className="text-sm text-muted-foreground">Livres enregistrés (localement).</p>
          </CardContent>
        </Card>
        <Card className="shadow-lg hover:shadow-primary/20 transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-semibold text-primary">Total Lecteurs</CardTitle>
            <Users className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isClient ? totalLecteurs : "..."}</div>
            <p className="text-sm text-muted-foreground">Lecteurs inscrits (localement).</p>
          </CardContent>
        </Card>
        <Card className="shadow-lg hover:shadow-primary/20 transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-semibold text-primary">Livres Empruntés</CardTitle>
            <BookOpen className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isClient ? currentLoansCount : "..."}</div>
            <p className="text-sm text-muted-foreground">En cours (depuis stockage local).</p>
          </CardContent>
        </Card>
        <Card className="shadow-lg hover:shadow-primary/20 transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-semibold text-destructive">Retards Actuels</CardTitle>
            <BookOpen className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{isClient ? '0' : "..."}</div>
            <p className="text-sm text-muted-foreground">Livres en retard (Module Emprunts à venir).</p>
          </CardContent>
        </Card>
      </div>

      <form onSubmit={handleSearchSubmit} className="mb-6">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            name="search"
            placeholder="Rechercher des livres dans votre bibliothèque..."
            className="w-full pl-10 pr-28 py-3 rounded-lg border bg-input text-foreground shadow-sm text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 py-1.5 px-4">
            Rechercher
          </Button>
        </div>
      </form>

      <Separator className="my-4" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-grow">
        <Card className="md:col-span-2 shadow-lg flex flex-col">
          <CardHeader>
            <CardTitle className="text-xl flex items-center text-primary">
              <MessageSquare className="mr-2 h-6 w-6" /> Assistant IA de la Bibliothèque
            </CardTitle>
            <CardDescription className="text-base">Posez vos questions sur la gestion, demandez des résumés, etc.</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow flex flex-col p-4">
            <ScrollArea className="h-80 flex-grow mb-3 pr-4 border rounded-md p-3 bg-muted/20" ref={chatScrollAreaRef}>
              {chatMessages.map((msg) => (
                <div key={msg.id} className={`mb-3 flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-lg shadow-md ${msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                    <p className="text-base whitespace-pre-wrap">{msg.text}</p>
                    <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-primary-foreground/80 text-right' : 'text-secondary-foreground/80 text-left'}`}>
                      {isClient ? formatDistanceToNow(msg.timestamp, { addSuffix: true, locale: fr }) : '...'}
                    </p>
                  </div>
                </div>
              ))}
              {isIaLoading && (
                 <div className="mb-3 flex justify-start">
                    <div className="max-w-[80%] p-3 rounded-lg shadow-md bg-secondary text-secondary-foreground flex items-center">
                       <span className="text-sm italic">L'IA réfléchit...</span>
                    </div>
                 </div>
              )}
            </ScrollArea>
            <form onSubmit={handleIaSubmit} className="flex items-center gap-2 mt-2">
              <Textarea
                value={iaQuery}
                onChange={(e) => setIaQuery(e.target.value)}
                placeholder="Posez une question à l'IA (ex: 'Donne-moi un rapport sur la bibliothèque')..."
                className="flex-grow resize-none bg-input text-foreground text-base"
                rows={2}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleIaSubmit();
                    }
                }}
              />
              <Button type="submit" disabled={isIaLoading || !iaQuery.trim()} size="icon" aria-label="Envoyer à l'IA">
                {isIaLoading ? <span className="text-xs">...</span> : <Send className="h-5 w-5" />}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="shadow-lg flex flex-col">
          <CardHeader>
            <CardTitle className="text-xl flex items-center text-primary">
              <ActivityIcon className="mr-2 h-6 w-6" /> Activité Récente
            </CardTitle>
            <CardDescription className="text-base">Dernières actions et notifications.</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow p-4">
            {isClient && latestNotifications.length > 0 ? (
              <ScrollArea className="h-96">
                <ul className="space-y-3">
                  {latestNotifications.map((notif: NotificationType) => (
                    <li key={notif.id} className={`p-3 rounded-md border ${notif.read ? 'bg-muted/30 border-border/50' : 'bg-primary/10 border-primary/30'}`}>
                      <h4 className="font-semibold text-sm">{notif.title}</h4>
                      <p className="text-xs text-muted-foreground mb-1">{notif.description}</p>
                      <p className="text-xs text-muted-foreground/70">
                        {isClient ? formatDistanceToNow(notif.timestamp, { addSuffix: true, locale: fr }) : '...'}
                      </p>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            ) : (
              isClient && <p className="text-sm text-muted-foreground text-center py-4">Aucune activité récente.</p>
            )}
            {!isClient && (
                <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                        <div key={i} className="p-3 rounded-md border bg-muted/30 border-border/50 animate-pulse">
                            <div className="h-4 bg-muted rounded w-3/4 mb-1.5"></div>
                            <div className="h-3 bg-muted rounded w-full mb-1"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                        </div>
                    ))}
                </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-auto pt-6 flex justify-center">
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à l'accueil LUX-R
          </Link>
        </Button>
      </div>
    </main>
  );
}
