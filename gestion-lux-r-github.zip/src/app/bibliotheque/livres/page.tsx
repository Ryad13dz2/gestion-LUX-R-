"use client";
import Link from 'next/link';
import Image from 'next/image';
import React, { useState, useEffect, FormEvent, Suspense } from 'react'; // Import Suspense
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowLeft, BookMarked, PlusCircle, Search, BookUp, Trash2, Edit3, UploadCloud, ExternalLink, Loader2 } from 'lucide-react'; // Import Loader2 for fallback
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from '@/contexts/NotificationContext';
import { Separator } from '@/components/ui/separator';

interface Book {
  id: string;
  isbn?: string;
  title: string;
  author?: string;
  genre?: string;
  year?: string;
  quantity?: number;
  coverImage?: string; // Can be a URL or a Data URL for uploaded images
  description?: string;
  publisher?: string;
  pageCount?: number;
}

const LOCAL_STORAGE_BOOKS_KEY = 'luxr_library_books';

// Component containing the main logic, using useSearchParams
function LivresPageContent() {
  const [isAddBookDialogOpen, setIsAddBookDialogOpen] = useState(false);
  const [books, setBooks] = useState<Book[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<Book[]>([]);
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [localSearchTerm, setLocalSearchTerm] = useState('');
  const [isClient, setIsClient] = useState(false);
  const [selectedCoverImageDataUrl, setSelectedCoverImageDataUrl] = useState<string | undefined>(undefined);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | undefined>(undefined);
  const searchParams = useSearchParams(); // useSearchParams is used here

  const [editingBook, setEditingBook] = useState<Book | null>(null);

  useEffect(() => {
    setIsClient(true);
    try {
      const storedBooks = localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY);
      if (storedBooks) {
        const parsedBooks = JSON.parse(storedBooks);
        if (Array.isArray(parsedBooks)) {
          const validBooks = parsedBooks.filter(
            (book): book is Book =>
              book && typeof book.id === 'string' && typeof book.title === 'string'
          );
          setBooks(validBooks);
        } else {
          console.warn("Stored books data in localStorage is not an array, resetting.");
          localStorage.removeItem(LOCAL_STORAGE_BOOKS_KEY);
          setBooks([]);
        }
      } else {
        setBooks([]);
      }
    } catch (error) {
      console.error("Error loading books from localStorage:", error);
      localStorage.removeItem(LOCAL_STORAGE_BOOKS_KEY);
      setBooks([]);
      toast({
        title: "Erreur de chargement (Local)",
        description: "Impossible de charger les livres. La liste locale a été réinitialisée.",
        variant: "destructive",
      });
    }
    
    const queryFromUrl = searchParams.get('q');
    if (queryFromUrl) {
      setLocalSearchTerm(queryFromUrl);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toast]); // Removed searchParams from dependency array as it's stable

  useEffect(() => {
    if (isClient) {
      try {
        localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(books));
      } catch (error) {
        console.error("Error saving books to localStorage:", error);
        toast({
          title: "Erreur de sauvegarde locale",
          description: "Impossible de sauvegarder les livres dans le stockage local de votre navigateur.",
          variant: "destructive",
        });
      }
    }
  }, [books, isClient, toast]);

  useEffect(() => {
    const searchTerm = localSearchTerm.trim().toLowerCase();
    if (!searchTerm) {
      setFilteredBooks(books);
      return;
    }
    const newFilteredBooks = books.filter(book => {
      const titleMatch = book.title && book.title.toLowerCase().includes(searchTerm);
      const authorMatch = book.author && book.author.toLowerCase().includes(searchTerm);
      const isbnMatch = book.isbn && book.isbn.toLowerCase().includes(searchTerm);
      const genreMatch = book.genre && book.genre.toLowerCase().includes(searchTerm);
      const descriptionMatch = book.description && book.description.toLowerCase().includes(searchTerm);
      const publisherMatch = book.publisher && book.publisher.toLowerCase().includes(searchTerm);
      return titleMatch || authorMatch || isbnMatch || genreMatch || descriptionMatch || publisherMatch;
    });
    setFilteredBooks(newFilteredBooks);
  }, [books, localSearchTerm]);

  const handleCoverImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedCoverImageDataUrl(reader.result as string);
        setImagePreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setSelectedCoverImageDataUrl(undefined);
      setImagePreviewUrl(undefined);
    }
  };
  
  const resetFormDialog = (formElement?: HTMLFormElement) => {
    setSelectedCoverImageDataUrl(undefined);
    setImagePreviewUrl(undefined);
    setEditingBook(null); 
    const formToReset = formElement || document.getElementById('addBookForm') as HTMLFormElement | null;
    formToReset?.reset();
  };

  const openAddBookDialog = () => {
    resetFormDialog(); 
    setIsAddBookDialogOpen(true);
  };

  const openEditBookDialog = (bookToEdit: Book) => {
    setEditingBook(bookToEdit);
    setSelectedCoverImageDataUrl(bookToEdit.coverImage); 
    setImagePreviewUrl(bookToEdit.coverImage); 
    setIsAddBookDialogOpen(true);
  };

  useEffect(() => {
    if (isAddBookDialogOpen && editingBook) {
      const form = document.getElementById('addBookForm') as HTMLFormElement | null;
      if (form) {
        (form.elements.namedItem('title') as HTMLInputElement).value = editingBook.title || '';
        (form.elements.namedItem('author') as HTMLInputElement).value = editingBook.author || '';
        (form.elements.namedItem('isbn') as HTMLInputElement).value = editingBook.isbn || '';
        (form.elements.namedItem('publisher') as HTMLInputElement).value = editingBook.publisher || '';
        (form.elements.namedItem('year') as HTMLInputElement).value = editingBook.year || '';
        (form.elements.namedItem('pageCount') as HTMLInputElement).value = editingBook.pageCount?.toString() || '';
        (form.elements.namedItem('genre') as HTMLInputElement).value = editingBook.genre || '';
        (form.elements.namedItem('quantity') as HTMLInputElement).value = editingBook.quantity?.toString() || '1';
        (form.elements.namedItem('description') as HTMLTextAreaElement).value = editingBook.description || '';
      }
    }
  }, [isAddBookDialogOpen, editingBook]);


  const handleSubmitBook = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    const bookData: Book = {
      id: editingBook ? editingBook.id : Date.now().toString(),
      isbn: formData.get('isbn') as string || undefined,
      title: formData.get('title') as string || 'Sans titre',
      author: formData.get('author') as string || undefined,
      genre: formData.get('genre') as string || undefined,
      year: formData.get('year') as string || undefined,
      quantity: parseInt(formData.get('quantity') as string) || 1,
      coverImage: selectedCoverImageDataUrl || (editingBook ? editingBook.coverImage : undefined),
      description: formData.get('description') as string || undefined,
      publisher: formData.get('publisher') as string || undefined,
      pageCount: formData.get('pageCount') ? parseInt(formData.get('pageCount') as string) : undefined,
    };

    if (editingBook) {
      setBooks((prevBooks) => prevBooks.map(b => b.id === editingBook.id ? bookData : b));
      toast({
        title: "Livre modifié (Stock Navigateur)",
        description: `"${bookData.title}" mis à jour. Sauvegarde locale dans votre navigateur.`,
      });
      addNotification("Livre modifié (local)", `"${bookData.title}" mis à jour dans le stock local (navigateur).`);
    } else {
      setBooks((prevBooks) => [bookData, ...prevBooks]);
      toast({
        title: "Livre ajouté (Stock Navigateur)",
        description: `"${bookData.title}" ajouté. Sauvegarde locale dans votre navigateur.`,
      });
      addNotification("Nouveau livre ajouté (local)", `"${bookData.title}" par ${bookData.author || 'Auteur inconnu'} ajouté au stock local (navigateur).`);
    }
    
    setLocalSearchTerm(''); 
    setIsAddBookDialogOpen(false);
    resetFormDialog(event.currentTarget);
  };

  const handleDeleteBook = (bookId: string) => {
    const bookToDelete = books.find(book => book.id === bookId);
    setBooks(prevBooks => prevBooks.filter(book => book.id !== bookId));
    toast({
      title: "Livre supprimé (Stock Navigateur)",
      description: `"${bookToDelete?.title || 'Inconnu'}" retiré. Sauvegarde locale dans votre navigateur.`,
      variant: "destructive"
    });
    if (bookToDelete) {
      addNotification("Livre supprimé (local)", `"${bookToDelete.title}" supprimé du stock local (navigateur).`);
    }
  };

  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-background text-foreground">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold text-foreground">Gestion des Livres</h1>
        <Dialog open={isAddBookDialogOpen} onOpenChange={(open) => {
          setIsAddBookDialogOpen(open);
          if (!open) {
            resetFormDialog(); 
          }
        }}>
          <DialogTrigger asChild>
            <Button onClick={openAddBookDialog}>
              <PlusCircle className="mr-2 h-5 w-5" />
              Ajouter un livre manuellement
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px] bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center">
                <BookUp className="mr-2 h-6 w-6" /> 
                {editingBook ? "Modifier le livre" : "Ajouter un nouveau livre (Manuel)"}
              </DialogTitle>
              <DialogDescription>
                {editingBook ? "Modifiez les informations du livre." : "Remplissez les informations ci-dessous pour ajouter un nouveau livre à la bibliothèque."} Sauvegarde locale dans votre navigateur.
              </DialogDescription>
            </DialogHeader>
            <form id="addBookForm" onSubmit={handleSubmitBook}>
              <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                {/* Form fields remain the same */}
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    Titre*
                  </Label>
                  <Input id="title" name="title" placeholder="Ex: Le Petit Prince" className="col-span-3 bg-background text-foreground border-border" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="author" className="text-right">
                    Auteur(s)
                  </Label>
                  <Input id="author" name="author" placeholder="Ex: Antoine de Saint-Exupéry" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="isbn" className="text-right">
                    ISBN
                  </Label>
                  <Input id="isbn" name="isbn" placeholder="Ex: 978-2070612750" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="publisher" className="text-right">
                    Éditeur
                  </Label>
                  <Input id="publisher" name="publisher" placeholder="Ex: Gallimard" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="year" className="text-right">
                    Année Pub.
                  </Label>
                  <Input id="year" name="year" type="number" placeholder="Ex: 1943" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="pageCount" className="text-right">
                    Pages
                  </Label>
                  <Input id="pageCount" name="pageCount" type="number" placeholder="Ex: 96" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="genre" className="text-right">
                    Genre
                  </Label>
                  <Input id="genre" name="genre" placeholder="Ex: Conte philosophique" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="quantity" className="text-right">
                    Quantité
                  </Label>
                  <Input id="quantity" name="quantity" type="number" defaultValue="1" min="0" className="col-span-3 bg-background text-foreground border-border" />
                </div>

                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="description" className="text-right pt-2">
                    Description
                  </Label>
                  <Textarea id="description" name="description" placeholder="Brève description du livre..." className="col-span-3 bg-background text-foreground border-border" rows={3} />
                </div>

                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="coverImageFile" className="text-right pt-2">
                    Couverture
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="coverImageFile"
                      name="coverImageFile"
                      type="file"
                      accept="image/*"
                      className="bg-background text-foreground border-border file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                      onChange={handleCoverImageChange}
                    />
                    {editingBook && editingBook.coverImage && !imagePreviewUrl && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        Couverture actuelle : <Link href={editingBook.coverImage} target="_blank" className="text-primary hover:underline">voir l'image</Link> (Pour changer, téléversez une nouvelle image)
                      </div>
                    )}
                    {imagePreviewUrl && (
                      <div className="mt-3 relative w-32 h-48 rounded border border-border overflow-hidden">
                        <Image src={imagePreviewUrl} alt="Aperçu couverture" fill style={{objectFit: 'contain'}} data-ai-hint="book cover" />
                      </div>
                    )}
                    {!imagePreviewUrl && !editingBook?.coverImage && (
                       <div className="mt-3 w-32 h-48 rounded border border-dashed border-border flex flex-col items-center justify-center bg-muted/50 text-muted-foreground">
                         <UploadCloud className="h-8 w-8 mb-2" />
                         <span>Téléverser</span>
                       </div>
                    )}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setIsAddBookDialogOpen(false); resetFormDialog(); }}>Annuler</Button>
                <Button type="submit
">{editingBook ? 'Sauvegarder les modifications' : 'Ajouter le livre'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="mb-4 flex items-center gap-2">
        <Search className="h-5 w-5 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Rechercher par titre, auteur, ISBN, genre..."
          value={localSearchTerm}
          onChange={(e) => setLocalSearchTerm(e.target.value)}
          className="max-w-sm bg-background text-foreground border-border"
        />
      </div>

      <Separator className="my-4" />

      {isClient && filteredBooks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 overflow-y-auto flex-1 pr-2 pb-4">
          {filteredBooks.map((book) => (
            <Card key={book.id} className="flex flex-col bg-card text-card-foreground hover:shadow-lg transition-shadow duration-200 ease-in-out overflow-hidden h-full">
              <CardHeader className="p-4 flex-shrink-0">
                <div className="relative w-full h-48 mb-3 rounded border border-border overflow-hidden bg-muted/50 flex items-center justify-center">
                  {book.coverImage ? (
                    <Image src={book.coverImage} alt={`Couverture de ${book.title}`} fill style={{objectFit: 'contain'}} data-ai-hint="book cover" />
                  ) : (
                    <BookMarked className="h-16 w-16 text-muted-foreground" />
                  )}
                </div>
                <CardTitle className="text-lg font-semibold leading-tight truncate">{book.title}</CardTitle>
                {book.author && <CardDescription className="text-sm text-muted-foreground truncate">{book.author}</CardDescription>}
              </CardHeader>
              <CardContent className="p-4 pt-0 text-sm text-muted-foreground flex-grow flex flex-col justify-between">
                <div>
                  {book.isbn && <p className="mb-1 truncate">ISBN: {book.isbn}</p>}
                  {book.genre && <p className="mb-1 truncate">Genre: {book.genre}</p>}
                  {book.year && <p className="mb-1 truncate">Année: {book.year}</p>}
                  {book.publisher && <p className="mb-1 truncate">Éditeur: {book.publisher}</p>}
                  {book.pageCount && <p className="mb-1 truncate">Pages: {book.pageCount}</p>}
                  {book.quantity !== undefined && <p className="mb-1 truncate">Quantité: {book.quantity}</p>}
                  {book.description && <p className="text-xs line-clamp-2 mt-2">{book.description}</p>}
                </div>
                <div className="flex justify-end gap-2 mt-4 pt-2 border-t border-border/50">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditBookDialog(book)}>
                    <Edit3 className="h-4 w-4" />
                    <span className="sr-only">Modifier</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive/80" onClick={() => handleDeleteBook(book.id)}>
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Supprimer</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : isClient ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground p-8">
          <BookMarked className="h-16 w-16 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Aucun livre trouvé</h2>
          {localSearchTerm ? (
            <p>Votre recherche "{localSearchTerm}" n'a donné aucun résultat.</p>
          ) : (
            <p>Votre bibliothèque est vide. Ajoutez des livres pour commencer.</p>
          )}
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground p-8">
          <Loader2 className="h-16 w-16 mb-4 animate-spin" />
          <p>Chargement des livres...</p>
        </div>
      )}
    </main>
  );
}

// Default export wraps the main component in Suspense
export default function LivresPage() {
  return (
    <Suspense fallback={
      <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground p-8">
        <Loader2 className="h-16 w-16 mb-4 animate-spin" />
        <p>Chargement de la page des livres...</p>
      </div>
    }>
      <LivresPageContent />
    </Suspense>
  );
}''