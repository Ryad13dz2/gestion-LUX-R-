
"use client";
import Link from 'next/link';
import Image from 'next/image';
import React, { useState, FormEvent, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowLeft, Users2, PlusCircle, UserPlus, UploadCloud, Search, Edit3, Trash2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from '@/contexts/NotificationContext';

interface Lecteur {
  id: string;
  nom: string;
  prenom: string;
  email?: string;
  photoUrl?: string; // URL de la photo ou Data URL pour l'image téléversée
  niveau?: string; // ex: régulier, VIP
  estBloque?: boolean;
}

const LOCAL_STORAGE_LECTEURS_KEY = 'luxr_library_lecteurs';

export default function LecteursPage() {
  const [isAddLecteurDialogOpen, setIsAddLecteurDialogOpen] = useState(false);
  const [lecteurs, setLecteurs] = useState<Lecteur[]>([]);
  const [filteredLecteurs, setFilteredLecteurs] = useState<Lecteur[]>([]);
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [localSearchTerm, setLocalSearchTerm] = useState('');
  const [isClient, setIsClient] = useState(false);
  const [selectedPhotoDataUrl, setSelectedPhotoDataUrl] = useState<string | undefined>(undefined);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | undefined>(undefined);
  const [editingLecteur, setEditingLecteur] = useState<Lecteur | null>(null);

  useEffect(() => {
    setIsClient(true);
    try {
      const storedLecteurs = localStorage.getItem(LOCAL_STORAGE_LECTEURS_KEY);
      if (storedLecteurs) {
        const parsedLecteurs = JSON.parse(storedLecteurs);
        if (Array.isArray(parsedLecteurs)) {
          const validLecteurs = parsedLecteurs.filter(
            (lecteur): lecteur is Lecteur =>
            lecteur && typeof lecteur.id === 'string' && typeof lecteur.nom === 'string' && typeof lecteur.prenom === 'string'
          );
          setLecteurs(validLecteurs);
        } else {
          console.warn("Stored lecteurs data in localStorage is not an array, resetting.");
          localStorage.removeItem(LOCAL_STORAGE_LECTEURS_KEY);
          setLecteurs([]);
        }
      } else {
        setLecteurs([]);
      }
    } catch (error) {
      console.error("Erreur de chargement des lecteurs depuis localStorage:", error);
      localStorage.removeItem(LOCAL_STORAGE_LECTEURS_KEY);
      setLecteurs([]);
      toast({
        title: "Erreur de chargement",
        description: "Impossible de charger les lecteurs. La liste a été réinitialisée.",
        variant: "destructive",
      });
    }
  }, [toast]);

  useEffect(() => {
    if (isClient) {
      try {
        localStorage.setItem(LOCAL_STORAGE_LECTEURS_KEY, JSON.stringify(lecteurs));
      } catch (error) {
        console.error("Error saving lecteurs to localStorage:", error);
        toast({
          title: "Erreur de sauvegarde locale",
          description: "Impossible de sauvegarder les lecteurs dans le stockage local.",
          variant: "destructive",
        });
      }
    }
  }, [lecteurs, isClient, toast]);

  useEffect(() => {
    const searchTerm = localSearchTerm.trim().toLowerCase();
    if (!searchTerm) {
      setFilteredLecteurs(lecteurs);
      return;
    }
    setFilteredLecteurs(
      lecteurs.filter(lecteur =>
        (lecteur.nom?.toLowerCase() || '').includes(searchTerm) ||
        (lecteur.prenom?.toLowerCase() || '').includes(searchTerm) ||
        (lecteur.email?.toLowerCase() || '').includes(searchTerm)
      )
    );
  }, [lecteurs, localSearchTerm]);

  const handlePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedPhotoDataUrl(reader.result as string);
        setImagePreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setSelectedPhotoDataUrl(undefined);
      setImagePreviewUrl(undefined);
    }
  };

  const resetFormDialog = (formElement?: HTMLFormElement) => {
    setSelectedPhotoDataUrl(undefined);
    setImagePreviewUrl(undefined);
    setEditingLecteur(null);
    const formToReset = formElement || document.getElementById('addLecteurForm') as HTMLFormElement | null;
    formToReset?.reset();
  };

  const openAddLecteurDialog = () => {
    resetFormDialog();
    setIsAddLecteurDialogOpen(true);
  };

  const openEditLecteurDialog = (lecteurToEdit: Lecteur) => {
    setEditingLecteur(lecteurToEdit);
    setSelectedPhotoDataUrl(lecteurToEdit.photoUrl);
    setImagePreviewUrl(lecteurToEdit.photoUrl);
    setIsAddLecteurDialogOpen(true);
  };
  
  useEffect(() => {
    if (isAddLecteurDialogOpen && editingLecteur) {
      const form = document.getElementById('addLecteurForm') as HTMLFormElement | null;
      if (form) {
        (form.elements.namedItem('nom') as HTMLInputElement).value = editingLecteur.nom || '';
        (form.elements.namedItem('prenom') as HTMLInputElement).value = editingLecteur.prenom || '';
        (form.elements.namedItem('email') as HTMLInputElement).value = editingLecteur.email || '';
      }
    }
  }, [isAddLecteurDialogOpen, editingLecteur]);


  const handleSubmitLecteur = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const lecteurData: Lecteur = {
      id: editingLecteur ? editingLecteur.id : Date.now().toString(),
      nom: formData.get('nom') as string || 'N/A',
      prenom: formData.get('prenom') as string || 'N/A',
      email: formData.get('email') as string || undefined,
      photoUrl: selectedPhotoDataUrl || (editingLecteur ? editingLecteur.photoUrl : undefined),
      // Niveau et estBloque seront gérés plus tard
    };

    if (editingLecteur) {
      setLecteurs(prevLecteurs => prevLecteurs.map(l => l.id === editingLecteur.id ? lecteurData : l));
      toast({
        title: "Lecteur modifié (localement)",
        description: `Le lecteur ${lecteurData.prenom} ${lecteurData.nom} a été mis à jour.`,
      });
      addNotification("Lecteur modifié", `Lecteur "${lecteurData.prenom} ${lecteurData.nom}" mis à jour.`);
    } else {
      setLecteurs(prevLecteurs => [lecteurData, ...prevLecteurs]);
      toast({
        title: "Lecteur ajouté (localement)",
        description: `Le lecteur ${lecteurData.prenom} ${lecteurData.nom} a été ajouté. Sauvegarde locale navigateur.`,
      });
      addNotification("Nouveau lecteur ajouté", `${lecteurData.prenom} ${lecteurData.nom} ajouté au stock local.`);
    }
    
    setLocalSearchTerm('');
    setIsAddLecteurDialogOpen(false);
    resetFormDialog(event.currentTarget);
  };

  const handleDeleteLecteur = (lecteurId: string) => {
    const lecteurToDelete = lecteurs.find(l => l.id === lecteurId);
    setLecteurs(prevLecteurs => prevLecteurs.filter(l => l.id !== lecteurId));
    toast({
      title: "Lecteur supprimé (localement)",
      description: `Le lecteur ${lecteurToDelete?.prenom || ''} ${lecteurToDelete?.nom || 'Inconnu'} a été retiré.`,
      variant: "destructive"
    });
    if (lecteurToDelete) {
      addNotification("Lecteur supprimé", `Lecteur "${lecteurToDelete.prenom} ${lecteurToDelete.nom}" supprimé.`);
    }
  };


  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-background text-foreground">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold text-foreground">Gestion des Lecteurs</h1>
        <Dialog open={isAddLecteurDialogOpen} onOpenChange={(open) => {
          setIsAddLecteurDialogOpen(open);
          if (!open) resetFormDialog();
        }}>
          <DialogTrigger asChild>
            <Button onClick={openAddLecteurDialog}>
              <UserPlus className="mr-2 h-5 w-5" />
              Ajouter un nouveau lecteur
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px] bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center">
                <UserPlus className="mr-2 h-6 w-6" /> 
                {editingLecteur ? "Modifier le lecteur" : "Ajouter un nouveau lecteur"}
              </DialogTitle>
              <DialogDescription>
                {editingLecteur ? "Modifiez les informations du lecteur." : "Remplissez les informations pour ajouter un lecteur."} Sauvegarde locale navigateur.
              </DialogDescription>
            </DialogHeader>
            <form id="addLecteurForm" onSubmit={handleSubmitLecteur}>
              <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="nom" className="text-right">Nom*</Label>
                  <Input id="nom" name="nom" placeholder="Ex: Dupont" className="col-span-3 bg-background text-foreground border-border" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="prenom" className="text-right">Prénom*</Label>
                  <Input id="prenom" name="prenom" placeholder="Ex: Jean" className="col-span-3 bg-background text-foreground border-border" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">Email</Label>
                  <Input id="email" name="email" type="email" placeholder="Ex: jean.dupont@email.com" className="col-span-3 bg-background text-foreground border-border" />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="photoFile" className="text-right pt-2">Photo</Label>
                  <div className="col-span-3">
                    <Input
                      id="photoFile"
                      name="photoFile"
                      type="file"
                      accept="image/*"
                      className="bg-background text-foreground border-border file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                      onChange={handlePhotoChange}
                    />
                     {editingLecteur && editingLecteur.photoUrl && !imagePreviewUrl && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        Photo actuelle. Pour changer, téléversez une nouvelle image.
                      </div>
                    )}
                    {imagePreviewUrl && (
                      <div className="mt-3 relative w-24 h-24 rounded-full border border-border overflow-hidden">
                        <Image src={imagePreviewUrl} alt="Aperçu photo lecteur" fill style={{objectFit: 'cover'}} data-ai-hint="person portrait" />
                      </div>
                    )}
                    {!imagePreviewUrl && (
                       <div className="mt-3 w-24 h-24 rounded-full border border-dashed border-border flex flex-col items-center justify-center bg-muted/50 text-muted-foreground">
                         <UploadCloud className="h-8 w-8 mb-1" />
                         <span className="text-xs text-center">Aperçu</span>
                       </div>
                    )}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setIsAddLecteurDialogOpen(false); resetFormDialog(); }}>Annuler</Button>
                <Button type="submit">
                  {editingLecteur ? <Edit3 className="mr-2 h-4 w-4" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                  {editingLecteur ? "Sauvegarder" : "Ajouter le lecteur"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex-1 bg-card p-6 rounded-lg shadow-md overflow-auto">
        <h2 className="text-xl font-semibold mb-4 text-card-foreground">Liste des Lecteurs (Sauvegarde Navigateur)</h2>
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Rechercher un lecteur (nom, prénom, email)..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border bg-background text-foreground shadow-sm text-base"
              value={localSearchTerm}
              onChange={(e) => setLocalSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {isClient && filteredLecteurs.length === 0 && lecteurs.length === 0 && (
          <div className="border border-dashed border-border rounded-lg p-8 text-center bg-background/50">
            <Users2 className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-base">Aucun lecteur enregistré pour le moment.</p>
            <p className="text-sm text-muted-foreground mt-1">Ajoutez des lecteurs via le bouton ci-dessus.</p>
          </div>
        )}
        {isClient && filteredLecteurs.length === 0 && lecteurs.length > 0 && localSearchTerm.trim() && (
          <div className="border border-dashed border-border rounded-lg p-8 text-center bg-background/50">
            <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-base">Aucun lecteur ne correspond à "{localSearchTerm}".</p>
          </div>
        )}

        {isClient && filteredLecteurs.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredLecteurs.map((lecteur) => (
              <Card key={lecteur.id} className="flex flex-col overflow-hidden shadow-lg hover:shadow-primary/20 transition-shadow bg-background/80">
                <CardHeader className="p-4 items-center">
                  <div className="relative w-24 h-24 mb-3 rounded-full overflow-hidden bg-muted">
                    <Image
                      src={lecteur.photoUrl || `https://placehold.co/100x100.png?text=${(lecteur.prenom?.[0] || 'L').toUpperCase()}${(lecteur.nom?.[0] || '').toUpperCase()}`}
                      alt={`Photo de ${lecteur.prenom} ${lecteur.nom}`}
                      fill
                      style={{objectFit: 'cover'}}
                      data-ai-hint="person portrait"
                      onError={(e) => { e.currentTarget.src = `https://placehold.co/100x100.png?text=Err`; }}
                    />
                  </div>
                  <CardTitle className="text-lg leading-tight text-center" title={`${lecteur.prenom} ${lecteur.nom}`}>{lecteur.prenom} {lecteur.nom}</CardTitle>
                  {lecteur.email && <CardDescription className="text-sm text-muted-foreground mt-1 text-center" title={lecteur.email}>{lecteur.email}</CardDescription>}
                </CardHeader>
                <CardContent className="p-4 pt-0 flex-grow flex flex-col">
                  {/* Placeholder for Niveau, Blocage, Historique */}
                  <p className="text-xs text-muted-foreground mt-1 mb-2 flex-grow text-center">Niveau: {lecteur.niveau || 'Standard'} {lecteur.estBloque ? '(Bloqué)' : ''}<br/>Plus d'infos à venir...</p>
                  <div className="mt-auto flex gap-2 pt-2 border-t border-border">
                    <Button variant="outline" size="sm" onClick={() => openEditLecteurDialog(lecteur)} className="flex-1">
                      <Edit3 className="mr-1.5 h-3.5 w-3.5" />
                      Modifier
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteLecteur(lecteur.id)} className="flex-1">
                      <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                      Supprimer
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        {!isClient && ( // Skeletons for initial load
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, index) => (
              <Card key={`skeleton-lecteur-${index}`} className="animate-pulse bg-background/50">
                <CardHeader className="p-4 items-center">
                  <div className="w-24 h-24 mb-3 rounded-full bg-muted" />
                  <div className="h-5 w-3/4 bg-muted rounded mb-1 mx-auto" />
                  <div className="h-4 w-1/2 bg-muted rounded mx-auto" />
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="h-8 w-full bg-muted rounded" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      <div className="mt-6 bg-card p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-3 text-card-foreground">Fonctionnalités Prévues pour les Lecteurs</h2>
        <Users2 className="h-8 w-8 text-primary mb-3" />
        <ul className="list-disc list-inside text-muted-foreground space-y-1 text-sm">
          <li>Création de profils utilisateurs avec photo (en cours, modification implémentée)</li>
          <li>Historique complet des emprunts / retours</li>
          <li>Système de niveaux (ex. : lecteur régulier, VIP…)</li>
          <li>Blocage temporaire en cas de retards</li>
          <li>Système de points ou récompenses pour les lecteurs actifs</li>
        </ul>
      </div>

      <div className="mt-auto pt-6 flex gap-4 justify-end">
        <Button variant="outline" asChild>
          <Link href="/bibliotheque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tableau de Bord Biblio
          </Link>
        </Button>
      </div>
    </main>
  );
}
