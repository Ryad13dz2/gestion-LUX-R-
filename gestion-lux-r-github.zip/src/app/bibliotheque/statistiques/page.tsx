
"use client";
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowLeft, BarChart3, AreaChart, ListChecks, Users, BookOpen, Clock, Percent, Download, FileText, FileSpreadsheet, Activity, Info, PieChart as PieChartIcon } from 'lucide-react';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { Bar, BarChart, Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Pie, PieChart, Cell } from 'recharts';
import { useToast } from "@/hooks/use-toast";

const monthlyLoansData = [
  { month: "Jan", loans: Math.floor(Math.random() * 50) + 10 },
  { month: "Fév", loans: Math.floor(Math.random() * 50) + 15 },
  { month: "Mar", loans: Math.floor(Math.random() * 50) + 20 },
  { month: "Avr", loans: Math.floor(Math.random() * 50) + 25 },
  { month: "Mai", loans: Math.floor(Math.random() * 50) + 30 },
  { month: "Juin", loans: Math.floor(Math.random() * 50) + 20 },
];

const popularGenresData = [
  { genre: "Science-Fiction", count: Math.floor(Math.random() * 30) + 10, fill: "hsl(var(--chart-1))" },
  { genre: "Roman", count: Math.floor(Math.random() * 30) + 15, fill: "hsl(var(--chart-2))" },
  { genre: "Histoire", count: Math.floor(Math.random() * 30) + 5, fill: "hsl(var(--chart-3))" },
  { genre: "Jeunesse", count: Math.floor(Math.random() * 30) + 12, fill: "hsl(var(--chart-4))" },
  { genre: "Mystère", count: Math.floor(Math.random() * 30) + 8, fill: "hsl(var(--chart-5))" },
];

const chartConfigMonthly = {
  loans: {
    label: "Emprunts",
    color: "hsl(var(--primary))",
  },
};

const chartConfigGenres = {
  count: {
    label: "Nombre d'emprunts",
  },
  "Science-Fiction": { label: "Science-Fiction", color: "hsl(var(--chart-1))" },
  "Roman": { label: "Roman", color: "hsl(var(--chart-2))" },
  "Histoire": { label: "Histoire", color: "hsl(var(--chart-3))" },
  "Jeunesse": { label: "Jeunesse", color: "hsl(var(--chart-4))" },
  "Mystère": { label: "Mystère", color: "hsl(var(--chart-5))" },
};


export default function StatistiquesPage() {
  const { toast } = useToast();

  const handleExportPDF = () => {
    toast({
      title: `Export en PDF (Fonctionnalité à venir)`,
      description: `La capacité de générer des rapports PDF détaillés sera ajoutée prochainement. Cette fonctionnalité avancée vous permettra d'exporter vos statistiques une fois les modules de gestion de la bibliothèque pleinement opérationnels.`,
      duration: 7000, // Increased duration for better readability
    });
  };

  const handleExportCSV = (dataToExport: any[], fileName: string) => {
    if (!dataToExport || dataToExport.length === 0) {
      toast({
        title: "Export CSV",
        description: "Aucune donnée simulée à exporter pour cette section.",
        variant: "destructive"
      });
      return;
    }

    const headers = Object.keys(dataToExport[0]);
    const csvContent = [
      headers.join(','),
      ...dataToExport.map(row => headers.map(header => String(row[header])).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${fileName}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({
        title: "Export CSV Réussi (Données Simulées)",
        description: `Le fichier ${fileName}.csv a été téléchargé avec les données de démonstration.`,
      });
    } else {
       toast({
        title: "Export CSV Échoué",
        description: "Votre navigateur ne supporte pas le téléchargement direct.",
        variant: "destructive"
      });
    }
  };

  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-background text-foreground">
      <h1 className="text-3xl font-semibold mb-6 text-foreground">Statistiques de la Bibliothèque</h1>

      <Alert className="mb-6 border-primary/50 bg-primary/5 text-primary">
        <Info className="h-5 w-5 !text-primary" />
        <AlertTitle className="text-primary font-semibold">Données Actuellement Simulées</AlertTitle>
        <AlertDescription className="text-primary/90">
          Veuillez noter que la plupart des graphiques et chiffres affichés sur cette page utilisent des données simulées à des fins de démonstration.
          Ces statistiques deviendront réelles et refléteront votre activité une fois que les modules de gestion des livres, lecteurs, et surtout des emprunts/retours seront pleinement opérationnels.
        </AlertDescription>
      </Alert>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-card shadow-lg col-span-1 md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <AreaChart className="mr-2 h-5 w-5 text-primary" />
              Livres Empruntés / Mois (Données Simulées)
            </CardTitle>
            <CardDescription>Évolution mensuelle des emprunts (simulation actuelle).</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfigMonthly} className="h-[250px] w-full">
              <LineChart data={monthlyLoansData} margin={{ left: 12, right: 12, top: 5, bottom: 5 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line dataKey="loans" type="monotone" stroke="var(--color-loans)" strokeWidth={2} dot={false} />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <PieChartIcon className="mr-2 h-5 w-5 text-primary" />
              Genres Populaires (Données Simulées)
            </CardTitle>
            <CardDescription>Répartition des emprunts par genre (simulation actuelle).</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ChartContainer config={chartConfigGenres} className="h-[250px] w-full aspect-square">
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent nameKey="count" hideLabel />} />
                <Pie data={popularGenresData} dataKey="count" nameKey="genre" labelLine={false} label={({ percent, genre }) => `${genre}: ${(percent * 100).toFixed(0)}%`}>
                  {popularGenresData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <ChartLegend content={<ChartLegendContent />} />
              </PieChart>
            </ChartContainer>
          </CardContent>
        </Card>
        
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <BookOpen className="mr-2 h-5 w-5 text-primary" />
              Top 10 Livres Lus (Simulation)
            </CardTitle>
            <CardDescription>Les livres les plus fréquemment empruntés (données fictives).</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="border-b border-border/50 pb-1">"Le Seigneur des Anneaux" - 25 emprunts</li>
              <li className="border-b border-border/50 pb-1">"Harry Potter à l'école des sorciers" - 22 emprunts</li>
              <li className="border-b border-border/50 pb-1">"1984" - 18 emprunts</li>
              <li className="border-b border-border/50 pb-1">"Dune" - 15 emprunts</li>
              <li className="pb-1 last:border-b-0 last:pb-0">"Orgueil et Préjugés" - 12 emprunts</li>
               <li>... (Données simulées)</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Users className="mr-2 h-5 w-5 text-primary" />
              Top 10 Lecteurs Actifs (Simulation)
            </CardTitle>
            <CardDescription>Les lecteurs avec le plus d'emprunts (données fictives).</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="border-b border-border/50 pb-1">Alice Dupont - 15 emprunts</li>
              <li className="border-b border-border/50 pb-1">Bob Martin - 12 emprunts</li>
              <li className="border-b border-border/50 pb-1">Carla Petit - 10 emprunts</li>
              <li className="border-b border-border/50 pb-1">David Moreau - 9 emprunts</li>
              <li className="pb-1 last:border-b-0 last:pb-0">Eva Bernard - 7 emprunts</li>
              <li>... (Données simulées)</li>
            </ul>
          </CardContent>
        </Card>
         <Card className="bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Percent className="mr-2 h-5 w-5 text-primary" />
              Taux de Retour à l'Heure (Simulation)
            </CardTitle>
            <CardDescription>Pourcentage des livres rendus à temps (données fictives).</CardDescription>
          </CardHeader>
          <CardContent>
             <p className="text-4xl font-bold text-primary text-center">85%</p>
             <p className="text-xs text-muted-foreground text-center mt-2">(Basé sur les données simulées du mois dernier)</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-card shadow-lg">
            <CardHeader>
                <CardTitle className="text-lg flex items-center">
                <ListChecks className="mr-2 h-5 w-5 text-primary" />
                Livres les plus Empruntés (Simulation Globale)
                </CardTitle>
                <CardDescription>Statistiques globales sur les emprunts (données fictives).</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-sm font-semibold">Total Emprunts (Simulé): <span className="text-primary">123</span></p>
                <p className="text-sm text-muted-foreground mt-1">Données plus détaillées à venir...</p>
            </CardContent>
        </Card>
        <Card className="bg-card shadow-lg">
            <CardHeader>
                <CardTitle className="text-lg flex items-center">
                <Clock className="mr-2 h-5 w-5 text-primary" />
                Heures d'Affluence (Simulation)
                </CardTitle>
                 <CardDescription>Pics d'activité simulés de la bibliothèque.</CardDescription>
            </CardHeader>
            <CardContent>
                 <p className="text-sm font-semibold">Pic habituel: <span className="text-primary">16h00 - 18h00</span></p>
                 <p className="text-sm text-muted-foreground mt-1">Analyse plus fine à venir...</p>
            </CardContent>
        </Card>
         <Card className="bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Download className="mr-2 h-5 w-5 text-primary" />
              Export des Rapports
            </CardTitle>
            <CardDescription>Téléchargez vos données statistiques.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col space-y-3">
            <Button variant="outline" onClick={handleExportPDF} className="w-full justify-start">
              <FileText className="mr-2 h-4 w-4" /> Exporter en PDF (Bientôt)
            </Button>
            <Button variant="outline" onClick={() => handleExportCSV(monthlyLoansData, 'emprunts_mensuels_simules')} className="w-full justify-start">
              <FileSpreadsheet className="mr-2 h-4 w-4" /> Exporter Emprunts/Mois (CSV)
            </Button>
             <Button variant="outline" onClick={() => handleExportCSV(popularGenresData.map(g => ({genre: g.genre, count: g.count})), 'genres_populaires_simules')} className="w-full justify-start">
              <FileSpreadsheet className="mr-2 h-4 w-4" /> Exporter Genres Populaires (CSV)
            </Button>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mb-6 bg-card shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-primary flex items-center">
            <Activity className="mr-2 h-6 w-6" />
            Détail des Fonctionnalités Prévues pour les Statistiques
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside text-muted-foreground space-y-2 text-sm text-left columns-1 md:columns-2">
            <li>Graphiques dynamiques (livres empruntés / mois, genre le plus populaire…) (Simulation actuelle avec graphiques visibles)</li>
            <li>Top 10 des livres les plus lus (Affichage de liste simulée)</li>
            <li>Top 10 des lecteurs les plus actifs (Affichage de liste simulée)</li>
            <li>Livres les plus empruntés (Indicateur avec données simulées)</li>
            <li>Heures d’affluence dans la bibliothèque (Indicateur avec données simulées)</li>
            <li>Taux de retour à l’heure (Indicateur avec données simulées)</li>
            <li>Statistiques de lecture (âge, catégorie, genre) (À venir)</li>
            <li>Export des rapports statistiques en PDF ou CSV (Export CSV de données simulées implémenté, PDF à venir)</li>
            <li>Comparaison des performances sur différentes périodes (À venir)</li>
            <li>Tableau de bord personnalisable avec les KPIs préférés (À venir)</li>
          </ul>
        </CardContent>
      </Card>

      <div className="flex gap-4 mt-auto justify-center">
        <Button variant="outline" asChild>
          <Link href="/bibliotheque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tableau de Bord Biblio
          </Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Accueil LUX-R
          </Link>
        </Button>
      </div>
    </main>
  );
}
