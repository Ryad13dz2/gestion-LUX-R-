
"use client";
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, Settings2, Palette, Database, Shield, Share2, FileText, Upload, DownloadCloud, CloudCog, Users, KeyRound, WifiOff, QrCode, MessageCircleQuestion, Printer, Languages, CheckSquare, Save, ListChecks, Clock, Book, UserPlus, FileSpreadsheet, UserCog } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import React, { useState, useEffect, ChangeEvent } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from "@/components/ui/checkbox";
import { useNotifications } from '@/contexts/NotificationContext';
import { ScrollArea } from '@/components/ui/scroll-area';


const LOCAL_STORAGE_BOOKS_KEY = 'luxr_library_books';
const LOCAL_STORAGE_LECTEURS_KEY = 'luxr_library_lecteurs';
const LOCAL_STORAGE_LOANS_KEY = 'luxr_library_loans';

interface Book {
  id: string;
  isbn?: string;
  title: string;
  author?: string;
  genre?: string;
  year?: string;
  quantity?: number;
  coverImage?: string;
  description?: string;
  publisher?: string;
  pageCount?: number;
}

interface Lecteur {
  id: string;
  nom: string;
  prenom: string;
  email?: string;
  photoUrl?: string;
  niveau?: string;
  estBloque?: boolean;
}

interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  readerId: string;
  readerName: string;
  loanDate: string;
  dueDate: string;
  returnDate?: string | null;
}


export default function ParametresPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isLabelPrinterDialogOpen, setIsLabelPrinterDialogOpen] = useState(false);
  const [isChatbotConfigDialogOpen, setIsChatbotConfigDialogOpen] = useState(false);
  const [isRestoreBackupDialogOpen, setIsRestoreBackupDialogOpen] = useState(false);
  const [isCloudBackupConfigDialogOpen, setIsCloudBackupConfigDialogOpen] = useState(false);
  const [isImportCsvDialogOpen, setIsImportCsvDialogOpen] = useState(false);
  const [isActionHistoryDialogOpen, setIsActionHistoryDialogOpen] = useState(false);
  const [isTwoFactorAuthDialogOpen, setIsTwoFactorAuthDialogOpen] = useState(false);
  const [isUserRolesDialogOpen, setIsUserRolesDialogOpen] = useState(false);
  const [selectedCsvFile, setSelectedCsvFile] = useState<File | null>(null);

  // State for Cloud Backup Dialog
  const [cloudProvider, setCloudProvider] = useState<string | undefined>("gdrive");
  const [autoCloudBackup, setAutoCloudBackup] = useState<boolean>(true);
  const [cloudBackupFrequency, setCloudBackupFrequency] = useState<string | undefined>("daily");

  // State for Chatbot Config Dialog
  const [chatbotEnabled, setChatbotEnabled] = useState(true);
  const [chatbotName, setChatbotName] = useState("BiblioBot");
  const [chatbotWelcomeMessage, setChatbotWelcomeMessage] = useState("Bonjour ! Comment puis-je vous aider avec la bibliothèque aujourd'hui ?");
  const [chatbotPersonality, setChatbotPersonality] = useState("amical");

  // State for Label Printer Config Dialog
  const [labelSize, setLabelSize] = useState("medium");
  const [includeBarcode, setIncludeBarcode] = useState(true);
  const [includeTitle, setIncludeTitle] = useState(true);
  const [includeAuthor, setIncludeAuthor] = useState(false);
  const [includeLibraryName, setIncludeLibraryName] = useState(false);
  const [customLine1, setCustomLine1] = useState("");
  const [customLine2, setCustomLine2] = useState("");

  // State for 2FA Dialog
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");


  const handleComingSoon = (feature: string) => {
    toast({
      title: "Fonctionnalité à venir",
      description: `${feature} sera bientôt disponible.`,
    });
  };

  const convertToCSV = (data: any[], headers: string[]) => {
    if (!data || data.length === 0) return "";
    const headerRow = headers.join(',');
    const dataRows = data.map(row =>
      headers.map(header => JSON.stringify(row[header] || "")).join(',')
    );
    return [headerRow, ...dataRows].join('\n');
  };

  const downloadCSV = (csvContent: string, fileName: string) => {
    if (!csvContent) {
      toast({ title: "Export CSV", description: "Aucune donnée à exporter.", variant: "destructive" });
      return;
    }
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${fileName}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Export CSV Réussi", description: `Le fichier ${fileName}.csv a été téléchargé.` });
    } else {
      toast({ title: "Export CSV Échoué", description: "Votre navigateur ne supporte pas le téléchargement direct.", variant: "destructive" });
    }
  };

  const handleExportAllLocalData = () => {
    try {
      const booksData: Book[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY) || '[]');
      const lecteursData: Lecteur[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LECTEURS_KEY) || '[]');
      const loansData: Loan[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LOANS_KEY) || '[]');

      if (booksData.length === 0 && lecteursData.length === 0 && loansData.length === 0) {
        toast({ title: "Export", description: "Aucune donnée locale à exporter.", variant: "default" });
        return;
      }
      
      let fullCsvContent = "";

      if (booksData.length > 0) {
        const bookHeaders = Object.keys(booksData[0] || {}).filter(key => key !== 'coverImage'); // Exclude coverImage DataURL from CSV
        fullCsvContent += "=== Livres ===\n";
        fullCsvContent += convertToCSV(booksData.map(b => ({...b, coverImage: b.coverImage?.startsWith('http') ? b.coverImage : undefined})), bookHeaders) + "\n\n";
      } else {
        fullCsvContent += "=== Livres ===\n (Aucune donnée)\n\n";
      }

      if (lecteursData.length > 0) {
        const lecteurHeaders = Object.keys(lecteursData[0] || {}).filter(key => key !== 'photoUrl'); // Exclude photoUrl DataURL
        fullCsvContent += "=== Lecteurs ===\n";
        fullCsvContent += convertToCSV(lecteursData.map(l => ({...l, photoUrl: l.photoUrl?.startsWith('http') ? l.photoUrl : undefined})), lecteurHeaders) + "\n\n";
      } else {
         fullCsvContent += "=== Lecteurs ===\n (Aucune donnée)\n\n";
      }
      
      if (loansData.length > 0) {
        const loanHeaders = Object.keys(loansData[0] || {});
        fullCsvContent += "=== Emprunts ===\n";
        fullCsvContent += convertToCSV(loansData, loanHeaders) + "\n\n";
      } else {
        fullCsvContent += "=== Emprunts ===\n (Aucune donnée)\n\n";
      }
      
      downloadCSV(fullCsvContent, 'luxr_bibliotheque_donnees_locales');

    } catch (error) {
      console.error("Erreur lors de l'export des données locales:", error);
      toast({ title: "Erreur d'Export", description: "Une erreur est survenue lors de la préparation des données pour l'export.", variant: "destructive" });
    }
  };

  const handleImportCsv = async () => {
    if (!selectedCsvFile) {
      toast({ title: "Aucun fichier sélectionné", description: "Veuillez sélectionner un fichier CSV à importer.", variant: "destructive" });
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const csvText = event.target?.result as string;
        if (!csvText) {
          toast({ title: "Erreur de lecture", description: "Impossible de lire le contenu du fichier.", variant: "destructive" });
          return;
        }

        const lines = csvText.split(/\r\n|\n/).filter(line => line.trim() !== '');
        if (lines.length < 2) {
          toast({ title: "Fichier CSV invalide", description: "Le fichier CSV doit contenir au moins une ligne d'en-tête et une ligne de données.", variant: "destructive" });
          return;
        }

        const headers = lines[0].split(',').map(header => header.trim().toLowerCase().replace(/\s+/g, '')); 
        
        const requiredHeaders = ['id', 'title'];
        const missingHeaders = requiredHeaders.filter(rh => !headers.includes(rh));
        if (missingHeaders.length > 0) {
            toast({ title: "Format CSV incorrect", description: `Les colonnes suivantes sont manquantes: ${missingHeaders.join(', ')}.`, variant: "destructive" });
            return;
        }

        const newBooks: Book[] = [];
        for (let i = 1; i < lines.length; i++) {
          const values = lines[i].match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g)?.map(value => {
            value = value.trim();
            if (value.startsWith('"') && value.endsWith('"')) {
              return value.substring(1, value.length - 1).replace(/""/g, '"'); 
            }
            return value;
          }) || [];

          const bookData: any = {};
          headers.forEach((header, index) => {
            bookData[header] = values[index] || ''; 
          });
          
          if (!bookData.id || !bookData.title) {
            console.warn(`Ligne ${i+1} ignorée: id ou titre manquant. Données:`, bookData);
            continue; 
          }

          const quantity = parseInt(bookData.quantity, 10);
          const pageCount = parseInt(bookData.pagecount, 10);

          newBooks.push({
            id: String(bookData.id),
            title: String(bookData.title),
            author: bookData.author ? String(bookData.author) : undefined,
            isbn: bookData.isbn ? String(bookData.isbn) : undefined,
            quantity: isNaN(quantity) ? 1 : quantity,
            coverImage: bookData.coverimage ? String(bookData.coverimage) : undefined, 
            description: bookData.description ? String(bookData.description) : undefined,
            publisher: bookData.publisher ? String(bookData.publisher) : undefined,
            pageCount: isNaN(pageCount) ? undefined : pageCount,
            year: bookData.year ? String(bookData.year) : undefined,
            genre: bookData.genre ? String(bookData.genre) : undefined,
          });
        }

        if (newBooks.length === 0) {
          toast({ title: "Aucun livre importé", description: "Aucun livre valide n'a été trouvé ou formaté correctement dans le fichier CSV.", variant: "default" });
          setIsImportCsvDialogOpen(false);
          setSelectedCsvFile(null);
          return;
        }

        const existingBooks: Book[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY) || '[]');
        const combinedBooks = [...existingBooks, ...newBooks];
        localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(combinedBooks));

        toast({ title: "Importation CSV Réussie", description: `${newBooks.length} livre(s) importé(s) avec succès dans le stock local.` });
        addNotification("Importation CSV (Livres)", `${newBooks.length} livre(s) importé(s) avec succès.`);
        setIsImportCsvDialogOpen(false);
        setSelectedCsvFile(null);

      } catch (error) {
        console.error("Erreur lors de l'importation CSV:", error);
        toast({ title: "Erreur d'Importation", description: "Une erreur est survenue lors du traitement du fichier CSV. Vérifiez le format du fichier et la console pour plus de détails.", variant: "destructive" });
      }
    };
    reader.onerror = () => {
        toast({ title: "Erreur de lecture de fichier", description: "Impossible de lire le fichier sélectionné.", variant: "destructive" });
    };
    reader.readAsText(selectedCsvFile);
  };

  const handleCloudBackupConfigSave = () => {
    toast({
      title: "Configuration Cloud (Simulation)",
      description: `Sauvegarde automatique ${autoCloudBackup ? 'activée' : 'désactivée'} sur ${cloudProvider || 'aucun fournisseur'}, fréquence ${cloudBackupFrequency || 'non définie'}.`,
    });
    setIsCloudBackupConfigDialogOpen(false);
  };

  const simulatedActions = [
    { id: '1', timestamp: '2024-07-22 10:15:30', user: 'Admin', type: 'Ajout Livre', description: 'Ajout du livre "Le Seigneur des Anneaux".' },
    { id: '2', timestamp: '2024-07-22 09:45:10', user: 'Admin', type: 'Modification Lecteur', description: 'Modification de la fiche de Alice Dupont.' },
    { id: '3', timestamp: '2024-07-21 16:20:05', user: 'Admin', type: 'Emprunt Enregistré', description: 'Livre "1984" emprunté par Bob Martin.' },
    { id: '4', timestamp: '2024-07-21 11:05:00', user: 'Admin', type: 'Retour Enregistré', description: 'Livre "Dune" retourné par Carla Petit.' },
    { id: '5', timestamp: '2024-07-20 14:30:00', user: 'Admin', type: 'Paramètre Modifié', description: 'Modification du thème de l\'interface.' },
  ];


  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-background text-foreground space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold text-foreground">Paramètres et Sécurité</h1>
        <Settings2 className="h-8 w-8 text-primary" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center"><Palette className="mr-2 h-5 w-5 text-primary" />Apparence</CardTitle>
            <CardDescription>Personnalisez l'apparence de l'application.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="theme-select">Thème de l'interface</Label>
              <Select defaultValue="light" disabled>
                <SelectTrigger id="theme-select" className="bg-input">
                  <SelectValue placeholder="Choisir un thème" />
                </SelectTrigger>
                <SelectContent className="bg-popover">
                  <SelectItem value="light">Clair (Actuel pour Biblio)</SelectItem>
                  <SelectItem value="dark">Sombre</SelectItem>
                  <SelectItem value="system">Système</SelectItem>
                </SelectContent>
              </Select>
               <p className="text-xs text-muted-foreground">Note: La section Bibliothèque force actuellement le thème clair.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="language-select">Langue de l'interface</Label>
              <Select disabled>
                <SelectTrigger id="language-select" className="bg-input">
                  <SelectValue placeholder="Choisir une langue" />
                </SelectTrigger>
                <SelectContent className="bg-popover">
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="en">Anglais</SelectItem>
                  <SelectItem value="ar">Arabe</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Multilingue bientôt disponible.</p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center"><Database className="mr-2 h-5 w-5 text-primary" />Gestion des Données</CardTitle>
            <CardDescription>Sauvegardez, exportez ou importez vos données.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="local-backup-switch" className="flex flex-col space-y-1">
                <span>Sauvegarde locale automatique</span>
                <span className="font-normal leading-snug text-muted-foreground text-xs">
                  (Simulation, fonctionnalité à venir)
                </span>
              </Label>
              <Switch id="local-backup-switch" disabled checked={true} />
            </div>
             <Button variant="outline" className="w-full justify-start" onClick={handleExportAllLocalData}>
              <FileSpreadsheet className="mr-2 h-4 w-4" /> Exporter Données Locales (CSV)
            </Button>
            
            <Dialog open={isImportCsvDialogOpen} onOpenChange={(open) => {
              setIsImportCsvDialogOpen(open);
              if (!open) setSelectedCsvFile(null);
            }}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <Upload className="mr-2 h-4 w-4" /> Importer des données Livres (CSV)
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <Upload className="mr-2 h-6 w-6 text-primary" /> Importer des Livres (CSV)
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Sélectionnez un fichier CSV pour importer des livres. La première ligne doit contenir les en-têtes. Colonnes attendues (insensibles à la casse):
                    <code className="block bg-muted p-1 rounded-sm text-xs my-1 whitespace-pre-wrap">id,title,author,isbn,quantity,coverImage,description,publisher,pageCount,year,genre</code>
                    Les colonnes `id` et `title` sont obligatoires.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-1">
                    <Label htmlFor="import-csv-file">Fichier CSV (.csv)</Label>
                    <Input 
                      id="import-csv-file" 
                      type="file" 
                      accept=".csv" 
                      className="bg-input" 
                      onChange={(e) => setSelectedCsvFile(e.target.files ? e.target.files[0] : null)}
                    />
                  </div>
                   {selectedCsvFile && <p className="text-xs text-muted-foreground">Fichier sélectionné : {selectedCsvFile.name}</p>}
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => {setIsImportCsvDialogOpen(false); setSelectedCsvFile(null);}}>Annuler</Button>
                  <Button onClick={handleImportCsv} disabled={!selectedCsvFile}>
                    <Upload className="mr-2 h-4 w-4" /> Importer les Livres
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            
             <Dialog open={isCloudBackupConfigDialogOpen} onOpenChange={(open) => {
                setIsCloudBackupConfigDialogOpen(open);
             }}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <CloudCog className="mr-2 h-4 w-4" /> Configurer Sauvegarde Cloud
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <CloudCog className="mr-2 h-6 w-6 text-primary" /> Configuration Sauvegarde Cloud
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Configurez la sauvegarde automatique de vos données sur un service cloud.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="cloud-provider">Fournisseur Cloud</Label>
                    <Select value={cloudProvider} onValueChange={setCloudProvider}>
                      <SelectTrigger id="cloud-provider" className="bg-input">
                        <SelectValue placeholder="Choisir un fournisseur..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover">
                        <SelectItem value="gdrive">Google Drive</SelectItem>
                        <SelectItem value="dropbox">Dropbox</SelectItem>
                        <SelectItem value="personal">Serveur Personnel (Bientôt)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="auto-cloud-backup" checked={autoCloudBackup} onCheckedChange={setAutoCloudBackup} />
                    <Label htmlFor="auto-cloud-backup">Activer la sauvegarde automatique</Label>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cloud-backup-frequency">Fréquence de sauvegarde</Label>
                    <Select value={cloudBackupFrequency} onValueChange={setCloudBackupFrequency} disabled={!autoCloudBackup}>
                      <SelectTrigger id="cloud-backup-frequency" className="bg-input">
                        <SelectValue placeholder="Choisir une fréquence..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover">
                        <SelectItem value="daily">Quotidienne</SelectItem>
                        <SelectItem value="weekly">Hebdomadaire</SelectItem>
                        <SelectItem value="monthly">Mensuelle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button variant="outline" className="w-full" disabled>
                    <Save className="mr-2 h-4 w-4" /> Lancer une sauvegarde manuelle (Bientôt)
                  </Button>
                   <p className="text-xs text-muted-foreground">
                    La sauvegarde réelle sur le cloud n'est pas encore implémentée. Ceci simule la configuration.
                  </p>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => {
                      setIsCloudBackupConfigDialogOpen(false);
                  }}>Annuler</Button>
                  <Button onClick={handleCloudBackupConfigSave}>
                    Sauvegarder (Simulation)
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isRestoreBackupDialogOpen} onOpenChange={setIsRestoreBackupDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <DownloadCloud className="mr-2 h-4 w-4" /> Restaurer depuis Sauvegarde
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <DownloadCloud className="mr-2 h-6 w-6 text-primary" /> Restaurer les Données
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Sélectionnez un fichier de sauvegarde (précédemment exporté) pour restaurer vos données.
                    Attention : cette opération peut écraser les données locales existantes. (Simulation actuelle)
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-1">
                    <Label htmlFor="backup-file">Fichier de sauvegarde</Label>
                    <Input id="backup-file" type="file" accept=".csv,.json" className="bg-input" />
                    <p className="text-xs text-muted-foreground">Formats supportés (simulation) : .csv, .json.</p>
                  </div>
                  <p className="text-xs text-primary bg-primary/10 p-2 rounded-md">
                    <strong>Note importante :</strong> La fonctionnalité de restauration réelle des données à partir d'un fichier n'est pas encore implémentée.
                    Ceci est une simulation de l'interface.
                  </p>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => setIsRestoreBackupDialogOpen(false)}>Annuler</Button>
                  <Button onClick={() => {
                    toast({ title: "Simulation de Restauration", description: "La restauration des données a été simulée. Aucune donnée n'a été modifiée." });
                    setIsRestoreBackupDialogOpen(false);
                  }}>
                    Lancer la Restauration (Simulation)
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center"><Shield className="mr-2 h-5 w-5 text-primary" />Sécurité (Illustratif)</CardTitle>
            <CardDescription>Gérez les accès et la sécurité de l'application.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
             <Dialog open={isUserRolesDialogOpen} onOpenChange={setIsUserRolesDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <UserCog className="mr-2 h-4 w-4" /> Gérer Utilisateurs et Rôles
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <UserCog className="mr-2 h-6 w-6 text-primary" /> Gestion des Utilisateurs et Rôles
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Cette section permettrait de créer et gérer les comptes utilisateurs (admin, bibliothécaire, assistant) et leurs permissions spécifiques au sein de l'application.
                    (Fonctionnalité avancée à venir)
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="p-4 bg-muted rounded-md text-center">
                    <p className="text-sm text-muted-foreground">Interface de gestion des utilisateurs et des rôles ici.</p>
                    <Button variant="secondary" className="mt-2" disabled>Ajouter un utilisateur (Bientôt)</Button>
                  </div>
                   <p className="text-xs text-primary bg-primary/10 p-2 rounded-md">
                    <strong>Note :</strong> La gestion complète des utilisateurs et des rôles avec des permissions détaillées est une fonctionnalité avancée qui nécessite une infrastructure backend. Ceci est une illustration.
                  </p>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsUserRolesDialogOpen(false)}>Fermer</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
             <Dialog open={isTwoFactorAuthDialogOpen} onOpenChange={setIsTwoFactorAuthDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <KeyRound className="mr-2 h-4 w-4" /> Configurer 2FA
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <KeyRound className="mr-2 h-6 w-6 text-primary" /> Configurer l'Authentification à Deux Facteurs (2FA)
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Renforcez la sécurité de votre compte en activant la 2FA.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-6">
                  <div className="flex items-center space-x-2">
                    <Switch id="activer-2fa" checked={twoFactorEnabled} onCheckedChange={setTwoFactorEnabled} />
                    <Label htmlFor="activer-2fa">Activer l'Authentification à Deux Facteurs</Label>
                  </div>
                  {twoFactorEnabled && (
                    <>
                      <div className="flex flex-col items-center space-y-2">
                        <p className="text-sm text-muted-foreground">Scannez ce QR code avec votre application d'authentification :</p>
                        <div className="w-32 h-32 bg-muted flex items-center justify-center rounded-md">
                          <QrCode className="h-20 w-20 text-muted-foreground" />
                        </div>
                         <p className="text-xs text-muted-foreground">(Ceci est un QR code factice)</p>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="verification-code">Entrez le code de vérification</Label>
                        <Input 
                          id="verification-code" 
                          value={verificationCode} 
                          onChange={(e) => setVerificationCode(e.target.value)} 
                          placeholder="Code à 6 chiffres" 
                          className="bg-input"
                          maxLength={6}
                        />
                      </div>
                    </>
                  )}
                  <p className="text-xs text-primary bg-primary/10 p-2 rounded-md">
                    <strong>Note :</strong> Ceci est une simulation de l'interface de configuration 2FA. Aucune fonctionnalité 2FA réelle n'est activée.
                  </p>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => setIsTwoFactorAuthDialogOpen(false)}>Annuler</Button>
                  <Button 
                    onClick={() => {
                      if (twoFactorEnabled && !verificationCode) {
                        toast({ title: "Code Requis", description: "Veuillez entrer un code de vérification.", variant: "destructive"});
                        return;
                      }
                      toast({ title: "Simulation 2FA", description: `Configuration 2FA ${twoFactorEnabled ? 'activée' : 'désactivée'} (simulation).` });
                      setIsTwoFactorAuthDialogOpen(false);
                    }}
                  >
                    {twoFactorEnabled ? "Vérifier et Activer (Simulation)" : "Sauvegarder (Simulation)"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={isActionHistoryDialogOpen} onOpenChange={setIsActionHistoryDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <ListChecks className="mr-2 h-4 w-4" /> Voir Historique des Actions
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <ListChecks className="mr-2 h-6 w-6 text-primary" /> 
                    Historique des Actions (Exemples)
                  </DialogTitle>
                  <DialogDescription className="mt-1 text-sm text-muted-foreground">
                    Ceci est un aperçu simulé de l'historique des actions. La journalisation réelle sera implémentée ultérieurement.
                  </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-72 mt-4 pr-3">
                  <ul className="space-y-3">
                    {simulatedActions.map(action => (
                      <li key={action.id} className="p-2 border rounded-md bg-muted/30 hover:bg-muted/50 transition-colors">
                        <div className="flex justify-between items-center">
                           <span className="font-medium text-sm text-foreground">{action.type}</span>
                           <span className="text-xs text-muted-foreground">{action.timestamp}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">Utilisateur: <span className="text-foreground/80">{action.user}</span></p>
                        <p className="text-xs text-muted-foreground mt-0.5">{action.description}</p>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
                <DialogFooter className="mt-4">
                  <Button variant="outline" onClick={() => setIsActionHistoryDialogOpen(false)}>Fermer</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        <Card className="shadow-lg md:col-span-1 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg flex items-center"><Settings2 className="mr-2 h-5 w-5 text-primary" />Fonctionnalités Avancées</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="offline-mode-switch" className="flex flex-col space-y-1">
                <span>Mode hors ligne (PWA)</span>
                 <span className="font-normal leading-snug text-muted-foreground text-xs">
                  (Fonctionnalité à venir)
                </span>
              </Label>
              <Switch id="offline-mode-switch" disabled />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="qr-code-switch" className="flex flex-col space-y-1">
                <span>Lecture de QR codes (téléphone)</span>
                 <span className="font-normal leading-snug text-muted-foreground text-xs">
                  (Fonctionnalité à venir)
                </span>
              </Label>
              <Switch id="qr-code-switch" disabled />
            </div>
             <Dialog open={isChatbotConfigDialogOpen} onOpenChange={setIsChatbotConfigDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <MessageCircleQuestion className="mr-2 h-4 w-4" /> Configurer Chatbot d'Aide
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <MessageCircleQuestion className="mr-2 h-6 w-6 text-primary" /> Configurer le Chatbot d'Aide
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Personnalisez le comportement et l'apparence de votre assistant IA.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="activer-chatbot" checked={chatbotEnabled} onCheckedChange={setChatbotEnabled} />
                    <Label htmlFor="activer-chatbot">Activer le chatbot d'aide</Label>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="chatbot-nom">Nom du chatbot</Label>
                    <Input id="chatbot-nom" value={chatbotName} onChange={(e) => setChatbotName(e.target.value)} placeholder="Ex: BiblioBot" className="bg-input" />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="chatbot-accueil">Message d'accueil</Label>
                    <Textarea id="chatbot-accueil" value={chatbotWelcomeMessage} onChange={(e) => setChatbotWelcomeMessage(e.target.value)} placeholder="Ex: Bonjour ! Comment puis-je vous aider avec la bibliothèque aujourd'hui ?" className="bg-input" rows={3}/>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="chatbot-personnalite">Personnalité du chatbot</Label>
                    <Select value={chatbotPersonality} onValueChange={setChatbotPersonality}>
                      <SelectTrigger id="chatbot-personnalite" className="bg-input">
                        <SelectValue placeholder="Choisir une personnalité" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover">
                        <SelectItem value="amical">Amical et serviable</SelectItem>
                        <SelectItem value="professionnel">Professionnel et direct</SelectItem>
                        <SelectItem value="concis">Concis et efficace</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                   <Button variant="outline" className="w-full justify-start" disabled>
                      <Database className="mr-2 h-4 w-4" /> Gérer la base de connaissances (Bientôt)
                   </Button>
                  <p className="text-xs text-muted-foreground">Ces paramètres sont interactifs. La sauvegarde réelle et l'impact sur un chatbot fonctionnel seront implémentés ultérieurement.</p>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => setIsChatbotConfigDialogOpen(false)}>Annuler</Button>
                  <Button onClick={() => {
                    toast({ title: "Simulation", description: `Chatbot ${chatbotEnabled ? 'activé' : 'désactivé'}. Nom: ${chatbotName}. Message: "${chatbotWelcomeMessage.substring(0,20)}...". Personnalité: ${chatbotPersonality}.`});
                    setIsChatbotConfigDialogOpen(false);
                  }}>
                    Sauvegarder (Simulation)
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isLabelPrinterDialogOpen} onOpenChange={setIsLabelPrinterDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <Printer className="mr-2 h-4 w-4" /> Imprimante d'Étiquettes
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <Printer className="mr-2 h-6 w-6 text-primary" /> Configuration d'Impression d'Étiquettes
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    Définissez les options pour la génération d'étiquettes. L'impression réelle dépendra de votre configuration matérielle.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-6 max-h-[60vh] overflow-y-auto pr-2">
                  <div className="space-y-2">
                    <Label htmlFor="label-size">Taille de l'étiquette</Label>
                    <Select value={labelSize} onValueChange={setLabelSize}>
                      <SelectTrigger id="label-size" className="bg-input">
                        <SelectValue placeholder="Choisir une taille..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover">
                        <SelectItem value="small">Petite (ex: 30mm x 60mm)</SelectItem>
                        <SelectItem value="medium">Moyenne (ex: 40mm x 80mm)</SelectItem>
                        <SelectItem value="large">Grande (ex: 50mm x 100mm)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label>Informations à inclure :</Label>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-barcode" checked={includeBarcode} onCheckedChange={(checked) => setIncludeBarcode(Boolean(checked))} />
                      <Label htmlFor="include-barcode" className="font-normal">Inclure Code-barres (ISBN)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-title" checked={includeTitle} onCheckedChange={(checked) => setIncludeTitle(Boolean(checked))} />
                      <Label htmlFor="include-title" className="font-normal">Inclure Titre du livre</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-author" checked={includeAuthor} onCheckedChange={(checked) => setIncludeAuthor(Boolean(checked))} />
                      <Label htmlFor="include-author" className="font-normal">Inclure Auteur(s)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-library-name" checked={includeLibraryName} onCheckedChange={(checked) => setIncludeLibraryName(Boolean(checked))} />
                      <Label htmlFor="include-library-name" className="font-normal">Inclure Nom de la bibliothèque</Label>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="custom-line-1">Ligne personnalisée 1 (optionnel)</Label>
                    <Input id="custom-line-1" value={customLine1} onChange={(e) => setCustomLine1(e.target.value)} placeholder="Ex: Section Jeunesse" className="bg-input"/>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="custom-line-2">Ligne personnalisée 2 (optionnel)</Label>
                    <Input id="custom-line-2" value={customLine2} onChange={(e) => setCustomLine2(e.target.value)} placeholder="Ex: À retourner avant le..." className="bg-input"/>
                  </div>

                  <Button variant="outline" className="w-full justify-start" disabled>
                    <CheckSquare className="mr-2 h-4 w-4" /> Prévisualiser l'étiquette (Bientôt)
                  </Button>
                   <p className="text-xs text-muted-foreground">Ces réglages sont pour la génération de fichier (ex: PDF) à imprimer. La connexion directe à une imprimante n'est pas prise en charge.</p>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button variant="outline" onClick={() => setIsLabelPrinterDialogOpen(false)}>Annuler</Button>
                  <Button onClick={() => {
                     toast({ title: "Simulation", description: "Réglages d'impression d'étiquettes (simulation) sauvegardés."});
                     setIsLabelPrinterDialogOpen(false);
                  }}>
                    Sauvegarder Réglages (Simulation)
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6 bg-card shadow-lg">
        <CardHeader>
            <CardTitle className="text-xl text-primary flex items-center">
                <Settings2 className="mr-2 h-6 w-6" />
                Autres Fonctionnalités Prévues pour les Paramètres
            </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside text-muted-foreground space-y-1 text-sm">
            <li>Droits d’accès personnalisés pour chaque rôle</li>
            <li>Connexion par mot de passe ou QR code</li>
            <li>Historique des actions (log d’activité des utilisateurs) (Aperçu simulé disponible)</li>
            <li>Interface de restauration facile des données (Interface de simulation disponible)</li>
            <li>Interface adaptée aux utilisateurs étrangers ou bilingues (Sélecteur de langue simulé)</li>
            <li>Version responsive (déjà en place) et PWA installable (conceptuellement)</li>
            <li>Activation/Configuration de la lecture de QR codes depuis téléphone (Simulation)</li>
            <li>Paramètres pour l’affichage en mode kiosque (À venir)</li>
            <li>Intégration avec imprimante d’étiquettes (Interface de configuration simulée disponible)</li>
            <li>Catalogue public en ligne (À venir)</li>
          </ul>
        </CardContent>
      </Card>

      <div className="mt-auto pt-6 flex gap-4 justify-center">
        <Button variant="outline" asChild>
          <Link href="/bibliotheque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tableau de Bord Biblio
          </Link>
        </Button>
      </div>
    </main>
  );
}


    