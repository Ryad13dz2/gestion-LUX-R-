
"use client";
import Link from 'next/link';
import React, { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, ArrowRightLeft, CalendarDays, ScanLine, BellRing, PlusCircle, Undo2, Info, Book, User, Camera, CheckCircle, XCircle, Settings, Loader2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNotifications } from '@/contexts/NotificationContext';
import { addWeeks, format, parseISO } from 'date-fns';
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";

interface Book {
  id: string;
  isbn?: string;
  title: string;
  author?: string;
  genre?: string;
  year?: string;
  quantity?: number;
  coverImage?: string;
  description?: string;
  publisher?: string;
  pageCount?: number;
}

interface Lecteur {
  id: string;
  nom: string;
  prenom: string;
  email?: string;
  photoUrl?: string;
  niveau?: string;
  estBloque?: boolean;
}

interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  readerId: string;
  readerName: string;
  loanDate: string;
  dueDate: string;
  returnDate?: string | null;
}

const LOCAL_STORAGE_BOOKS_KEY = 'luxr_library_books';
const LOCAL_STORAGE_LECTEURS_KEY = 'luxr_library_lecteurs';
const LOCAL_STORAGE_LOANS_KEY = 'luxr_library_loans';

export default function EmpruntsPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();

  const [isEmpruntDialogOpen, setIsEmpruntDialogOpen] = useState(false);
  const [isRetourDialogOpen, setIsRetourDialogOpen] = useState(false);
  const [isSaisieRapideDialogOpen, setIsSaisieRapideDialogOpen] = useState(false);
  const [isAlertesConfigDialogOpen, setIsAlertesConfigDialogOpen] = useState(false);
  const [isPenalitesConfigDialogOpen, setIsPenalitesConfigDialogOpen] = useState(false);

  const [allBooks, setAllBooks] = useState<Book[]>([]);
  const [allReaders, setAllReaders] = useState<Lecteur[]>([]);
  const [activeLoans, setActiveLoans] = useState<Loan[]>([]);
  const [selectedBookId, setSelectedBookId] = useState<string | undefined>(undefined);
  const [selectedReaderId, setSelectedReaderId] = useState<string | undefined>(undefined);
  const [selectedLoanIdToReturn, setSelectedLoanIdToReturn] = useState<string | undefined>(undefined);
  
  const [isSubmittingQuickLoan, setIsSubmittingQuickLoan] = useState(false);
  const [isSubmittingNouvelEmprunt, setIsSubmittingNouvelEmprunt] = useState(false);
  const [isSubmittingReturn, setIsSubmittingReturn] = useState(false);


  useEffect(() => {
    if (isSaisieRapideDialogOpen || isEmpruntDialogOpen || isRetourDialogOpen) {
      // Load books
      try {
        const storedBooks = localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY);
        if (storedBooks) {
          const parsedBooks: Book[] = JSON.parse(storedBooks);
          // For loan dialogs, only show books with quantity > 0. For return dialog, all books might be relevant if we need to look up details, but it's not used directly for selection.
          setAllBooks(isRetourDialogOpen ? parsedBooks : parsedBooks.filter(book => (book.quantity ?? 0) > 0));
        } else {
          setAllBooks([]);
        }
      } catch (error) {
        console.error("Error loading books for dialog:", error);
        setAllBooks([]);
      }

      // Load readers
      try {
        const storedReaders = localStorage.getItem(LOCAL_STORAGE_LECTEURS_KEY);
        if (storedReaders) {
          setAllReaders(JSON.parse(storedReaders));
        } else {
          setAllReaders([]);
        }
      } catch (error) {
        console.error("Error loading readers for dialog:", error);
        setAllReaders([]);
      }

      // Load active loans for return dialog
      if (isRetourDialogOpen) {
        try {
          const storedLoans = localStorage.getItem(LOCAL_STORAGE_LOANS_KEY);
          if (storedLoans) {
            const parsedLoans: Loan[] = JSON.parse(storedLoans);
            setActiveLoans(parsedLoans.filter(loan => !loan.returnDate));
          } else {
            setActiveLoans([]);
          }
        } catch (error) {
          console.error("Error loading active loans for return dialog:", error);
          setActiveLoans([]);
        }
      }
    }
  }, [isSaisieRapideDialogOpen, isEmpruntDialogOpen, isRetourDialogOpen]);

  const resetLoanDetailsForm = () => {
    setSelectedBookId(undefined);
    setSelectedReaderId(undefined);
    setSelectedLoanIdToReturn(undefined);
  }

  const handleSaisieRapideSubmit = () => {
    if (!selectedBookId || !selectedReaderId) {
      toast({
        title: "Sélection manquante",
        description: "Veuillez sélectionner un livre et un lecteur.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmittingQuickLoan(true);

    const book = allBooks.find(b => b.id === selectedBookId);
    const reader = allReaders.find(r => r.id === selectedReaderId);

    if (!book || !reader) {
      toast({
        title: "Erreur de données",
        description: "Livre ou lecteur non trouvé. Veuillez réessayer.",
        variant: "destructive",
      });
      setIsSubmittingQuickLoan(false);
      return;
    }

    if ((book.quantity ?? 0) <= 0) {
       toast({
        title: "Livre non disponible",
        description: `Le livre "${book.title}" n'est plus en stock.`,
        variant: "destructive",
      });
      setIsSubmittingQuickLoan(false);
      return;
    }

    const loanDate = new Date();
    const dueDate = addWeeks(loanDate, 2);
    const newLoan: Loan = {
      id: Date.now().toString(),
      bookId: book.id,
      bookTitle: book.title,
      readerId: reader.id,
      readerName: `${reader.prenom} ${reader.nom}`,
      loanDate: loanDate.toISOString(),
      dueDate: dueDate.toISOString(),
    };

    const currentBooks: Book[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY) || '[]');
    const updatedBooks = currentBooks.map(b => 
      b.id === book.id ? { ...b, quantity: (b.quantity ?? 1) - 1 } : b
    );
    localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(updatedBooks));
    setAllBooks(updatedBooks.filter(b => (b.quantity ?? 0) > 0));

    const currentLoans: Loan[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LOANS_KEY) || '[]');
    localStorage.setItem(LOCAL_STORAGE_LOANS_KEY, JSON.stringify([newLoan, ...currentLoans]));
    
    toast({
      title: "Emprunt enregistré (Saisie Rapide)!",
      description: `Le livre "${book.title}" a été emprunté par ${reader.prenom} ${reader.nom}. Retour prévu le ${format(dueDate, 'dd/MM/yyyy')}.`,
      className: "bg-green-100 text-green-800 border-green-300",
      duration: 5000,
    });
    addNotification("Nouvel Emprunt (Rapide)", `"${book.title}" emprunté par ${reader.prenom} ${reader.nom}.`);
    
    setIsSubmittingQuickLoan(false);
    setIsSaisieRapideDialogOpen(false);
    resetLoanDetailsForm();
  };

  const handleNouvelEmpruntSubmit = () => {
    if (!selectedBookId || !selectedReaderId) {
      toast({
        title: "Sélection manquante",
        description: "Veuillez sélectionner un livre et un lecteur.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmittingNouvelEmprunt(true);

    const currentBooksFromStorage: Book[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY) || '[]');
    const bookFromStorage = currentBooksFromStorage.find(b => b.id === selectedBookId);
    const reader = allReaders.find(r => r.id === selectedReaderId);


    if (!bookFromStorage || !reader) {
      toast({
        title: "Erreur de données",
        description: "Livre ou lecteur non trouvé. Veuillez réessayer.",
        variant: "destructive",
      });
      setIsSubmittingNouvelEmprunt(false);
      return;
    }

    if ((bookFromStorage.quantity ?? 0) <= 0) {
       toast({
        title: "Livre non disponible (Vérification finale)",
        description: `Le livre "${bookFromStorage.title}" n'est plus en stock. La liste a peut-être été mise à jour.`,
        variant: "destructive",
      });
      setIsSubmittingNouvelEmprunt(false);
      const updatedBooksList = currentBooksFromStorage.filter(b => (b.quantity ?? 0) > 0);
      setAllBooks(updatedBooksList);
      return;
    }
    
    const loanDate = new Date();
    const dueDate = addWeeks(loanDate, 2);
    const newLoan: Loan = {
      id: Date.now().toString(),
      bookId: bookFromStorage.id,
      bookTitle: bookFromStorage.title,
      readerId: reader.id,
      readerName: `${reader.prenom} ${reader.nom}`,
      loanDate: loanDate.toISOString(),
      dueDate: dueDate.toISOString(),
    };
    
    const updatedBooks = currentBooksFromStorage.map(b => 
      b.id === bookFromStorage.id ? { ...b, quantity: (b.quantity ?? 1) - 1 } : b
    );
    localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(updatedBooks));
    setAllBooks(updatedBooks.filter(b => (b.quantity ?? 0) > 0));


    const currentLoans: Loan[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LOANS_KEY) || '[]');
    localStorage.setItem(LOCAL_STORAGE_LOANS_KEY, JSON.stringify([newLoan, ...currentLoans]));
    
    toast({
      title: "Nouvel Emprunt Enregistré !",
      description: `Le livre "${bookFromStorage.title}" a été emprunté par ${reader.prenom} ${reader.nom}. Retour prévu le ${format(dueDate, 'dd/MM/yyyy')}.`,
      className: "bg-green-100 text-green-800 border-green-300",
      duration: 5000,
    });
    addNotification("Nouvel Emprunt", `"${bookFromStorage.title}" emprunté par ${reader.prenom} ${reader.nom}.`);
    
    setIsSubmittingNouvelEmprunt(false);
    setIsEmpruntDialogOpen(false);
    resetLoanDetailsForm();
  };

  const handleReturnSubmit = () => {
    if (!selectedLoanIdToReturn) {
      toast({
        title: "Sélection manquante",
        description: "Veuillez sélectionner un emprunt à retourner.",
        variant: "destructive",
      });
      return;
    }
    setIsSubmittingReturn(true);

    const currentLoans: Loan[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_LOANS_KEY) || '[]');
    const loanToReturn = currentLoans.find(loan => loan.id === selectedLoanIdToReturn);

    if (!loanToReturn) {
      toast({
        title: "Erreur",
        description: "Emprunt non trouvé. Il a peut-être déjà été retourné ou supprimé.",
        variant: "destructive",
      });
      setIsSubmittingReturn(false);
      setActiveLoans(currentLoans.filter(loan => !loan.returnDate)); // Refresh list
      return;
    }

    const updatedLoans = currentLoans.map(loan =>
      loan.id === selectedLoanIdToReturn ? { ...loan, returnDate: new Date().toISOString() } : loan
    );
    localStorage.setItem(LOCAL_STORAGE_LOANS_KEY, JSON.stringify(updatedLoans));

    // Update book quantity
    const currentBooks: Book[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BOOKS_KEY) || '[]');
    const updatedBooks = currentBooks.map(book =>
      book.id === loanToReturn.bookId ? { ...book, quantity: (book.quantity ?? 0) + 1 } : book
    );
    localStorage.setItem(LOCAL_STORAGE_BOOKS_KEY, JSON.stringify(updatedBooks));
    
    toast({
      title: "Retour Traité !",
      description: `Le livre "${loanToReturn.bookTitle}" a été marqué comme retourné.`,
      className: "bg-green-100 text-green-800 border-green-300",
    });
    addNotification("Retour de Livre", `"${loanToReturn.bookTitle}" retourné par ${loanToReturn.readerName}.`);

    setIsSubmittingReturn(false);
    setIsRetourDialogOpen(false);
    resetLoanDetailsForm();
    setActiveLoans(updatedLoans.filter(loan => !loan.returnDate)); // Refresh the list of active loans for the dialog
  };


  return (
    <main className="p-4 md:p-6 flex-1 flex flex-col bg-background text-foreground">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold text-foreground">Gestion des Emprunts et Retours</h1>
        <div className="flex gap-2">
          <Dialog open={isEmpruntDialogOpen} onOpenChange={(open) => {
            setIsEmpruntDialogOpen(open);
            if (!open) resetLoanDetailsForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-5 w-5" />
                Nouvel Emprunt
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-card text-card-foreground">
              <DialogHeader>
                <DialogTitle>Enregistrer un Nouvel Emprunt</DialogTitle>
                <DialogDescription>
                  Sélectionnez un livre disponible et un lecteur actif pour enregistrer un nouvel emprunt.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nouvel-emprunt-select-livre" className="flex items-center">
                    <Book className="mr-2 h-4 w-4" /> Sélectionner un Livre
                  </Label>
                  <Select value={selectedBookId} onValueChange={setSelectedBookId}>
                    <SelectTrigger id="nouvel-emprunt-select-livre" className="w-full bg-input text-foreground">
                      <SelectValue placeholder="Choisir un livre disponible..." />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {allBooks.length > 0 ? (
                        allBooks.map(book => (
                          <SelectItem key={book.id} value={book.id} disabled={(book.quantity ?? 0) <= 0}>
                            {book.title} (Stock: {book.quantity ?? 0})
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-books" disabled>Aucun livre disponible ou chargé</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nouvel-emprunt-select-lecteur" className="flex items-center">
                    <User className="mr-2 h-4 w-4" /> Sélectionner un Lecteur
                  </Label>
                  <Select value={selectedReaderId} onValueChange={setSelectedReaderId}>
                    <SelectTrigger id="nouvel-emprunt-select-lecteur" className="w-full bg-input text-foreground">
                      <SelectValue placeholder="Choisir un lecteur..." />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {allReaders.length > 0 ? (
                         allReaders.map(reader => (
                          <SelectItem key={reader.id} value={reader.id}>
                            {reader.prenom} {reader.nom}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-readers" disabled>Aucun lecteur enregistré ou chargé</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter className="sm:justify-between">
                <Button type="button" variant="outline" onClick={() => {setIsEmpruntDialogOpen(false); resetLoanDetailsForm();}}>Annuler</Button>
                <Button 
                  type="button" 
                  onClick={handleNouvelEmpruntSubmit} 
                  disabled={!selectedBookId || !selectedReaderId || isSubmittingNouvelEmprunt}
                >
                  {isSubmittingNouvelEmprunt ? <Loader2 className="animate-spin mr-2" /> : null}
                  {isSubmittingNouvelEmprunt ? 'Enregistrement...' : 'Valider l\'Emprunt'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isRetourDialogOpen} onOpenChange={(open) => {
            setIsRetourDialogOpen(open);
            if (!open) resetLoanDetailsForm();
          }}>
            <DialogTrigger asChild>
              <Button variant="secondary">
                <Undo2 className="mr-2 h-5 w-5" />
                Traiter un Retour
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-card text-card-foreground">
              <DialogHeader>
                <DialogTitle>Traiter un Retour de Livre</DialogTitle>
                <DialogDescription>
                  Sélectionnez un emprunt en cours pour le marquer comme retourné.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                 <div className="space-y-2">
                  <Label htmlFor="retour-select-emprunt" className="flex items-center">
                    <ArrowRightLeft className="mr-2 h-4 w-4" /> Sélectionner un Emprunt
                  </Label>
                  <Select value={selectedLoanIdToReturn} onValueChange={setSelectedLoanIdToReturn}>
                    <SelectTrigger id="retour-select-emprunt" className="w-full bg-input text-foreground">
                      <SelectValue placeholder="Choisir un emprunt à retourner..." />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {activeLoans.length > 0 ? (
                        activeLoans.map(loan => (
                          <SelectItem key={loan.id} value={loan.id}>
                            {loan.bookTitle} - par {loan.readerName} (Emprunté le: {format(parseISO(loan.loanDate), 'dd/MM/yyyy')})
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-active-loans" disabled>Aucun emprunt en cours</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                 <p className="text-xs text-muted-foreground">
                    Fonctionnalités à venir : Notation de l'état du livre (bon, abîmé, perdu).
                  </p>
              </div>
              <DialogFooter className="sm:justify-between">
                 <Button type="button" variant="outline" onClick={() => {setIsRetourDialogOpen(false); resetLoanDetailsForm();}}>Annuler</Button>
                <Button 
                  type="button" 
                  onClick={handleReturnSubmit} 
                  disabled={!selectedLoanIdToReturn || isSubmittingReturn}
                >
                  {isSubmittingReturn ? <Loader2 className="animate-spin mr-2" /> : null}
                  {isSubmittingReturn ? 'Traitement...' : 'Confirmer le Retour'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <ScanLine className="mr-2 h-5 w-5 text-primary" />
              Saisie Rapide d'Emprunt
            </CardTitle>
            <CardDescription>Sélection manuelle d'un livre et d'un lecteur.</CardDescription>
          </CardHeader>
          <CardContent>
            <Dialog open={isSaisieRapideDialogOpen} onOpenChange={(open) => {
              setIsSaisieRapideDialogOpen(open);
              if (!open) resetLoanDetailsForm();
            }}>
              <DialogTrigger asChild>
                <Button className="w-full">
                  Lancer la Saisie Rapide
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="flex items-center">
                    <ScanLine className="mr-2 h-6 w-6 text-primary" /> Saisie Rapide : Nouvel Emprunt
                  </DialogTitle>
                  <DialogDescription>
                    Sélectionnez un livre et un lecteur pour enregistrer un nouvel emprunt.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="scan-input" className="flex items-center">
                      <Camera className="mr-2 h-4 w-4" /> Scanner ISBN / Badge Lecteur (Simulation)
                    </Label>
                    <Input id="scan-input" placeholder="Scan non actif, utilisez les sélections manuelles." disabled className="bg-muted/50 cursor-not-allowed" />
                     <p className="text-xs text-muted-foreground">Bientôt : activez votre caméra ou lecteur de code-barres.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="select-livre" className="flex items-center">
                      <Book className="mr-2 h-4 w-4" /> Sélectionner un Livre
                    </Label>
                    <Select value={selectedBookId} onValueChange={setSelectedBookId}>
                      <SelectTrigger id="select-livre" className="w-full bg-input text-foreground">
                        <SelectValue placeholder="Choisir un livre disponible..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover text-popover-foreground">
                        {allBooks.length > 0 ? (
                          allBooks.map(book => (
                            <SelectItem key={book.id} value={book.id} disabled={(book.quantity ?? 0) <= 0}>
                              {book.title} (Stock: {book.quantity ?? 0})
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="no-books" disabled>Aucun livre disponible ou chargé</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="select-lecteur" className="flex items-center">
                      <User className="mr-2 h-4 w-4" /> Sélectionner un Lecteur
                    </Label>
                     <Select value={selectedReaderId} onValueChange={setSelectedReaderId}>
                      <SelectTrigger id="select-lecteur" className="w-full bg-input text-foreground">
                        <SelectValue placeholder="Choisir un lecteur..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover text-popover-foreground">
                        {allReaders.length > 0 ? (
                           allReaders.map(reader => (
                            <SelectItem key={reader.id} value={reader.id}>
                              {reader.prenom} {reader.nom}
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="no-readers" disabled>Aucun lecteur enregistré ou chargé</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter className="sm:justify-between">
                  <Button type="button" variant="outline" onClick={() => {setIsSaisieRapideDialogOpen(false); resetLoanDetailsForm();}}>Annuler</Button>
                  <Button 
                    type="button" 
                    onClick={handleSaisieRapideSubmit} 
                    disabled={!selectedBookId || !selectedReaderId || isSubmittingQuickLoan}
                  >
                    {isSubmittingQuickLoan ? <Loader2 className="animate-spin mr-2" /> : null}
                    {isSubmittingQuickLoan ? 'Enregistrement...' : 'Valider l\'Emprunt'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <CalendarDays className="mr-2 h-5 w-5 text-primary" />
              Vue Calendrier des Retours
            </CardTitle>
            <CardDescription>Visualisez les échéances et les retards.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center h-32 bg-muted/30 rounded-md">
            <CalendarDays className="h-12 w-12 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Calendrier des retours à venir ici.</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <BellRing className="mr-2 h-5 w-5 text-primary" />
              Alertes et Notifications
            </CardTitle>
            <CardDescription>Gestion des rappels et pénalités.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
                <Dialog open={isAlertesConfigDialogOpen} onOpenChange={(open) => setIsAlertesConfigDialogOpen(open)}>
                    <DialogTrigger asChild>
                        <div className="flex items-center justify-between p-2 bg-muted/30 rounded-md hover:bg-muted/50 cursor-pointer">
                            <span className="text-sm">Configurer les alertes avant échéance</span>
                            <Settings className="h-4 w-4 text-muted-foreground" />
                        </div>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                        <DialogHeader>
                            <DialogTitle>Configurer les Alertes Avant Échéance (Simulation)</DialogTitle>
                            <DialogDescription>
                                Définissez quand et comment les rappels automatiques sont envoyés. (Fonctionnalité à venir)
                            </DialogDescription>
                        </DialogHeader>
                        <div className="py-4 space-y-4">
                            <div className="flex items-center space-x-2">
                                <Switch id="activer-rappels" disabled />
                                <Label htmlFor="activer-rappels">Activer les rappels automatiques</Label>
                            </div>
                            <div className="space-y-1">
                                <Label htmlFor="jours-avant-rappel">Envoyer X jours avant la date limite</Label>
                                <Input id="jours-avant-rappel" type="number" placeholder="Ex: 3" disabled className="bg-input" />
                            </div>
                            <div className="space-y-2">
                                <Label>Canaux de notification (simulation) :</Label>
                                <div className="flex items-center space-x-2">
                                    <Checkbox id="rappel-email" disabled />
                                    <Label htmlFor="rappel-email" className="font-normal">Par Email</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Checkbox id="rappel-sms" disabled />
                                    <Label htmlFor="rappel-sms" className="font-normal">Par SMS</Label>
                                </div>
                                 <div className="flex items-center space-x-2">
                                    <Checkbox id="rappel-interne" checked disabled />
                                    <Label htmlFor="rappel-interne" className="font-normal">Notification interne (toujours active)</Label>
                                </div>
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsAlertesConfigDialogOpen(false)}>Fermer</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                <Dialog open={isPenalitesConfigDialogOpen} onOpenChange={(open) => setIsPenalitesConfigDialogOpen(open)}>
                    <DialogTrigger asChild>
                        <div className="flex items-center justify-between p-2 bg-muted/30 rounded-md hover:bg-muted/50 cursor-pointer">
                            <span className="text-sm">Configurer la gestion des pénalités</span>
                            <Settings className="h-4 w-4 text-muted-foreground" />
                        </div>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                        <DialogHeader>
                            <DialogTitle>Configurer la Gestion des Pénalités (Simulation)</DialogTitle>
                            <DialogDescription>
                                Définissez les règles pour les retards. (Fonctionnalité à venir)
                            </DialogDescription>
                        </DialogHeader>
                        <div className="py-4 space-y-4">
                            <div className="flex items-center space-x-2">
                                <Switch id="activer-penalites" disabled />
                                <Label htmlFor="activer-penalites">Activer les pénalités pour retard</Label>
                            </div>
                            <div className="space-y-1">
                                <Label htmlFor="penalite-jour">Montant de la pénalité par jour de retard (€)</Label>
                                <Input id="penalite-jour" type="number" step="0.10" placeholder="Ex: 0.50" disabled className="bg-input" />
                            </div>
                             <div className="space-y-1">
                                <Label htmlFor="jours-avant-blocage">Bloquer l'emprunt après X jours de retard cumulés</Label>
                                <Input id="jours-avant-blocage" type="number" placeholder="Ex: 15" disabled className="bg-input" />
                            </div>
                             <p className="text-xs text-muted-foreground">Ces paramètres sont indicatifs et seront configurables lorsque la fonctionnalité sera implémentée.</p>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsPenalitesConfigDialogOpen(false)}>Fermer</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
             <p className="text-xs text-muted-foreground mt-2">
              (Configuration des notifications automatiques et pénalités à venir)
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="flex-1 flex flex-col shadow-lg">
        <CardHeader>
            <CardTitle className="text-xl flex items-center">
                <ArrowRightLeft className="mr-2 h-6 w-6 text-primary" />
                Détail des Fonctionnalités Prévues
            </CardTitle>
            <CardDescription>Fonctionnalités du module Emprunts/Retours en cours de développement :</CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
           <ul className="list-disc list-inside text-muted-foreground space-y-2 text-sm">
              <li>Saisie rapide via scan ou sélection (sélection manuelle pour emprunt implémentée)</li>
              <li>Date de retour automatique (implémentée pour saisie rapide et nouvel emprunt)</li>
              <li>Alertes avant la date limite de retour</li>
              <li>Gestion des pénalités en cas de retard</li>
              <li>Suivi de l’état du livre au retour (bon, abîmé, perdu) (marquage du retour implémenté)</li>
              <li>Vue calendrier des livres à retourner</li>
              <li>Notifications internes (implémentée pour emprunt/retour)</li>
              <li>Notifications par email et SMS (potentiellement)</li>
              <li>Alertes automatiques 3 jours avant la date limite</li>
            </ul>
        </CardContent>
      </Card>

      <div className="mt-auto pt-6 flex gap-4 justify-end">
        <Button variant="outline" asChild>
          <Link href="/bibliotheque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tableau de Bord Biblio
          </Link>
        </Button>
      </div>
    </main>
  );
}

    