
"use client";

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from "@/hooks/use-toast";


export default function HomePage() {
  const { toast } = useToast();

  return (
    <TooltipProvider>
      <div className="relative flex flex-col min-h-screen bg-black text-white">
        <header className="py-6 px-6 flex flex-col items-center text-center z-10">
          <div>
            <h1 className="text-5xl font-bold text-white">LUX-R</h1>
            <p className="text-lg text-gray-300">Développé par Ryad Mohamed TALEB</p>
          </div>
        </header>

        <main className="flex-grow flex flex-col md:flex-row items-center justify-center p-4 md:p-8 gap-4 md:gap-8 z-10">
          {/* Section Bibliothèque */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href="/bibliotheque" className="w-full md:w-2/5 md:self-stretch transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <Card className="overflow-hidden h-full flex flex-col group bg-black/30 backdrop-blur-sm border-primary/50 hover:border-primary">
                  <div className="p-3 text-center">
                    <h2 className="text-2xl font-semibold text-white">gestion de bibliothèque</h2>
                  </div>
                  <CardContent className="relative p-0 w-full aspect-[4/3]">
                    <Image
                      src="https://cdn.pixabay.com/photo/2016/02/16/21/07/books-1204029_960_720.jpg"
                      alt="Gestion de Bibliothèque"
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      priority
                      data-ai-hint="library books"
                    />
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors flex flex-col items-center justify-end p-4 opacity-0 group-hover:opacity-100">
                       <ArrowRight className="w-8 h-8 text-white group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </TooltipTrigger>
            <TooltipContent>
              <p>Accéder au module de gestion de bibliothèque</p>
            </TooltipContent>
          </Tooltip>

          {/* Séparateur BDD 2 */}
          <div className="flex items-center justify-center w-full md:w-auto h-16 md:h-auto md:self-stretch my-4 md:my-0">
            <div className="bg-background text-primary px-3 py-6 md:px-4 md:py-10 rounded-lg shadow-md h-full flex items-center justify-center transform transition-all duration-300 hover:scale-105">
              <span className="text-3xl md:text-4xl font-bold md:writing-mode-vertical-rl origin-center whitespace-nowrap">
                BDD 2
              </span>
            </div>
          </div>

          {/* Section Banque */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href="/banque" className="w-full md:w-2/5 md:self-stretch transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <Card className="overflow-hidden h-full flex flex-col group bg-black/30 backdrop-blur-sm border-primary/50 hover:border-primary">
                  <div className="p-3 text-center">
                     <h2 className="text-2xl font-semibold text-white">gestion de comptes bancaires</h2>
                  </div>
                  <CardContent className="relative p-0 w-full aspect-[4/3]">
                    <Image
                      src="https://cdn.pixabay.com/photo/2014/10/23/10/10/dollars-499481_960_720.jpg"
                      alt="Gestion de Comptes Bancaires"
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      priority
                      data-ai-hint="banknotes cash"
                    />
                     <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors flex flex-col items-center justify-end p-4 opacity-0 group-hover:opacity-100">
                       <ArrowRight className="w-8 h-8 text-white group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </TooltipTrigger>
            <TooltipContent>
              <p>Accéder au module de gestion de comptes bancaires</p>
            </TooltipContent>
          </Tooltip>
        </main>

        <footer className="py-8 px-6 text-center z-10">
          <p className="text-sm text-gray-400">
            un logiciel super puisant de gestion cree par LUX-R &copy; {new Date().getFullYear()}
          </p>
        </footer>
      </div>
    </TooltipProvider>
  );
}
