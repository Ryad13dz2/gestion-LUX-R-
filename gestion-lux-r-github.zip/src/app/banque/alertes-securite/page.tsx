
"use client";

import Link from 'next/link';
import React, { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, ShieldCheck, BellRing, KeyRound, History, QrCode, Loader2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from '@/components/ui/scroll-area';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';
const LOCAL_STORAGE_BANK_ALERT_SETTINGS_KEY = 'luxr_bank_alert_settings';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  currency: string;
}

interface AlertSettings {
  lowBalanceAlertEnabled: boolean;
  lowBalanceAccountId: string | undefined;
  lowBalanceThreshold: number | string; // string for input, number for storage
  largeTransactionAlertEnabled: boolean;
  largeTransactionThreshold: number | string;
  largeTransactionType: 'all' | 'expense' | 'income';
  notifyByEmail: boolean;
  notifyBySms: boolean;
}

interface TwoFactorAuthState {
    enabled: boolean;
    qrCodeVisible: boolean; // To simulate showing QR code step
    verificationCode: string;
}

export default function AlertesSecuritePage() {
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);

  // Alert Settings State
  const [alertSettings, setAlertSettings] = useState<AlertSettings>({
    lowBalanceAlertEnabled: true,
    lowBalanceAccountId: undefined,
    lowBalanceThreshold: 100,
    largeTransactionAlertEnabled: false,
    largeTransactionThreshold: 1000,
    largeTransactionType: 'all',
    notifyByEmail: true,
    notifyBySms: false,
  });
  
  // 2FA Dialog State
  const [isTwoFactorAuthDialogOpen, setIsTwoFactorAuthDialogOpen] = useState(false);
  const [twoFactorAuth, setTwoFactorAuth] = useState<TwoFactorAuthState>({
    enabled: false, // This would ideally be loaded from user's global security settings
    qrCodeVisible: false,
    verificationCode: "",
  });
  const [isSubmitting2FA, setIsSubmitting2FA] = useState(false);


  useEffect(() => {
    setIsClient(true);
    // Load bank accounts
    try {
      const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
      if (storedAccounts) {
        setBankAccounts(JSON.parse(storedAccounts));
      }
    } catch (error) {
      console.error("Erreur de chargement des comptes bancaires:", error);
      toast({ title: "Erreur", description: "Impossible de charger les comptes clients pour les alertes.", variant: "destructive" });
    }

    // Load alert settings
    try {
      const storedSettings = localStorage.getItem(LOCAL_STORAGE_BANK_ALERT_SETTINGS_KEY);
      if (storedSettings) {
        setAlertSettings(JSON.parse(storedSettings));
      }
    } catch (error) {
      console.error("Erreur de chargement des paramètres d'alerte:", error);
      toast({ title: "Erreur", description: "Impossible de charger les préférences d'alertes.", variant: "destructive" });
    }
  }, [toast]);

  const handleAlertSettingsChange = (field: keyof AlertSettings, value: any) => {
    setAlertSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveAlertSettings = () => {
    try {
      localStorage.setItem(LOCAL_STORAGE_BANK_ALERT_SETTINGS_KEY, JSON.stringify(alertSettings));
      toast({
        title: "Préférences d'Alertes Sauvegardées",
        description: "Vos configurations d'alertes ont été enregistrées localement.",
        className: "bg-green-100 text-green-800 border-green-300",
      });
    } catch (error) {
      console.error("Erreur de sauvegarde des paramètres d'alerte:", error);
      toast({ title: "Erreur de Sauvegarde", description: "Impossible de sauvegarder les préférences d'alertes.", variant: "destructive" });
    }
  };

  const handleTwoFactorAuthSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting2FA(true);
    
    // Simulate API call / processing
    setTimeout(() => {
      if (twoFactorAuth.enabled && !twoFactorAuth.qrCodeVisible) {
        // User is enabling 2FA, show QR code step (simulated)
        setTwoFactorAuth(prev => ({ ...prev, qrCodeVisible: true }));
      } else if (twoFactorAuth.enabled && twoFactorAuth.qrCodeVisible) {
        // User is verifying code
        if (twoFactorAuth.verificationCode === "123456") { // Simulate correct code
          toast({ title: "2FA Activée (Simulation)", description: "L'authentification à deux facteurs est maintenant active." });
          setIsTwoFactorAuthDialogOpen(false);
          // Here you would save the 2FA enabled status for the user
        } else {
          toast({ title: "Code de Vérification Incorrect", description: "Veuillez réessayer.", variant: "destructive" });
        }
      } else {
        // User is disabling 2FA
         toast({ title: "2FA Désactivée (Simulation)", description: "L'authentification à deux facteurs a été désactivée." });
         setIsTwoFactorAuthDialogOpen(false);
         setTwoFactorAuth(prev => ({...prev, qrCodeVisible: false, verificationCode: ""}));
      }
      setIsSubmitting2FA(false);
    }, 1000);
  };

  const simulatedLoginHistory = [
    { id: '1', date: '2024-07-25 10:15', ip: '192.168.1.10 (Paris, FR)', status: 'Réussie' },
    { id: '2', date: '2024-07-24 18:30', ip: '10.0.0.5 (Lyon, FR)', status: 'Réussie' },
    { id: '3', date: '2024-07-24 09:05', ip: '203.0.113.45 (Inconnu)', status: 'Échouée (Mot de passe incorrect)' },
    { id: '4', date: '2024-07-23 14:00', ip: '192.168.1.10 (Paris, FR)', status: 'Réussie' },
  ];

  if (!isClient) {
    return (
      <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-primary flex items-center">
            <ShieldCheck className="mr-3 h-8 w-8" />
            Alertes et Sécurité
          </h1>
        </div>
        <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
          <Loader2 className="h-8 w-8 animate-spin text-primary mr-2"/>
          <p className="text-xl text-muted-foreground">Chargement des paramètres...</p>
        </div>
      </main>
    );
  }


  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <ShieldCheck className="mr-3 h-8 w-8" />
          Alertes et Sécurité
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section Configuration des Alertes */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center">
              <BellRing className="mr-2 h-6 w-6 text-primary" /> Configuration des Alertes
            </CardTitle>
            <CardDescription>Personnalisez les notifications pour rester informé de l'activité de vos comptes.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Alerte Solde Bas */}
            <div className="p-4 border rounded-lg bg-muted/30">
              <div className="flex items-center justify-between mb-3">
                <Label htmlFor="low-balance-switch" className="text-base font-semibold">Alerte de Solde Bas</Label>
                <Switch
                  id="low-balance-switch"
                  checked={alertSettings.lowBalanceAlertEnabled}
                  onCheckedChange={(checked) => handleAlertSettingsChange('lowBalanceAlertEnabled', checked)}
                />
              </div>
              {alertSettings.lowBalanceAlertEnabled && (
                <div className="space-y-3 pl-2 border-l-2 border-primary ml-1">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                    <div>
                      <Label htmlFor="low-balance-account">Compte concerné</Label>
                      <Select
                        value={alertSettings.lowBalanceAccountId}
                        onValueChange={(value) => handleAlertSettingsChange('lowBalanceAccountId', value)}
                        disabled={bankAccounts.length === 0}
                      >
                        <SelectTrigger id="low-balance-account" className="bg-input">
                          <SelectValue placeholder={bankAccounts.length > 0 ? "Choisir un compte" : "Aucun compte disponible"} />
                        </SelectTrigger>
                        <SelectContent className="bg-popover">
                          {bankAccounts.map(acc => (
                            <SelectItem key={acc.id} value={acc.id}>
                              {acc.holderFirstName} {acc.holderLastName} ({acc.accountNumber})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="low-balance-threshold">Seuil de solde (en devise du compte)</Label>
                      <Input
                        id="low-balance-threshold"
                        type="number"
                        value={alertSettings.lowBalanceThreshold}
                        onChange={(e) => handleAlertSettingsChange('lowBalanceThreshold', e.target.value)}
                        placeholder="Ex: 100"
                        className="bg-input"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Alerte Transactions Importantes */}
            <div className="p-4 border rounded-lg bg-muted/30">
              <div className="flex items-center justify-between mb-3">
                <Label htmlFor="large-transaction-switch" className="text-base font-semibold">Alerte de Transactions Importantes</Label>
                <Switch
                  id="large-transaction-switch"
                  checked={alertSettings.largeTransactionAlertEnabled}
                  onCheckedChange={(checked) => handleAlertSettingsChange('largeTransactionAlertEnabled', checked)}
                />
              </div>
              {alertSettings.largeTransactionAlertEnabled && (
                <div className="space-y-3 pl-2 border-l-2 border-primary ml-1">
                  <div>
                    <Label htmlFor="large-transaction-threshold">Seuil de transaction (montant absolu)</Label>
                    <Input
                      id="large-transaction-threshold"
                      type="number"
                      value={alertSettings.largeTransactionThreshold}
                      onChange={(e) => handleAlertSettingsChange('largeTransactionThreshold', e.target.value)}
                      placeholder="Ex: 1000"
                      className="bg-input"
                    />
                  </div>
                  <div>
                    <Label>Type de transaction à surveiller</Label>
                    <RadioGroup
                      value={alertSettings.largeTransactionType}
                      onValueChange={(value) => handleAlertSettingsChange('largeTransactionType', value as AlertSettings['largeTransactionType'])}
                      className="flex space-x-4 pt-1"
                    >
                      <div className="flex items-center space-x-2"><RadioGroupItem value="all" id="lt-all" /><Label htmlFor="lt-all">Toutes</Label></div>
                      <div className="flex items-center space-x-2"><RadioGroupItem value="expense" id="lt-expense" /><Label htmlFor="lt-expense">Dépenses</Label></div>
                      <div className="flex items-center space-x-2"><RadioGroupItem value="income" id="lt-income" /><Label htmlFor="lt-income">Revenus</Label></div>
                    </RadioGroup>
                  </div>
                </div>
              )}
            </div>
            
            {/* Canaux de Notification */}
            <div className="p-4 border rounded-lg bg-muted/30">
                <Label className="text-base font-semibold mb-2 block">Canaux de Notification (Simulation)</Label>
                <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="notify-email" 
                            checked={alertSettings.notifyByEmail} 
                            onCheckedChange={(checked) => handleAlertSettingsChange('notifyByEmail', Boolean(checked))}
                        />
                        <Label htmlFor="notify-email" className="font-normal">Notifier par Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="notify-sms" 
                            checked={alertSettings.notifyBySms} 
                            onCheckedChange={(checked) => handleAlertSettingsChange('notifyBySms', Boolean(checked))}
                        />
                        <Label htmlFor="notify-sms" className="font-normal">Notifier par SMS</Label>
                    </div>
                </div>
                 <p className="text-xs text-muted-foreground mt-2">La configuration réelle des envois d'emails/SMS sera implémentée ultérieurement.</p>
            </div>

            <Button onClick={handleSaveAlertSettings} className="w-full">
              Sauvegarder les Préférences d'Alertes (Local)
            </Button>
          </CardContent>
        </Card>

        {/* Section Paramètres de Sécurité */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center">
              <ShieldCheck className="mr-2 h-6 w-6 text-primary" /> Paramètres de Sécurité (Illustratif)
            </CardTitle>
            <CardDescription>Gérez la sécurité de votre accès à la plateforme.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Dialog open={isTwoFactorAuthDialogOpen} onOpenChange={setIsTwoFactorAuthDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <KeyRound className="mr-2 h-4 w-4" /> Configurer l'Authentification à Deux Facteurs (2FA)
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="text-xl flex items-center">
                    <KeyRound className="mr-2 h-6 w-6 text-primary" /> Configurer la 2FA
                  </DialogTitle>
                  <DialogDescription className="mt-2 text-sm text-muted-foreground">
                    {twoFactorAuth.enabled && twoFactorAuth.qrCodeVisible 
                      ? "Scannez ce QR code avec votre application d'authentification, puis entrez le code généré."
                      : twoFactorAuth.enabled 
                      ? "L'authentification à deux facteurs est activée. Vous pouvez la désactiver ci-dessous."
                      : "Activez la 2FA pour renforcer la sécurité de votre compte."}
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleTwoFactorAuthSubmit}>
                    <div className="py-4 space-y-6">
                    {!twoFactorAuth.qrCodeVisible && (
                        <div className="flex items-center space-x-2">
                            <Switch 
                                id="activer-2fa" 
                                checked={twoFactorAuth.enabled} 
                                onCheckedChange={(checked) => setTwoFactorAuth(prev => ({ ...prev, enabled: checked, qrCodeVisible: false, verificationCode: "" }))}
                            />
                            <Label htmlFor="activer-2fa">{twoFactorAuth.enabled ? "2FA Activée" : "Activer la 2FA"}</Label>
                        </div>
                    )}

                    {twoFactorAuth.enabled && twoFactorAuth.qrCodeVisible && (
                        <>
                        <div className="flex flex-col items-center space-y-2">
                            <p className="text-sm text-muted-foreground">Scannez ce QR code :</p>
                            <div className="w-36 h-36 bg-muted flex items-center justify-center rounded-md border">
                            <QrCode className="h-28 w-28 text-muted-foreground" />
                            </div>
                            <p className="text-xs text-muted-foreground">(Ceci est un QR code factice)</p>
                        </div>
                        <div className="space-y-1">
                            <Label htmlFor="verification-code">Entrez le code de vérification</Label>
                            <Input 
                            id="verification-code" 
                            value={twoFactorAuth.verificationCode} 
                            onChange={(e) => setTwoFactorAuth(prev => ({ ...prev, verificationCode: e.target.value }))}
                            placeholder="Code à 6 chiffres" 
                            className="bg-input"
                            maxLength={6}
                            required
                            />
                        </div>
                        </>
                    )}
                     <p className="text-xs text-primary bg-primary/10 p-2 rounded-md">
                        <strong>Note :</strong> Ceci est une simulation. Aucune fonctionnalité 2FA réelle n'est activée. Utilisez "123456" comme code de vérification.
                    </p>
                    </div>
                    <DialogFooter className="sm:justify-between">
                    <Button type="button" variant="outline" onClick={() => setIsTwoFactorAuthDialogOpen(false)}>Annuler</Button>
                    <Button type="submit" disabled={isSubmitting2FA}>
                        {isSubmitting2FA && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {twoFactorAuth.enabled 
                        ? (twoFactorAuth.qrCodeVisible ? "Vérifier et Activer" : "Désactiver la 2FA") 
                        : "Activer la 2FA"}
                    </Button>
                    </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>

            <Button variant="outline" className="w-full justify-start" disabled>
              <KeyRound className="mr-2 h-4 w-4" /> Changer le Mot de Passe (Bientôt)
            </Button>
            <p className="text-xs text-muted-foreground">Une gestion sécurisée des mots de passe nécessite une infrastructure backend.</p>
            
            <div className="pt-4">
                <h3 className="text-md font-semibold mb-2 flex items-center">
                    <History className="mr-2 h-5 w-5 text-primary" /> Historique des Connexions Récentes (Exemples)
                </h3>
                <ScrollArea className="h-40 border rounded-md p-3 bg-muted/30">
                    <ul className="space-y-2 text-sm">
                        {simulatedLoginHistory.map(login => (
                            <li key={login.id} className={`pb-1 border-b border-border/30 last:border-b-0 ${login.status === 'Échouée (Mot de passe incorrect)' ? 'text-destructive' : 'text-muted-foreground'}`}>
                                <span className="font-medium text-foreground">{login.date}</span> - IP: {login.ip} - Statut: <span className={login.status !== 'Réussie' ? 'font-semibold' : ''}>{login.status}</span>
                            </li>
                        ))}
                    </ul>
                </ScrollArea>
                <p className="text-xs text-muted-foreground mt-1">Ceci est un exemple d'historique. La journalisation réelle sera implémentée ultérieurement.</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Les préférences d'alertes sont sauvegardées localement. Les fonctions de sécurité sont illustratives.
      </p>
    </main>
  );
}

    