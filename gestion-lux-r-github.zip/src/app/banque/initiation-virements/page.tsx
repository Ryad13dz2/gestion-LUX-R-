
"use client";

import Link from 'next/link';
import React, { useState, useEffect } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Send, Banknote, CalendarIcon, User, Landmark, FileText } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useNotifications } from '@/contexts/NotificationContext';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  currency: "EUR" | "USD" | "DZD";
  balance: number;
}

const transferFormSchema = z.object({
  sourceAccountId: z.string({ required_error: "Veuillez sélectionner un compte source." }),
  destinationType: z.enum(["internal", "external"], { required_error: "Veuillez choisir un type de destinataire." }),
  destinationAccountId: z.string().optional(),
  externalAccountIBAN: z.string().optional(),
  externalAccountHolderName: z.string().optional(),
  amount: z.preprocess(
    (val) => (val === "" ? undefined : parseFloat(String(val))),
    z.number({ invalid_type_error: "Montant invalide." }).positive({ message: "Le montant du virement doit être positif." })
  ),
  executionDate: z.date({ required_error: "La date d'exécution est requise." }),
  reference: z.string().optional().or(z.literal('')),
}).superRefine((data, ctx) => {
  if (data.destinationType === "internal" && !data.destinationAccountId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Veuillez sélectionner un compte destinataire interne.",
      path: ["destinationAccountId"],
    });
  }
  if (data.destinationType === "internal" && data.sourceAccountId === data.destinationAccountId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Le compte source et destinataire ne peuvent pas être identiques.",
      path: ["destinationAccountId"],
    });
  }
  if (data.destinationType === "external" && (!data.externalAccountIBAN || data.externalAccountIBAN.trim() === "")) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "L'IBAN du compte externe est requis.",
      path: ["externalAccountIBAN"],
    });
  }
   if (data.destinationType === "external" && (!data.externalAccountHolderName || data.externalAccountHolderName.trim() === "")) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Le nom du titulaire du compte externe est requis.",
      path: ["externalAccountHolderName"],
    });
  }
});

type TransferFormValues = z.infer<typeof transferFormSchema>;

export default function InitiationVirementsPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isClient, setIsClient] = useState(false);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);

  const form = useForm<TransferFormValues>({
    resolver: zodResolver(transferFormSchema),
    defaultValues: {
      amount: "" as unknown as undefined,
      reference: "",
      destinationType: "internal",
    },
  });

  const destinationType = form.watch("destinationType");
  const sourceAccountId = form.watch("sourceAccountId");

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      try {
        const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
        if (storedAccounts) {
          setBankAccounts(JSON.parse(storedAccounts));
        }
      } catch (error) {
        console.error("Erreur de chargement des comptes bancaires:", error);
        toast({ title: "Erreur", description: "Impossible de charger les comptes clients.", variant: "destructive" });
      }
    }
  }, [toast]);

  const getCurrencySymbol = (currencyCode: string | undefined) => {
    if (!currencyCode) return '';
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  async function onSubmit(data: TransferFormValues) {
    if (!isClient) return;

    const sourceAccount = bankAccounts.find(acc => acc.id === data.sourceAccountId);
    if (!sourceAccount) {
      toast({ title: "Erreur", description: "Compte source non trouvé.", variant: "destructive" });
      return;
    }

    if (sourceAccount.balance < data.amount) {
      toast({
        title: "Solde Insuffisant",
        description: `Le solde du compte source (${sourceAccount.balance.toFixed(2)} ${getCurrencySymbol(sourceAccount.currency)}) est insuffisant pour effectuer ce virement.`,
        variant: "destructive",
        duration: 7000,
      });
      return;
    }

    let updatedAccountsList = [...bankAccounts];
    let notificationTitle = "Virement Enregistré (Local)";
    let notificationDescription = "";

    // Update source account
    const updatedSourceAccount = { ...sourceAccount, balance: sourceAccount.balance - data.amount };
    updatedAccountsList = updatedAccountsList.map(acc => acc.id === sourceAccount.id ? updatedSourceAccount : acc);

    if (data.destinationType === "internal" && data.destinationAccountId) {
      const destinationAccount = bankAccounts.find(acc => acc.id === data.destinationAccountId);
      if (!destinationAccount) {
        toast({ title: "Erreur", description: "Compte destinataire interne non trouvé.", variant: "destructive" });
        return;
      }
      if (sourceAccount.currency !== destinationAccount.currency) {
        toast({
            title: "Opération Non Supportée",
            description: "Les virements entre comptes de devises différentes ne sont pas supportés pour cette simulation.",
            variant: "destructive",
            duration: 7000,
        });
        return;
      }
      const updatedDestinationAccount = { ...destinationAccount, balance: destinationAccount.balance + data.amount };
      updatedAccountsList = updatedAccountsList.map(acc => acc.id === destinationAccount.id ? updatedDestinationAccount : acc);
      notificationDescription = `Virement de ${data.amount.toFixed(2)} ${getCurrencySymbol(sourceAccount.currency)} de ${sourceAccount.holderFirstName} ${sourceAccount.holderLastName} à ${destinationAccount.holderFirstName} ${destinationAccount.holderLastName}.`;
    } else if (data.destinationType === "external") {
      notificationDescription = `Virement externe de ${data.amount.toFixed(2)} ${getCurrencySymbol(sourceAccount.currency)} de ${sourceAccount.holderFirstName} ${sourceAccount.holderLastName} vers ${data.externalAccountHolderName} (IBAN: ${data.externalAccountIBAN}).`;
    }

    try {
      localStorage.setItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY, JSON.stringify(updatedAccountsList));
      setBankAccounts(updatedAccountsList);

      toast({
        title: notificationTitle,
        description: notificationDescription,
        className: "bg-green-100 text-green-800 border-green-300",
        duration: 7000,
      });
      addNotification(notificationTitle, notificationDescription);
      form.reset({
        amount: "" as unknown as undefined,
        reference: "",
        sourceAccountId: undefined,
        destinationType: "internal",
        destinationAccountId: undefined,
        externalAccountHolderName: "",
        externalAccountIBAN: "",
        executionDate: undefined,
      });
    } catch (error) {
      console.error("Erreur lors de l'enregistrement du virement:", error);
      toast({
        title: "Erreur de Sauvegarde",
        description: "Une erreur est survenue lors de l'enregistrement du virement.",
        variant: "destructive",
      });
    }
  }

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <Send className="mr-3 h-8 w-8" />
          Initiation de Virements
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      {isClient && bankAccounts.length < 1 && (
        <Alert variant="destructive" className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Comptes Insuffisants</AlertTitle>
          <AlertDescription>
            Vous devez avoir au moins un compte client pour initier un virement. Pour un virement interne, au moins deux comptes sont nécessaires. 
            Veuillez d'abord <Link href="/banque/ouverture-compte" className="underline">créer des comptes clients</Link>.
          </AlertDescription>
        </Alert>
      )}

      <Card className="w-full max-w-3xl mx-auto shadow-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Détails du Virement</CardTitle>
          <CardDescription>Remplissez les informations pour initier un nouveau virement. Les soldes des comptes seront mis à jour localement.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="sourceAccountId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Compte Source</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""} disabled={bankAccounts.length === 0}>
                      <FormControl>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue placeholder={bankAccounts.length > 0 ? "Sélectionner un compte source" : "Aucun compte disponible"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-popover text-popover-foreground border-border">
                        {bankAccounts.map(acc => (
                          <SelectItem key={acc.id} value={acc.id}>
                            {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber} (Solde: {acc.balance.toFixed(2)} {getCurrencySymbol(acc.currency)})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="destinationType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel className="flex items-center"><Landmark className="mr-2 h-4 w-4 text-primary" />Type de Destinataire</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1 md:flex-row md:space-x-4 md:space-y-0"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="internal" />
                          </FormControl>
                          <FormLabel className="font-normal">Compte Interne (LUX-R)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="external" />
                          </FormControl>
                          <FormLabel className="font-normal">Compte Externe</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {destinationType === "internal" && (
                <FormField
                  control={form.control}
                  name="destinationAccountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Compte Destinataire (Interne)</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""} disabled={bankAccounts.length < 2}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder={bankAccounts.length < 2 ? "Nécessite au moins 2 comptes" : "Sélectionner un compte destinataire"} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          {bankAccounts.filter(acc => acc.id !== sourceAccountId).map(acc => (
                            <SelectItem key={acc.id} value={acc.id}>
                              {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber} (Solde: {acc.balance.toFixed(2)} {getCurrencySymbol(acc.currency)})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {destinationType === "external" && (
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="externalAccountIBAN"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center"><Landmark className="mr-2 h-4 w-4 text-primary" />IBAN du Compte Destinataire Externe</FormLabel>
                        <FormControl>
                          <Input placeholder="FR76 XXXX XXXX XXXX XXXX XXXX XXX" {...field} className="bg-input border-border text-foreground" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="externalAccountHolderName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Nom du Titulaire du Compte Externe</FormLabel>
                        <FormControl>
                          <Input placeholder="Nom complet du bénéficiaire" {...field} className="bg-input border-border text-foreground" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Montant du Virement</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Ex: 250.00" {...field} className="bg-input border-border text-foreground" step="0.01" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="executionDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="flex items-center"><CalendarIcon className="mr-2 h-4 w-4 text-primary" />Date d'Exécution</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal bg-input border-border text-foreground hover:bg-accent",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: fr })
                              ) : (
                                <span>Choisir une date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date(new Date().setHours(0,0,0,0))}
                            initialFocus
                            className="bg-card text-card-foreground"
                            defaultMonth={field.value || new Date()}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><FileText className="mr-2 h-4 w-4 text-primary" />Motif / Référence (Optionnel)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Ex: Loyer mois de Juillet, Cadeau anniversaire" {...field} className="bg-input border-border text-foreground" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={form.formState.isSubmitting || !isClient || bankAccounts.length === 0}
              >
                {form.formState.isSubmitting ? 'Traitement en cours...' : 'Initier le Virement'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Les virements et les soldes sont actuellement sauvegardés localement dans votre navigateur.
      </p>
    </main>
  );
}


    