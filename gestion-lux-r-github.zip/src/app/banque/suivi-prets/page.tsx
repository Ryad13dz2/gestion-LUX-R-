
"use client";

import Link from 'next/link';
import React, { useState, useEffect, FormEvent, useMemo } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format, addMonths, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Percent, PlusCircle, Banknote, CalendarIcon, Search as SearchIcon, Info, Users, HandCoins, Building, Car, Receipt, Eye } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from '@/contexts/NotificationContext';
import { cn } from "@/lib/utils";
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';
const LOCAL_STORAGE_BANK_LOANS_KEY = 'luxr_bank_loans';

interface BankAccountForLoan {
  id: string;
  accountNumber: string;
  holderFullName: string;
  currency: "EUR" | "USD" | "DZD";
}

interface Loan {
  id: string;
  accountId: string;
  accountHolderFullName: string;
  loanAmount: number;
  interestRate: number; // Stored as percentage, e.g., 5 for 5%
  termMonths: number;
  loanPurpose?: string;
  startDate: string; // ISO string
  currency: "EUR" | "USD" | "DZD";
  status: 'En cours' | 'Remboursé' | 'En Retard'; // Simulated
  // Calculated for display
  dueDate?: string;
  monthlyPayment?: number;
}

const loanFormSchema = z.object({
  accountId: z.string({ required_error: "Veuillez sélectionner un compte client." }).min(1, "Un compte client est requis."),
  loanAmount: z.preprocess(
    (val) => val === "" ? undefined : parseFloat(String(val)),
    z.number({invalid_type_error: "Montant invalide"}).positive({ message: "Le montant du prêt doit être positif." })
  ),
  interestRate: z.preprocess(
    (val) => val === "" ? undefined : parseFloat(String(val)),
    z.number({invalid_type_error: "Taux invalide"}).min(0, { message: "Le taux d'intérêt ne peut être négatif." }).max(100, { message: "Le taux d'intérêt ne peut excéder 100%."})
  ),
  termMonths: z.preprocess(
    (val) => val === "" ? undefined : parseInt(String(val), 10),
    z.number({invalid_type_error: "Durée invalide"}).int().positive({ message: "La durée doit être un nombre entier positif de mois." })
  ),
  loanPurpose: z.string().optional(),
  startDate: z.date({ required_error: "La date de début est requise." }),
});

type LoanFormValues = z.infer<typeof loanFormSchema>;

export default function SuiviPretsPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isClient, setIsClient] = useState(false);
  const [isAddLoanDialogOpen, setIsAddLoanDialogOpen] = useState(false);
  const [isRecordPaymentDialogOpen, setIsRecordPaymentDialogOpen] = useState(false);
  const [isViewLoanDetailsDialogOpen, setIsViewLoanDetailsDialogOpen] = useState(false);
  const [loanForPayment, setLoanForPayment] = useState<Loan | null>(null);
  const [loanForDetails, setLoanForDetails] = useState<Loan | null>(null);
  
  const [bankAccounts, setBankAccounts] = useState<BankAccountForLoan[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const form = useForm<LoanFormValues>({
    resolver: zodResolver(loanFormSchema),
    defaultValues: {
      loanAmount: '' as unknown as undefined,
      interestRate: '' as unknown as undefined,
      termMonths: '' as unknown as undefined,
      loanPurpose: "",
      accountId: undefined,
      startDate: undefined,
    },
  });

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      // Load bank accounts
      try {
        const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
        if (storedAccounts) {
          const parsedAccounts = JSON.parse(storedAccounts).map((acc: any) => ({
            id: acc.id,
            accountNumber: acc.accountNumber,
            holderFullName: `${acc.holderFirstName} ${acc.holderLastName}`,
            currency: acc.currency,
          }));
          setBankAccounts(parsedAccounts);
        }
      } catch (error) {
        console.error("Erreur de chargement des comptes bancaires:", error);
        toast({ title: "Erreur", description: "Impossible de charger les comptes clients.", variant: "destructive" });
      }

      // Load loans
      try {
        const storedLoans = localStorage.getItem(LOCAL_STORAGE_BANK_LOANS_KEY);
        if (storedLoans) {
          const parsedLoans: Loan[] = JSON.parse(storedLoans);
          setLoans(parsedLoans.map(loan => ({
            ...loan,
            dueDate: format(addMonths(parseISO(loan.startDate), loan.termMonths), 'dd MMMM yyyy', { locale: fr }),
            monthlyPayment: calculateMonthlyPayment(loan.loanAmount, loan.interestRate, loan.termMonths)
          })));
        }
      } catch (error) {
        console.error("Erreur de chargement des prêts:", error);
        toast({ title: "Erreur", description: "Impossible de charger les prêts existants.", variant: "destructive" });
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredLoans = useMemo(() => {
    const lowercasedFilter = searchTerm.toLowerCase();
    if (!lowercasedFilter) return loans;
    return loans.filter(loan =>
      loan.accountHolderFullName.toLowerCase().includes(lowercasedFilter) ||
      (loan.loanPurpose && loan.loanPurpose.toLowerCase().includes(lowercasedFilter)) ||
      loan.id.toLowerCase().includes(lowercasedFilter)
    );
  }, [loans, searchTerm]);

  function calculateMonthlyPayment(principal: number, annualInterestRate: number, termMonths: number): number {
    if (principal <= 0 || termMonths <= 0) return 0;
    if (annualInterestRate === 0) return principal / termMonths;

    const monthlyInterestRate = (annualInterestRate / 100) / 12;
    const payment = principal * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, termMonths)) / (Math.pow(1 + monthlyInterestRate, termMonths) - 1);
    return parseFloat(payment.toFixed(2));
  }

  const getCurrencySymbol = (currencyCode: string | undefined) => {
    if (!currencyCode) return '';
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };
  
  async function onSubmit(data: LoanFormValues) {
    if (!isClient) return;

    const selectedAccount = bankAccounts.find(acc => acc.id === data.accountId);
    if (!selectedAccount) {
      toast({ title: "Erreur", description: "Compte client sélectionné non valide.", variant: "destructive" });
      return;
    }

    const newLoan: Loan = {
      id: `PRET-${Date.now().toString().slice(-6)}`,
      accountId: selectedAccount.id,
      accountHolderFullName: selectedAccount.holderFullName,
      loanAmount: data.loanAmount,
      interestRate: data.interestRate,
      termMonths: data.termMonths,
      loanPurpose: data.loanPurpose || "Non spécifié",
      startDate: data.startDate.toISOString(),
      currency: selectedAccount.currency,
      status: 'En cours', // Initial status
    };
    
    // Calculate display fields
    newLoan.dueDate = format(addMonths(parseISO(newLoan.startDate), newLoan.termMonths), 'dd MMMM yyyy', { locale: fr });
    newLoan.monthlyPayment = calculateMonthlyPayment(newLoan.loanAmount, newLoan.interestRate, newLoan.termMonths);


    try {
      const updatedLoans = [...loans, newLoan];
      localStorage.setItem(LOCAL_STORAGE_BANK_LOANS_KEY, JSON.stringify(updatedLoans));
      setLoans(updatedLoans.map(loan => ({ // ensure all loans in state have calculated fields
        ...loan,
        dueDate: format(addMonths(parseISO(loan.startDate), loan.termMonths), 'dd MMMM yyyy', { locale: fr }),
        monthlyPayment: calculateMonthlyPayment(loan.loanAmount, loan.interestRate, loan.termMonths)
      })));
      
      toast({
        title: "Nouveau Prêt Enregistré (Local)",
        description: `Prêt de ${newLoan.loanAmount} ${getCurrencySymbol(newLoan.currency)} pour ${newLoan.accountHolderFullName} enregistré.`,
        className: "bg-green-100 text-green-800 border-green-300",
      });
      addNotification("Nouveau Prêt Ajouté", `Prêt pour ${newLoan.accountHolderFullName} d'un montant de ${newLoan.loanAmount} ${getCurrencySymbol(newLoan.currency)}.`);
      form.reset({
        loanAmount: '' as unknown as undefined,
        interestRate: '' as unknown as undefined,
        termMonths: '' as unknown as undefined,
        loanPurpose: "",
        accountId: undefined,
        startDate: undefined,
      });
      setIsAddLoanDialogOpen(false);
    } catch (error) {
      console.error("Erreur lors de la sauvegarde du prêt:", error);
      toast({
        title: "Erreur de Sauvegarde",
        description: "Une erreur est survenue lors de l'enregistrement du prêt.",
        variant: "destructive",
      });
    }
  }
  
  const getLoanPurposeIcon = (purpose?: string) => {
    if (!purpose) return <HandCoins className="mr-2 h-4 w-4 text-muted-foreground" />;
    const lowerPurpose = purpose.toLowerCase();
    if (lowerPurpose.includes("immobilier")) return <Building className="mr-2 h-4 w-4 text-muted-foreground" />;
    if (lowerPurpose.includes("voiture") || lowerPurpose.includes("auto")) return <Car className="mr-2 h-4 w-4 text-muted-foreground" />;
    return <HandCoins className="mr-2 h-4 w-4 text-muted-foreground" />;
  }

  const openRecordPaymentDialog = (loan: Loan) => {
    setLoanForPayment(loan);
    setIsRecordPaymentDialogOpen(true);
  };

  const openViewLoanDetailsDialog = (loan: Loan) => {
    setLoanForDetails(loan);
    setIsViewLoanDetailsDialogOpen(true);
  };

  const handleRecordPaymentSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!loanForPayment) return;

    const formData = new FormData(event.currentTarget);
    const paymentAmount = formData.get('paymentAmount') as string;
    
    // Here you would typically update the loan balance, record the transaction, etc.
    // For now, we just simulate with a toast.
    toast({
      title: "Paiement Enregistré (Simulation)",
      description: `Paiement de ${paymentAmount || loanForPayment.monthlyPayment?.toFixed(2)} ${getCurrencySymbol(loanForPayment.currency)} pour le prêt ${loanForPayment.id} a été simulé.`,
      className: "bg-green-100 text-green-800 border-green-300",
    });
    addNotification("Paiement de Prêt (Simulé)", `Paiement pour prêt ${loanForPayment.id} enregistré.`);
    setIsRecordPaymentDialogOpen(false);
    setLoanForPayment(null);
  };


  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <Percent className="mr-3 h-8 w-8" />
          Suivi des Prêts et Crédits
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <div className="mb-6 flex justify-between items-center">
        <div className="relative w-full max-w-md">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Rechercher par client, N° prêt, objet..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border bg-input text-foreground shadow-sm text-base"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Dialog open={isAddLoanDialogOpen} onOpenChange={setIsAddLoanDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" disabled={!isClient || bankAccounts.length === 0}>
              <PlusCircle className="mr-2 h-5 w-5" />
              Ajouter un Nouveau Prêt
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center">
                <PlusCircle className="mr-2 h-6 w-6 text-primary" /> Enregistrer un Nouveau Prêt
              </DialogTitle>
              <DialogDescription>
                Remplissez les informations pour enregistrer un nouveau prêt. Sauvegarde locale.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
                <FormField
                  control={form.control}
                  name="accountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Users className="mr-2 h-4 w-4 text-primary" />Compte Client Bénéficiaire</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder="Sélectionner un compte client" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          {bankAccounts.map(acc => (
                            <SelectItem key={acc.id} value={acc.id}>
                              {acc.holderFullName} (N°: {acc.accountNumber} - {getCurrencySymbol(acc.currency)})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="loanAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Montant du Prêt</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="Ex: 5000" {...field} value={field.value ?? ''} className="bg-input border-border text-foreground" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="interestRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center"><Percent className="mr-2 h-4 w-4 text-primary" />Taux d'Intérêt Annuel (%)</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="Ex: 5.5" step="0.01" {...field} value={field.value ?? ''} className="bg-input border-border text-foreground" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                    control={form.control}
                    name="termMonths"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel className="flex items-center"><CalendarIcon className="mr-2 h-4 w-4 text-primary" />Durée du Prêt (Mois)</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder="Ex: 24" {...field} value={field.value ?? ''} className="bg-input border-border text-foreground" />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel className="flex items-center"><CalendarIcon className="mr-2 h-4 w-4 text-primary" />Date de Début du Prêt</FormLabel>
                        <Popover>
                            <PopoverTrigger asChild>
                            <FormControl>
                                <Button
                                variant={"outline"}
                                className={cn(
                                    "w-full pl-3 text-left font-normal bg-input border-border text-foreground hover:bg-accent",
                                    !field.value && "text-muted-foreground"
                                )}
                                >
                                {field.value ? (
                                    format(field.value, "PPP", { locale: fr })
                                ) : (
                                    <span>Choisir une date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                            </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                            <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) => date < new Date("2000-01-01")}
                                initialFocus
                                className="bg-card text-card-foreground"
                            />
                            </PopoverContent>
                        </Popover>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                </div>
                <FormField
                  control={form.control}
                  name="loanPurpose"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Info className="mr-2 h-4 w-4 text-primary" />Objet du Prêt (Optionnel)</FormLabel>
                       <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder="Sélectionner un objet ou laisser vide" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          <SelectItem value="Immobilier">Immobilier</SelectItem>
                          <SelectItem value="Voiture">Voiture</SelectItem>
                          <SelectItem value="Consommation">Consommation</SelectItem>
                          <SelectItem value="Travaux">Travaux</SelectItem>
                          <SelectItem value="Autre">Autre (sera "Non spécifié")</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter className="mt-6">
                  <Button type="button" variant="outline" onClick={() => setIsAddLoanDialogOpen(false)}>Annuler</Button>
                  <Button type="submit" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting ? 'Enregistrement...' : 'Enregistrer le Prêt'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
       {isClient && bankAccounts.length === 0 && (
         <Alert variant="destructive" className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Aucun Compte Client</AlertTitle>
          <AlertDescription>
            Vous devez d'abord <Link href="/banque/ouverture-compte" className="underline">créer au moins un compte client</Link> avant de pouvoir enregistrer un prêt.
          </AlertDescription>
        </Alert>
      )}

      {isClient && filteredLoans.length === 0 && loans.length > 0 && (
         <Card className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
          <p className="text-xl text-muted-foreground text-center">
            Aucun prêt ne correspond à votre recherche "{searchTerm}".
          </p>
        </Card>
      )}
      {isClient && loans.length === 0 && (
        <Card className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md min-h-[300px]">
          <div className="text-center">
            <Percent className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-xl text-muted-foreground">Aucun prêt enregistré pour le moment.</p>
            <p className="text-sm text-muted-foreground mt-1">Utilisez le bouton "Ajouter un Nouveau Prêt" pour commencer.</p>
          </div>
        </Card>
      )}

      {isClient && filteredLoans.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredLoans.map(loan => (
            <Card key={loan.id} className="shadow-lg hover:shadow-primary/20 transition-shadow duration-300 bg-card flex flex-col">
              <CardHeader>
                <CardTitle className="text-xl flex items-center text-primary">
                  <Users className="mr-2 h-5 w-5" /> {loan.accountHolderFullName}
                </CardTitle>
                <CardDescription className="text-sm">
                  Prêt N° : <span className="font-semibold text-foreground">{loan.id}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm flex-grow">
                <div className="flex items-center">
                  <Banknote className="mr-2 h-4 w-4 text-muted-foreground" />
                  Montant : <span className="ml-1 font-bold text-green-600">{loan.loanAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {getCurrencySymbol(loan.currency)}</span>
                </div>
                <div className="flex items-center">
                  <Percent className="mr-2 h-4 w-4 text-muted-foreground" />
                  Taux : <span className="ml-1 font-medium">{loan.interestRate}% / an</span>
                </div>
                 <div className="flex items-center">
                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                  Durée : <span className="ml-1 font-medium">{loan.termMonths} mois</span>
                </div>
                 <div className="flex items-center">
                  {getLoanPurposeIcon(loan.loanPurpose)}
                  Objet : <span className="ml-1 font-medium">{loan.loanPurpose}</span>
                </div>
                 <div className="flex items-center">
                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                  Début : <span className="ml-1 font-medium">{format(parseISO(loan.startDate), 'dd MMM yyyy', { locale: fr })}</span>
                </div>
                 <div className="flex items-center">
                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                  Échéance : <span className="ml-1 font-medium">{loan.dueDate}</span>
                </div>
                 <div className="flex items-center">
                  <HandCoins className="mr-2 h-4 w-4 text-muted-foreground" />
                  Mensualité : <span className="ml-1 font-medium">~{loan.monthlyPayment?.toFixed(2)} {getCurrencySymbol(loan.currency)}</span>
                </div>
                <div className="flex items-center">
                  <Info className="mr-2 h-4 w-4 text-muted-foreground" />
                  Statut : <span className={`ml-1 font-semibold px-2 py-0.5 rounded-full text-xs ${loan.status === 'En cours' ? 'bg-blue-100 text-blue-700' : loan.status === 'Remboursé' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{loan.status}</span>
                </div>
              </CardContent>
              <CardFooter className="pt-4 border-t mt-auto space-x-2">
                 <Button variant="outline" size="sm" className="flex-grow" onClick={() => openViewLoanDetailsDialog(loan)}>
                    <Eye className="mr-2 h-4 w-4" /> Voir Détails
                </Button>
                <Button 
                    size="sm" 
                    className="flex-grow" 
                    onClick={() => openRecordPaymentDialog(loan)} 
                    disabled={loan.status === 'Remboursé'}
                >
                    <Receipt className="mr-2 h-4 w-4" /> Enregistrer Paiement
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      
      {/* Record Payment Dialog */}
      {loanForPayment && (
        <Dialog open={isRecordPaymentDialogOpen} onOpenChange={(open) => {
            setIsRecordPaymentDialogOpen(open);
            if (!open) setLoanForPayment(null);
        }}>
          <DialogContent className="sm:max-w-md bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="flex items-center text-xl">
                <Receipt className="mr-2 h-5 w-5 text-primary" />
                Enregistrer un Paiement pour le Prêt {loanForPayment.id}
              </DialogTitle>
              <DialogDescription className="mt-1">
                Titulaire: {loanForPayment.accountHolderFullName}<br/>
                Mensualité estimée: {loanForPayment.monthlyPayment?.toFixed(2)} {getCurrencySymbol(loanForPayment.currency)}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleRecordPaymentSubmit} className="space-y-4 py-4">
              <div>
                <Label htmlFor="paymentAmount">Montant du Paiement ({getCurrencySymbol(loanForPayment.currency)})</Label>
                <Input 
                  id="paymentAmount" 
                  name="paymentAmount"
                  type="number" 
                  defaultValue={loanForPayment.monthlyPayment?.toFixed(2)}
                  className="bg-input text-foreground"
                  step="0.01"
                  required
                />
              </div>
              <div>
                <Label htmlFor="paymentDate">Date du Paiement</Label>
                <Input 
                  id="paymentDate" 
                  name="paymentDate"
                  type="date" 
                  defaultValue={format(new Date(), 'yyyy-MM-dd')} 
                  className="bg-input text-foreground"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Ceci est une simulation. La logique de mise à jour du solde du prêt sera implémentée ultérieurement.
              </p>
              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setIsRecordPaymentDialogOpen(false)}>Annuler</Button>
                <Button type="submit">Confirmer Paiement (Simulation)</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* View Loan Details Dialog */}
      {loanForDetails && (
        <Dialog open={isViewLoanDetailsDialogOpen} onOpenChange={(open) => {
            setIsViewLoanDetailsDialogOpen(open);
            if (!open) setLoanForDetails(null);
        }}>
          <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="flex items-center text-xl">
                <Eye className="mr-2 h-5 w-5 text-primary" />
                Détails du Prêt {loanForDetails.id}
              </DialogTitle>
              <DialogDescription className="mt-1">
                Informations complètes du prêt pour {loanForDetails.accountHolderFullName}.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-3 text-sm max-h-[70vh] overflow-y-auto pr-2">
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Titulaire :</span>
                <span className="col-span-2">{loanForDetails.accountHolderFullName}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Montant du Prêt :</span>
                <span className="col-span-2 font-medium text-green-600">{loanForDetails.loanAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {getCurrencySymbol(loanForDetails.currency)}</span>
              </div>
               <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Taux d'Intérêt :</span>
                <span className="col-span-2">{loanForDetails.interestRate}% / an</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Durée :</span>
                <span className="col-span-2">{loanForDetails.termMonths} mois</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Objet du Prêt :</span>
                <span className="col-span-2">{loanForDetails.loanPurpose}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Date de Début :</span>
                <span className="col-span-2">{format(parseISO(loanForDetails.startDate), 'dd MMMM yyyy', { locale: fr })}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Date d'Échéance :</span>
                <span className="col-span-2">{loanForDetails.dueDate}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Mensualité Estimée :</span>
                <span className="col-span-2">~{loanForDetails.monthlyPayment?.toFixed(2)} {getCurrencySymbol(loanForDetails.currency)}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Devise :</span>
                <span className="col-span-2">{loanForDetails.currency}</span>
              </div>
              <div className="grid grid-cols-3 gap-x-2">
                <span className="font-semibold text-muted-foreground col-span-1">Statut :</span>
                <span className={`col-span-2 font-semibold px-2 py-0.5 rounded-full text-xs inline-block w-fit ${loanForDetails.status === 'En cours' ? 'bg-blue-100 text-blue-700' : loanForDetails.status === 'Remboursé' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{loanForDetails.status}</span>
              </div>
              {/* Future: Amortization schedule, payment history etc. */}
            </div>
            <DialogFooter className="mt-6">
              <Button variant="outline" onClick={() => setIsViewLoanDetailsDialogOpen(false)}>Fermer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {!isClient && ( // Fallback for SSR or if client-side hasn't hydrated yet
        <div className="flex-grow flex items-center justify-center">
          <p className="text-xl text-muted-foreground">Chargement de la page...</p>
        </div>
      )}
    </main>
  );
}

