
"use client";

import Link from 'next/link';
import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Users, Search as SearchIcon, Briefcase, CalendarDays, Banknote, UserCircle, Mail, Phone, Landmark, Building } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { format, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  dateOfBirth: string; // ISO string
  email?: string;
  phone?: string;
  accountType: "courant" | "epargne";
  initialDeposit?: number;
  currency: "EUR" | "USD" | "DZD";
  balance: number;
  creationDate: string; // ISO string
}

export default function ConsultationComptesPage() {
  const { toast } = useToast();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (isClient) {
      try {
        const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
        if (storedAccounts) {
          const parsedAccounts: BankAccount[] = JSON.parse(storedAccounts);
          // Basic validation
          if (Array.isArray(parsedAccounts) && parsedAccounts.every(acc => acc && acc.id && acc.accountNumber)) {
            setAccounts(parsedAccounts);
          } else {
            console.warn("Données des comptes bancaires corrompues dans localStorage. Réinitialisation.");
            localStorage.removeItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
            setAccounts([]);
          }
        } else {
          setAccounts([]);
        }
      } catch (error) {
        console.error("Erreur lors du chargement des comptes depuis localStorage:", error);
        toast({
          title: "Erreur de Chargement",
          description: "Impossible de charger les comptes. Les données ont peut-être été corrompues.",
          variant: "destructive",
        });
        setAccounts([]);
      } finally {
        setIsLoading(false);
      }
    }
  }, [isClient, toast]);

  const filteredAccounts = useMemo(() => {
    if (!searchTerm.trim()) {
      return accounts;
    }
    const lowercasedFilter = searchTerm.toLowerCase();
    return accounts.filter(account =>
      (account.holderFirstName?.toLowerCase() || '').includes(lowercasedFilter) ||
      (account.holderLastName?.toLowerCase() || '').includes(lowercasedFilter) ||
      (account.accountNumber?.toLowerCase() || '').includes(lowercasedFilter) ||
      (account.email?.toLowerCase() || '').includes(lowercasedFilter)
    );
  }, [accounts, searchTerm]);

  const getCurrencySymbol = (currencyCode: string) => {
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <Users className="mr-3 h-8 w-8" />
          Consultation des Comptes Clients
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Rechercher par nom, N° de compte, email..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border bg-input text-foreground shadow-sm text-base"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading && isClient && (
        <div className="flex-grow flex items-center justify-center">
          <p className="text-xl text-muted-foreground">Chargement des comptes...</p>
        </div>
      )}

      {!isLoading && isClient && filteredAccounts.length === 0 && (
        <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
          <p className="text-xl text-muted-foreground text-center">
            {accounts.length === 0 ? "Aucun compte client enregistré pour le moment." : `Aucun compte ne correspond à votre recherche "${searchTerm}".`}
          </p>
        </div>
      )}

      {!isLoading && isClient && filteredAccounts.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAccounts.map(account => (
            <Card key={account.id} className="shadow-lg hover:shadow-primary/20 transition-shadow duration-300 bg-card flex flex-col">
              <CardHeader>
                <CardTitle className="text-xl flex items-center text-primary">
                  <UserCircle className="mr-2 h-6 w-6" />
                  {account.holderFirstName} {account.holderLastName}
                </CardTitle>
                <CardDescription className="text-sm">
                  N° de Compte : <span className="font-semibold text-foreground">{account.accountNumber}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-center">
                  {account.accountType === "courant" ? <Briefcase className="mr-2 h-4 w-4 text-muted-foreground" /> : <Landmark className="mr-2 h-4 w-4 text-muted-foreground" />}
                  Type : <span className="ml-1 font-medium">{account.accountType === "courant" ? "Compte Courant" : "Compte Épargne"}</span>
                </div>
                 <div className="flex items-center">
                  <Banknote className="mr-2 h-4 w-4 text-muted-foreground" />
                  Solde : <span className="ml-1 font-bold text-green-500">{account.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {getCurrencySymbol(account.currency)}</span>
                </div>
                <div className="flex items-center">
                  <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
                  Date de Naissance : <span className="ml-1 font-medium">{format(parseISO(account.dateOfBirth), 'dd MMMM yyyy', { locale: fr })}</span>
                </div>
                {account.email && (
                  <div className="flex items-center">
                    <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                    Email : <span className="ml-1 font-medium">{account.email}</span>
                  </div>
                )}
                {account.phone && (
                  <div className="flex items-center">
                    <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                    Téléphone : <span className="ml-1 font-medium">{account.phone}</span>
                  </div>
                )}
                 <div className="flex items-center">
                  <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
                  Créé le : <span className="ml-1 font-medium">{format(parseISO(account.creationDate), 'dd MMMM yyyy à HH:mm', { locale: fr })}</span>
                </div>
                 <Button variant="outline" size="sm" className="w-full mt-4" onClick={() => {
                    toast({ title: "Fonctionnalité à venir", description: "La vue détaillée du compte sera bientôt disponible." });
                 }}>
                    Voir les Détails du Compte (Bientôt)
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
       {!isClient && ( // Fallback for SSR or if client-side hasn't hydrated yet
        <div className="flex-grow flex items-center justify-center">
          <p className="text-xl text-muted-foreground">Initialisation de la page...</p>
        </div>
      )}
    </main>
  );
}
