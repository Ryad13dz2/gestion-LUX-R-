
"use client";

import Link from 'next/link';
import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, History, Search as SearchIcon, Filter, Download, CalendarIcon, Banknote, ArrowUpCircle, ArrowDownCircle, ChevronsLeft, ChevronsRight, FileSpreadsheet, FileText } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, subDays, addDays, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';


const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccountInfo {
  id: string;
  accountNumber: string;
  holderFullName: string; 
}

interface BankTransaction {
  id: string;
  date: string; // ISO string
  compteNumero: string;
  compteTitulaire: string;
  description: string;
  montant: number; // Positive for credit, negative for debit
  type: 'debit' | 'credit';
  soldeApres?: number;
}

// Generate more diverse simulated transactions
const generateSimulatedTransactions = (accounts: BankAccountInfo[]): BankTransaction[] => {
  const transactions: BankTransaction[] = [];
  const descriptionsDebit = ["Achat Supermarché", "Retrait DAB", "Facture Électricité", "Restaurant Le Gourmet", "Abonnement Streaming", "Loyer Mensuel"];
  const descriptionsCredit = ["Virement Reçu - Salaire", "Remboursement Impôts", "Vente en Ligne", "Cadeau Anniversaire"];
  const numTransactions = 25; // Generate more transactions

  const defaultAccount = accounts.length > 0 ? accounts[0] : { id: 'sim0', accountNumber: 'SIM0001', holderFullName: 'Compte Simulé' };

  for (let i = 0; i < numTransactions; i++) {
    const randomAccount = accounts.length > 0 ? accounts[Math.floor(Math.random() * accounts.length)] : defaultAccount;
    const type = Math.random() > 0.6 ? 'credit' : 'debit';
    const date = subDays(new Date(), Math.floor(Math.random() * 90)).toISOString();
    let description = "";
    let montant = 0;

    if (type === 'debit') {
      description = descriptionsDebit[Math.floor(Math.random() * descriptionsDebit.length)];
      montant = -(Math.floor(Math.random() * 200) + 5);
    } else {
      description = descriptionsCredit[Math.floor(Math.random() * descriptionsCredit.length)];
      montant = Math.floor(Math.random() * 1500) + 50;
    }
    
    transactions.push({
      id: `tx-${Date.now()}-${i}`,
      date,
      compteNumero: randomAccount.accountNumber,
      compteTitulaire: randomAccount.holderFullName,
      description: `${description} #${Math.floor(Math.random() * 1000)}`,
      montant,
      type,
      soldeApres: Math.floor(Math.random() * 5000) + (type === 'credit' ? montant : 0) // very rough simulation
    });
  }
  return transactions.sort((a, b) => parseISO(b.date).getTime() - parseISO(a.date).getTime());
};


export default function HistoriqueTransactionsPage() {
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);
  
  const [allBankAccounts, setAllBankAccounts] = useState<BankAccountInfo[]>([]);
  const [allTransactions, setAllTransactions] = useState<BankTransaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<BankTransaction[]>([]);

  // Filter states
  const [selectedAccountId, setSelectedAccountId] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState<Date | undefined>(subDays(new Date(), 30));
  const [dateTo, setDateTo] = useState<Date | undefined>(new Date());
  const [transactionType, setTransactionType] = useState<string>("all");
  const [minAmount, setMinAmount] = useState<string>("");
  const [maxAmount, setMaxAmount] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");
  
  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    setIsClient(true);
    try {
      const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
      if (storedAccounts) {
        const parsedAccounts = JSON.parse(storedAccounts).map((acc: any) => ({
          id: acc.id,
          accountNumber: acc.accountNumber,
          holderFullName: `${acc.holderFirstName} ${acc.holderLastName}`
        }));
        setAllBankAccounts(parsedAccounts);
        setAllTransactions(generateSimulatedTransactions(parsedAccounts));
      } else {
        const simAccounts = [{ id: 'sim0', accountNumber: 'SIM0001', holderFullName: 'Compte Simulé par Défaut' }];
        setAllBankAccounts(simAccounts);
        setAllTransactions(generateSimulatedTransactions(simAccounts));
      }
    } catch (error) {
        console.error("Erreur de chargement des comptes pour l'historique:", error);
        const simAccounts = [{ id: 'sim0', accountNumber: 'SIM0001', holderFullName: 'Compte Simulé Erreur' }];
        setAllBankAccounts(simAccounts);
        setAllTransactions(generateSimulatedTransactions(simAccounts));
    }
  }, []);

  const applyFilters = () => {
    let tempTransactions = allTransactions;

    // Account filter
    if (selectedAccountId !== "all") {
      const account = allBankAccounts.find(acc => acc.id === selectedAccountId);
      if (account) {
        tempTransactions = tempTransactions.filter(tx => tx.compteNumero === account.accountNumber);
      }
    }

    // Date filter
    if (dateFrom) {
      tempTransactions = tempTransactions.filter(tx => parseISO(tx.date) >= dateFrom);
    }
    if (dateTo) {
      // Set time to end of day for 'dateTo' to include all transactions of that day
      const endOfDayDateTo = new Date(dateTo);
      endOfDayDateTo.setHours(23, 59, 59, 999);
      tempTransactions = tempTransactions.filter(tx => parseISO(tx.date) <= endOfDayDateTo);
    }
    
    // Transaction type filter
    if (transactionType !== "all") {
      tempTransactions = tempTransactions.filter(tx => tx.type === transactionType);
    }

    // Amount filter
    const numMinAmount = parseFloat(minAmount);
    if (!isNaN(numMinAmount)) {
      tempTransactions = tempTransactions.filter(tx => Math.abs(tx.montant) >= numMinAmount);
    }
    const numMaxAmount = parseFloat(maxAmount);
    if (!isNaN(numMaxAmount)) {
      tempTransactions = tempTransactions.filter(tx => Math.abs(tx.montant) <= numMaxAmount);
    }
    
    // Search term filter (description)
    if (searchTerm.trim() !== "") {
      const lowerSearchTerm = searchTerm.toLowerCase();
      tempTransactions = tempTransactions.filter(tx => tx.description.toLowerCase().includes(lowerSearchTerm));
    }
    
    setFilteredTransactions(tempTransactions);
    setCurrentPage(1); // Reset to first page after filtering
    toast({
      title: "Filtres Appliqués (Simulation)",
      description: "Les transactions affichées ont été mises à jour en fonction de vos critères (données simulées).",
    });
  };
  
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(applyFilters, [allTransactions, selectedAccountId, dateFrom, dateTo, transactionType, minAmount, maxAmount, searchTerm]); 

  const paginatedTransactions = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredTransactions.slice(startIndex, endIndex);
  }, [filteredTransactions, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);

  const getCurrencySymbol = (currencyCode: string = "EUR") => { 
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  const handleExport = (type: 'CSV' | 'PDF') => {
    if (filteredTransactions.length === 0) {
      toast({
        title: "Aucune donnée à exporter",
        description: "Aucune transaction ne correspond aux filtres actuels.",
        variant: "destructive",
      });
      return;
    }

    if (type === 'PDF') {
      const doc = new jsPDF();
      doc.text("Historique des Transactions (Simulé)", 14, 15);
      
      const tableColumn = ["Date", "Compte", "Description", "Type", "Montant", "Solde Après"];
      const tableRows: any[][] = [];

      filteredTransactions.forEach(tx => {
        const transactionData = [
          format(parseISO(tx.date), 'dd/MM/yyyy HH:mm', { locale: fr }),
          `${tx.compteTitulaire}\n(${tx.compteNumero})`,
          tx.description,
          tx.type === 'debit' ? 'Débit' : 'Crédit',
          `${tx.montant.toFixed(2)} ${getCurrencySymbol()}`,
          tx.soldeApres !== undefined ? `${tx.soldeApres.toFixed(2)} ${getCurrencySymbol()}` : 'N/A'
        ];
        tableRows.push(transactionData);
      });

      autoTable(doc, {
        head: [tableColumn],
        body: tableRows,
        startY: 25,
        theme: 'striped',
        headStyles: { fillColor: [22, 160, 133] }, // Vert primaire approx
        styles: { fontSize: 8, cellPadding: 1.5 },
        columnStyles: {
          0: { cellWidth: 25 }, // Date
          1: { cellWidth: 35 }, // Compte
          2: { cellWidth: 'auto' }, // Description
          3: { cellWidth: 15 }, // Type
          4: { cellWidth: 20, halign: 'right' }, // Montant
          5: { cellWidth: 20, halign: 'right' }, // Solde Après
        }
      });
      
      doc.save('historique_transactions.pdf');
      toast({
        title: "Export PDF Réussi (Données Simulées)",
        description: "Le fichier PDF de l'historique a été généré et téléchargé.",
      });
      return;
    }

    if (type === 'CSV') {
      const headers = [
        "ID",
        "Date",
        "Numéro de Compte",
        "Titulaire du Compte",
        "Description",
        "Montant",
        "Type",
        "Solde Après (Simulé)"
      ];
      
      const escapeCsvCell = (cellData: any) => {
        const stringData = String(cellData === null || cellData === undefined ? "" : cellData);
        if (stringData.includes(",")) {
          return `"${stringData.replace(/"/g, '""')}"`;
        }
        return stringData;
      };

      const csvRows = [
        headers.join(','),
        ...filteredTransactions.map(tx => [
          escapeCsvCell(tx.id),
          escapeCsvCell(format(parseISO(tx.date), 'yyyy-MM-dd HH:mm:ss')),
          escapeCsvCell(tx.compteNumero),
          escapeCsvCell(tx.compteTitulaire),
          escapeCsvCell(tx.description),
          escapeCsvCell(tx.montant.toFixed(2)),
          escapeCsvCell(tx.type),
          escapeCsvCell(tx.soldeApres !== undefined ? tx.soldeApres.toFixed(2) : '')
        ].join(','))
      ];
      
      const csvString = csvRows.join('\n');
      const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "historique_transactions.csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Export CSV Réussi",
        description: "Le fichier CSV des transactions (simulées) a été téléchargé.",
      });
    }
  };


  if (!isClient) {
    return (
      <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-primary flex items-center">
            <History className="mr-3 h-8 w-8" />
            Historique des Transactions
          </h1>
          <Button variant="outline" asChild>
            <Link href="/banque">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour à la Gestion Bancaire
            </Link>
          </Button>
        </div>
        <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
          <p className="text-xl text-muted-foreground">Chargement de l'historique...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <History className="mr-3 h-8 w-8" />
          Historique des Transactions
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>
        <Alert className="mb-6 border-primary/50 bg-primary/5 text-primary">
            <Info className="h-5 w-5 !text-primary" />
            <AlertTitle className="text-primary font-semibold">Note Importante</AlertTitle>
            <AlertDescription className="text-primary/90">
            Cette page affiche des données de transactions simulées à des fins de démonstration. 
            Les fonctionnalités de filtrage et de pagination opèrent sur ces données simulées.
            </AlertDescription>
        </Alert>

      {/* Filters Card */}
      <Card className="mb-6 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl flex items-center"><Filter className="mr-2 h-5 w-5 text-primary"/>Filtres</CardTitle>
          <CardDescription>Affinez votre recherche de transactions (données et filtres simulés).</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="filter-account">Compte Bancaire</Label>
            <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
              <SelectTrigger id="filter-account" className="bg-input">
                <SelectValue placeholder="Tous les comptes" />
              </SelectTrigger>
              <SelectContent className="bg-popover">
                <SelectItem value="all">Tous les comptes</SelectItem>
                {allBankAccounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.id}>{acc.holderFullName} ({acc.accountNumber})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col">
            <Label htmlFor="date-from">Du (Date)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="date-from"
                  variant={"outline"}
                  className={cn("justify-start text-left font-normal bg-input", !dateFrom && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateFrom ? format(dateFrom, "PPP", { locale: fr }) : <span>Choisir une date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-card">
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} initialFocus />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex flex-col">
            <Label htmlFor="date-to">Au (Date)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="date-to"
                  variant={"outline"}
                  className={cn("justify-start text-left font-normal bg-input", !dateTo && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateTo ? format(dateTo, "PPP", { locale: fr }) : <span>Choisir une date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-card">
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          
          <div>
            <Label htmlFor="filter-type">Type de Transaction</Label>
            <Select value={transactionType} onValueChange={setTransactionType}>
              <SelectTrigger id="filter-type" className="bg-input">
                <SelectValue placeholder="Tous les types" />
              </SelectTrigger>
              <SelectContent className="bg-popover">
                <SelectItem value="all">Tous les types</SelectItem>
                <SelectItem value="debit">Débit</SelectItem>
                <SelectItem value="credit">Crédit</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="filter-min-amount">Montant Minimum</Label>
            <Input id="filter-min-amount" type="number" placeholder="Ex: 10" value={minAmount} onChange={(e) => setMinAmount(e.target.value)} className="bg-input" />
          </div>
          <div>
            <Label htmlFor="filter-max-amount">Montant Maximum</Label>
            <Input id="filter-max-amount" type="number" placeholder="Ex: 500" value={maxAmount} onChange={(e) => setMaxAmount(e.target.value)} className="bg-input" />
          </div>
          
          <div className="md:col-span-2 lg:col-span-3">
            <Label htmlFor="filter-search-term">Recherche par Description</Label>
            <div className="relative">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                id="filter-search-term" 
                type="search" 
                placeholder="Rechercher dans les descriptions..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)} 
                className="bg-input pl-9" 
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transactions Table Card */}
      <Card className="flex-1 flex flex-col shadow-lg">
        <CardHeader className="flex-row items-center justify-between">
          <div>
            <CardTitle className="text-xl">Transactions Récentes (Données Simulées)</CardTitle>
            <CardDescription>
              {filteredTransactions.length} transaction(s) correspondante(s) à vos critères (sur {allTransactions.length} au total simulées).
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => handleExport('CSV')}>
              <FileSpreadsheet className="mr-2 h-4 w-4" /> Exporter CSV
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleExport('PDF')}>
              <FileText className="mr-2 h-4 w-4" /> Exporter PDF
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto">
          {paginatedTransactions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Compte</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Montant</TableHead>
                  <TableHead className="text-right">Solde Après (Sim.)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedTransactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>{format(parseISO(tx.date), 'dd/MM/yyyy HH:mm', { locale: fr })}</TableCell>
                    <TableCell>
                        <div>{tx.compteTitulaire}</div>
                        <div className="text-xs text-muted-foreground">{tx.compteNumero}</div>
                    </TableCell>
                    <TableCell>{tx.description}</TableCell>
                    <TableCell>
                      {tx.type === 'debit' ? (
                        <span className="flex items-center text-destructive">
                          <ArrowDownCircle className="mr-1.5 h-4 w-4" /> Débit
                        </span>
                      ) : (
                        <span className="flex items-center text-green-600">
                          <ArrowUpCircle className="mr-1.5 h-4 w-4" /> Crédit
                        </span>
                      )}
                    </TableCell>
                    <TableCell className={`text-right font-medium ${tx.type === 'debit' ? 'text-destructive' : 'text-green-600'}`}>
                      {tx.type === 'debit' ? '-' : '+'}
                      {Math.abs(tx.montant).toFixed(2)} {getCurrencySymbol()}
                    </TableCell>
                     <TableCell className="text-right">
                      {tx.soldeApres !== undefined ? `${tx.soldeApres.toFixed(2)} ${getCurrencySymbol()}` : 'N/A'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-10">
              <History className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                {allTransactions.length === 0 ? "Aucune transaction simulée disponible." : "Aucune transaction ne correspond à vos filtres."}
              </p>
              {allTransactions.length > 0 && <p className="text-xs text-muted-foreground">Essayez d'élargir vos critères de recherche.</p>}
            </div>
          )}
        </CardContent>
        {totalPages > 1 && (
          <div className="flex justify-between items-center p-4 border-t">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
            >
              <ChevronsLeft className="mr-2 h-4 w-4" /> Précédent
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {currentPage} sur {totalPages}
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
            >
              Suivant <ChevronsRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}
      </Card>
    </main>
  );
}
