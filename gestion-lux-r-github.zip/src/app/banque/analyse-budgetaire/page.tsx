
"use client";

import Link from 'next/link';
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Briefcase, BarChart2, PieChart as PieChartIcon, DollarSign, TrendingUp, TrendingDown, CalendarDays } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { Bar, BarChart, Pie, PieChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Cell, LabelList } from 'recharts';
import { format, getYear, getMonth } from 'date-fns';
import { fr } from 'date-fns/locale';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  currency: string;
}

interface SimulatedTransaction {
  id: string;
  description: string;
  amount: number; // positive for income, negative for expense
  category: string;
  type: 'income' | 'expense';
}

const generateSimulatedTransactions = (currencySymbol: string): SimulatedTransaction[] => {
  const transactions: SimulatedTransaction[] = [];
  const incomeCategories = ["Salaire", "Revenus Locatifs", "Vente Divers"];
  const expenseCategories = ["Alimentation", "Transport", "Loisirs", "Factures", "Shopping", "Santé"];
  const numTransactions = Math.floor(Math.random() * 15) + 10; // 10 to 24 transactions

  for (let i = 0; i < numTransactions; i++) {
    const isIncome = Math.random() < 0.3; // 30% chance of income
    if (isIncome) {
      transactions.push({
        id: `inc-${i}`,
        description: incomeCategories[Math.floor(Math.random() * incomeCategories.length)],
        amount: Math.floor(Math.random() * 2000) + 500,
        category: "Revenu",
        type: 'income',
      });
    } else {
      const category = expenseCategories[Math.floor(Math.random() * expenseCategories.length)];
      transactions.push({
        id: `exp-${i}`,
        description: `${category} - Achat #${Math.floor(Math.random() * 100)}`,
        amount: -(Math.floor(Math.random() * 150) + 10),
        category: category,
        type: 'expense',
      });
    }
  }
  return transactions;
};

const chartConfigBar = {
  total: {
    label: "Montant",
  },
  income: {
    label: "Revenus",
    color: "hsl(var(--chart-2))",
  },
  expenses: {
    label: "Dépenses",
    color: "hsl(var(--chart-1))",
  },
};

const EXPENSE_CATEGORY_COLORS: Record<string, string> = {
  "Alimentation": "hsl(var(--chart-1))",
  "Transport": "hsl(var(--chart-2))",
  "Loisirs": "hsl(var(--chart-3))",
  "Factures": "hsl(var(--chart-4))",
  "Shopping": "hsl(var(--chart-5))",
  "Santé": "hsl(var(--chart-1))", // Re-use for more variety if few categories
  "Autre": "hsl(var(--muted))",
};


export default function AnalyseBudgetairePage() {
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string | undefined>(undefined);
  
  const currentMonth = (new Date().getMonth()).toString();
  const currentYear = new Date().getFullYear().toString();

  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [selectedYear, setSelectedYear] = useState<string>(currentYear);

  const [simulatedData, setSimulatedData] = useState<SimulatedTransaction[]>([]);
  const [currencySymbol, setCurrencySymbol] = useState('€');

  useEffect(() => {
    setIsClient(true);
    try {
      const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
      if (storedAccounts) {
        const parsedAccounts = JSON.parse(storedAccounts);
        setAccounts(parsedAccounts);
        if (parsedAccounts.length > 0) {
          setSelectedAccountId(parsedAccounts[0].id);
          setCurrencySymbol(getCurrencySymbol(parsedAccounts[0].currency));
        }
      }
    } catch (error) {
      console.error("Erreur de chargement des comptes :", error);
      toast({ title: "Erreur", description: "Impossible de charger les comptes bancaires.", variant: "destructive" });
    }
  }, [toast]);

  const getCurrencySymbol = (currencyCode: string | undefined) => {
    if (!currencyCode) return '€';
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  const regenerateSimulatedData = useCallback(() => {
    const account = accounts.find(acc => acc.id === selectedAccountId);
    if (account) {
      const symbol = getCurrencySymbol(account.currency);
      setCurrencySymbol(symbol);
      setSimulatedData(generateSimulatedTransactions(symbol));
      toast({
        title: "Analyse Budgétaire (Simulation)",
        description: `Données simulées générées pour le compte ${account.accountNumber} pour ${format(new Date(parseInt(selectedYear), parseInt(selectedMonth)), 'MMMM yyyy', { locale: fr })}.`,
        duration: 3000,
      });
    } else {
      setSimulatedData([]);
    }
  }, [selectedAccountId, selectedMonth, selectedYear, accounts, toast]);

  useEffect(() => {
    if (isClient && selectedAccountId) {
      regenerateSimulatedData();
    }
  }, [isClient, selectedAccountId, selectedMonth, selectedYear, regenerateSimulatedData]);


  const { totalIncome, totalExpenses, netBalance, incomeExpenseChartData, expenseCategoryChartData } = useMemo(() => {
    const income = simulatedData.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const expenses = simulatedData.filter(t => t.type === 'expense').reduce((sum, t) => sum + Math.abs(t.amount), 0);
    const net = income - expenses;

    const barData = [
      { name: "Flux", income: income, expenses: expenses }
    ];
    
    const expensesByCat = simulatedData
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        const category = t.category || "Autre";
        acc[category] = (acc[category] || 0) + Math.abs(t.amount);
        return acc;
      }, {} as Record<string, number>);

    const pieData = Object.entries(expensesByCat)
      .map(([name, value]) => ({ name, value, fill: EXPENSE_CATEGORY_COLORS[name] || EXPENSE_CATEGORY_COLORS["Autre"] }))
      .sort((a, b) => b.value - a.value); // Sort for consistent pie chart display

    return {
      totalIncome: income,
      totalExpenses: expenses,
      netBalance: net,
      incomeExpenseChartData: barData,
      expenseCategoryChartData: pieData,
    };
  }, [simulatedData]);
  
  const years = useMemo(() => {
    const currentYr = getYear(new Date());
    return Array.from({ length: 5 }, (_, i) => (currentYr - i).toString());
  }, []);

  const months = useMemo(() => {
    return Array.from({ length: 12 }, (_, i) => ({
      value: i.toString(),
      label: format(new Date(0, i), 'MMMM', { locale: fr }),
    }));
  }, []);


  if (!isClient) {
    return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <Briefcase className="mr-3 h-8 w-8" />
          Analyse Budgétaire
        </h1>
      </div>
      <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
        <p className="text-xl text-muted-foreground">Chargement de la page...</p>
      </div>
    </main>
    );
  }


  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <Briefcase className="mr-3 h-8 w-8" />
          Analyse Budgétaire (Simulation)
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <Card className="mb-6 shadow-md">
        <CardHeader>
          <CardTitle className="text-lg">Sélectionnez Compte et Période</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="account-select" className="block text-sm font-medium text-muted-foreground mb-1">Compte Bancaire</label>
            <Select value={selectedAccountId} onValueChange={setSelectedAccountId} disabled={accounts.length === 0}>
              <SelectTrigger id="account-select" className="bg-input text-foreground">
                <SelectValue placeholder={accounts.length > 0 ? "Sélectionner un compte" : "Aucun compte disponible"} />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground">
                {accounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.id}>
                    {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber} ({getCurrencySymbol(acc.currency)})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {accounts.length === 0 && <p className="text-xs text-destructive mt-1">Aucun compte. <Link href="/banque/ouverture-compte" className="underline">Ouvrir un compte</Link>.</p>}
          </div>
           <div>
            <label htmlFor="month-select" className="block text-sm font-medium text-muted-foreground mb-1">Mois</label>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger id="month-select" className="bg-input text-foreground">
                <SelectValue placeholder="Mois" />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground">
                {months.map(month => (
                  <SelectItem key={month.value} value={month.value}>{month.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label htmlFor="year-select" className="block text-sm font-medium text-muted-foreground mb-1">Année</label>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger id="year-select" className="bg-input text-foreground">
                <SelectValue placeholder="Année" />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground">
                {years.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedAccountId ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="shadow-md bg-green-50 border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-green-700 flex items-center"><TrendingUp className="mr-2 h-5 w-5"/>Total Revenus</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-green-600">{totalIncome.toFixed(2)} {currencySymbol}</p>
              </CardContent>
            </Card>
            <Card className="shadow-md bg-red-50 border-red-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium text-red-700 flex items-center"><TrendingDown className="mr-2 h-5 w-5"/>Total Dépenses</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-red-600">{totalExpenses.toFixed(2)} {currencySymbol}</p>
              </CardContent>
            </Card>
            <Card className={`shadow-md ${netBalance >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
              <CardHeader className="pb-2">
                 <CardTitle className={`text-base font-medium flex items-center ${netBalance >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
                    <DollarSign className="mr-2 h-5 w-5"/>Solde Net
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-2xl font-bold ${netBalance >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>{netBalance.toFixed(2)} {currencySymbol}</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg flex items-center"><BarChart2 className="mr-2 h-5 w-5 text-primary" />Revenus vs. Dépenses</CardTitle>
                <CardDescription>Comparaison des flux financiers pour la période sélectionnée.</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer config={chartConfigBar} className="h-[300px] w-full">
                  <BarChart data={incomeExpenseChartData} layout="vertical" margin={{ left: 10, right: 30 }}>
                    <CartesianGrid horizontal={false} />
                    <XAxis type="number" tickFormatter={(value) => `${value.toLocaleString()} ${currencySymbol}`} />
                    <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} hide />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <ChartLegend content={<ChartLegendContent />} />
                    <Bar dataKey="income" fill="var(--color-income)" radius={4} name="Revenus" />
                    <Bar dataKey="expenses" fill="var(--color-expenses)" radius={4} name="Dépenses" />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg flex items-center"><PieChartIcon className="mr-2 h-5 w-5 text-primary" />Répartition des Dépenses</CardTitle>
                <CardDescription>Catégories de dépenses pour la période sélectionnée.</CardDescription>
              </CardHeader>
              <CardContent className="flex items-center justify-center">
                 {expenseCategoryChartData.length > 0 ? (
                    <ChartContainer config={{}} className="h-[300px] w-full aspect-square">
                        <PieChart>
                        <ChartTooltip content={<ChartTooltipContent nameKey="value" />} />
                        <Pie data={expenseCategoryChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} labelLine={false}>
                            {expenseCategoryChartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                            <LabelList
                                dataKey="name"
                                className="fill-background text-xs"
                                formatter={(labelName: string, entry: any) => {
                                    // labelName is entry.name (because dataKey="name")
                                    // Use optional chaining and nullish coalescing for safety
                                    const itemActualValue = entry?.value ?? (entry?.payload?.value ?? 0);
                                    const percentage = totalExpenses > 0 ? (itemActualValue / totalExpenses * 100).toFixed(0) : "0";
                                    return `${labelName} (${percentage}%)`;
                                }}
                                dy={4}
                            />
                        </Pie>
                        <ChartLegend content={<ChartLegendContent nameKey="name" />} className="[&_.recharts-legend-item-text]:capitalize" />
                        </PieChart>
                    </ChartContainer>
                 ) : (
                    <p className="text-muted-foreground py-10">Aucune dépense enregistrée pour cette période.</p>
                 )}
              </CardContent>
            </Card>
          </div>
        </>
      ) : (
        <Card className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md min-h-[300px]">
          <p className="text-xl text-muted-foreground text-center">
            Veuillez sélectionner un compte bancaire pour afficher l'analyse budgétaire.
          </p>
        </Card>
      )}
       <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Toutes les données financières affichées sur cette page sont simulées à des fins de démonstration.
      </p>
    </main>
  );
}
