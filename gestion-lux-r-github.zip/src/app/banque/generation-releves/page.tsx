
"use client";
import Link from 'next/link';
import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, ListChecks, FileText, Loader2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { format, parseISO, getMonth, getYear, startOfMonth, endOfMonth } from 'date-fns';
import { fr } from 'date-fns/locale';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info } from 'lucide-react';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  currency: string;
  balance: number; // This balance is initial, not live
}

interface BankTransaction {
  id: string;
  date: string; // ISO string
  compteNumero: string;
  compteTitulaire: string;
  description: string;
  montant: number; // Positive for credit, negative for debit
  type: 'debit' | 'credit';
}

// Simplified version of simulated transactions for statements
const generateSimulatedTransactionsForAccount = (accountNumber: string, accountHolder: string, numTransactions: number = 15): BankTransaction[] => {
  const transactions: BankTransaction[] = [];
  const descriptionsDebit = ["Paiement Facture Mobile", "Achat en Ligne", "Retrait DAB", "Restaurant", "Abonnement Média"];
  const descriptionsCredit = ["Virement Reçu - Salaire", "Remboursement Divers", "Intérêts Perçus"];
  
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth();

  for (let i = 0; i < numTransactions; i++) {
    const type = Math.random() > 0.6 ? 'credit' : 'debit';
    // Generate transactions for the last 3-4 months for variety
    const transactionMonth = (currentMonth - Math.floor(Math.random() * 4) + 12) % 12;
    const transactionYear = transactionMonth > currentMonth ? currentYear -1 : currentYear;
    const day = Math.floor(Math.random() * 28) + 1;
    const date = new Date(transactionYear, transactionMonth, day).toISOString();

    let description = "";
    let montant = 0;

    if (type === 'debit') {
      description = descriptionsDebit[Math.floor(Math.random() * descriptionsDebit.length)];
      montant = -(Math.floor(Math.random() * 150) + 5);
    } else {
      description = descriptionsCredit[Math.floor(Math.random() * descriptionsCredit.length)];
      montant = Math.floor(Math.random() * 1200) + 50;
    }
    
    transactions.push({
      id: `stmt-tx-${accountNumber}-${Date.now()}-${i}`,
      date,
      compteNumero: accountNumber,
      compteTitulaire: accountHolder,
      description: `${description} #${Math.floor(Math.random() * 1000)}`,
      montant,
      type,
    });
  }
  return transactions.sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime());
};


export default function GenerationRelevesPage() {
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string | undefined>(undefined);
  const [selectedMonth, setSelectedMonth] = useState<string | undefined>((new Date().getMonth()).toString()); // Default to previous month
  const [selectedYear, setSelectedYear] = useState<string | undefined>(new Date().getFullYear().toString());
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsClient(true);
    try {
      const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
      if (storedAccounts) {
        setAccounts(JSON.parse(storedAccounts));
      }
    } catch (error) {
      console.error("Erreur de chargement des comptes :", error);
      toast({ title: "Erreur", description: "Impossible de charger les comptes bancaires.", variant: "destructive" });
    }
  }, [toast]);

  const years = useMemo(() => {
    const currentYr = new Date().getFullYear();
    return Array.from({ length: 5 }, (_, i) => (currentYr - i).toString());
  }, []);

  const months = useMemo(() => {
    return Array.from({ length: 12 }, (_, i) => ({
      value: i.toString(),
      label: format(new Date(0, i), 'MMMM', { locale: fr }),
    }));
  }, []);
  
  const getCurrencySymbol = (currencyCode: string | undefined) => {
    if (!currencyCode) return '€'; // Default
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  const handleGenerateStatement = async () => {
    if (!selectedAccountId || !selectedMonth || !selectedYear) {
      toast({ title: "Sélection requise", description: "Veuillez sélectionner un compte, un mois et une année.", variant: "destructive" });
      return;
    }
    setIsLoading(true);

    const account = accounts.find(acc => acc.id === selectedAccountId);
    if (!account) {
      toast({ title: "Erreur", description: "Compte sélectionné non trouvé.", variant: "destructive" });
      setIsLoading(false);
      return;
    }

    const monthNumber = parseInt(selectedMonth);
    const yearNumber = parseInt(selectedYear);
    const periodStart = startOfMonth(new Date(yearNumber, monthNumber));
    const periodEnd = endOfMonth(new Date(yearNumber, monthNumber));

    // Simulate fetching transactions for this account and period
    // In a real app, this would be an API call or complex local data query
    const allSimulatedTransactions = generateSimulatedTransactionsForAccount(account.accountNumber, `${account.holderFirstName} ${account.holderLastName}`, 50);
    const transactionsForPeriod = allSimulatedTransactions.filter(tx => {
      const txDate = parseISO(tx.date);
      return tx.compteNumero === account.accountNumber && txDate >= periodStart && txDate <= periodEnd;
    });

    if (transactionsForPeriod.length === 0) {
        toast({ title: "Aucune transaction", description: `Aucune transaction trouvée pour ${account.accountNumber} pour ${format(periodStart, 'MMMM yyyy', { locale: fr })}.`, variant: "default" });
        setIsLoading(false);
        return;
    }
    
    try {
      const doc = new jsPDF();
      const pageHeight = doc.internal.pageSize.height;
      let yPos = 20;

      // Header
      doc.setFontSize(18);
      doc.text("LUX-R Banque - Relevé de Compte", doc.internal.pageSize.width / 2, yPos, { align: 'center' });
      yPos += 10;
      doc.setFontSize(10);
      doc.text(`Date de Génération: ${format(new Date(), 'dd MMMM yyyy', { locale: fr })}`, 14, yPos);
      yPos += 7;

      doc.setFontSize(12);
      doc.text(`Titulaire: ${account.holderFirstName} ${account.holderLastName}`, 14, yPos);
      yPos += 7;
      doc.text(`Compte N°: ${account.accountNumber}`, 14, yPos);
      yPos += 7;
      doc.text(`Période du Relevé: ${format(periodStart, 'MMMM yyyy', { locale: fr })}`, 14, yPos);
      yPos += 10;

      // Simulated Summary
      doc.setFontSize(14);
      doc.text("Résumé du Compte (Simulation)", 14, yPos);
      yPos += 7;
      doc.setFontSize(10);
      const currencySymbol = getCurrencySymbol(account.currency);
      // These are entirely simulated values
      const soldePrecedentSimule = (Math.random() * 5000 + 1000).toFixed(2);
      const totalCredits = transactionsForPeriod.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.montant, 0);
      const totalDebits = transactionsForPeriod.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.montant, 0);
      const nouveauSoldeSimule = (parseFloat(soldePrecedentSimule) + totalCredits + totalDebits).toFixed(2);

      doc.text(`Solde au ${format(startOfMonth(periodStart), 'dd/MM/yyyy', { locale: fr })}: ${soldePrecedentSimule} ${currencySymbol}`, 14, yPos);
      yPos += 5;
      doc.text(`Total des Dépôts/Crédits: + ${totalCredits.toFixed(2)} ${currencySymbol}`, 14, yPos);
      yPos += 5;
      doc.text(`Total des Retraits/Débits: ${totalDebits.toFixed(2)} ${currencySymbol}`, 14, yPos); // Debits are already negative
      yPos += 5;
      doc.text(`Solde au ${format(endOfMonth(periodStart), 'dd/MM/yyyy', { locale: fr })}: ${nouveauSoldeSimule} ${currencySymbol}`, 14, yPos);
      yPos += 10;

      // Transaction Table
      doc.setFontSize(14);
      doc.text("Détail des Opérations", 14, yPos);
      yPos += 2; // autoTable will add its own margin

      const tableColumn = ["Date", "Description", "Débit", "Crédit"];
      const tableRows: any[][] = [];

      transactionsForPeriod.forEach(tx => {
        const transactionData = [
          format(parseISO(tx.date), 'dd/MM/yy', { locale: fr }),
          tx.description,
          tx.type === 'debit' ? Math.abs(tx.montant).toFixed(2) + ` ${currencySymbol}` : '',
          tx.type === 'credit' ? tx.montant.toFixed(2) + ` ${currencySymbol}`: '',
        ];
        tableRows.push(transactionData);
      });

      autoTable(doc, {
        head: [tableColumn],
        body: tableRows,
        startY: yPos,
        theme: 'striped',
        headStyles: { fillColor: [34, 139, 34] }, // Vert
        styles: { fontSize: 9, cellPadding: 1.5 },
        columnStyles: {
            2: { halign: 'right' },
            3: { halign: 'right' },
        },
        didDrawPage: (data) => {
            // Footer on each page
            const pageNum = doc.internal.getCurrentPageInfo().pageNumber;
            doc.setFontSize(8);
            doc.text(`Page ${pageNum}`, data.settings.margin.left, pageHeight - 10);
        }
      });
      
      doc.save(`releve_compte_${account.accountNumber}_${selectedMonth}_${selectedYear}.pdf`);
      toast({ title: "Relevé Généré", description: "Le relevé de compte PDF a été téléchargé.", className: "bg-green-100 text-green-800 border-green-300" });

    } catch (error) {
        console.error("Erreur lors de la génération PDF:", error);
        toast({ title: "Erreur PDF", description: "Une erreur est survenue lors de la génération du relevé.", variant: "destructive" });
    } finally {
        setIsLoading(false);
    }
  };

  if (!isClient) {
    return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <ListChecks className="mr-3 h-8 w-8" />
          Génération de Relevés de Compte
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>
      <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
        <p className="text-xl text-muted-foreground">Chargement de la page...</p>
      </div>
    </main>
    );
  }

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <ListChecks className="mr-3 h-8 w-8" />
          Génération de Relevés de Compte
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <Alert className="mb-6 border-primary/50 bg-primary/5 text-primary">
        <Info className="h-5 w-5 !text-primary" />
        <AlertTitle className="text-primary font-semibold">Note sur les Données</AlertTitle>
        <AlertDescription className="text-primary/90">
          Cette page utilise les comptes enregistrés localement. Les transactions affichées sur le relevé sont <strong>simulées</strong> à des fins de démonstration et ne reflètent pas des opérations réelles.
        </AlertDescription>
      </Alert>

      <Card className="w-full max-w-lg mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl">Options du Relevé</CardTitle>
          <CardDescription>Sélectionnez un compte et une période pour générer le relevé.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="account-select">Compte Bancaire</Label>
            <Select value={selectedAccountId} onValueChange={setSelectedAccountId} disabled={accounts.length === 0}>
              <SelectTrigger id="account-select" className="bg-input text-foreground">
                <SelectValue placeholder={accounts.length > 0 ? "Sélectionner un compte" : "Aucun compte disponible"} />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground">
                {accounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.id}>
                    {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {accounts.length === 0 && <p className="text-xs text-destructive mt-1">Aucun compte client n'a été créé. Veuillez d'abord <Link href="/banque/ouverture-compte" className="underline">ouvrir un compte</Link>.</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="month-select">Mois</Label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger id="month-select" className="bg-input text-foreground">
                  <SelectValue placeholder="Mois" />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground">
                  {months.map(month => (
                    <SelectItem key={month.value} value={month.value}>{month.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="year-select">Année</Label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger id="year-select" className="bg-input text-foreground">
                  <SelectValue placeholder="Année" />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground">
                  {years.map(year => (
                    <SelectItem key={year} value={year}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleGenerateStatement} 
            className="w-full" 
            disabled={!selectedAccountId || isLoading || accounts.length === 0}
          >
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <FileText className="mr-2 h-4 w-4" />
            )}
            {isLoading ? "Génération en cours..." : "Générer le Relevé (PDF)"}
          </Button>
        </CardContent>
      </Card>
      
      <p className="text-center text-xs text-muted-foreground mt-8">
        Les relevés générés sont basés sur des transactions simulées.
      </p>
    </main>
  );
}
