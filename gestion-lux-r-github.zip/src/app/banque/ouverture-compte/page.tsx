
"use client";

import Link from 'next/link';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { CalendarIcon } from "lucide-react";

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, PlusCircle, Banknote, User, Mail, Phone, CalendarDays as CalendarDaysIcon } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import React, { useState, useEffect } from 'react';
import { useNotifications } from '@/contexts/NotificationContext';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

const accountFormSchema = z.object({
  holderLastName: z.string().min(2, { message: "Le nom doit contenir au moins 2 caractères." }),
  holderFirstName: z.string().min(2, { message: "Le prénom doit contenir au moins 2 caractères." }),
  dateOfBirth: z.date({ required_error: "La date de naissance est requise." }),
  email: z.string().email({ message: "Veuillez entrer une adresse email valide." }).optional().or(z.literal('')),
  phone: z.string().optional().or(z.literal('')),
  accountType: z.enum(["courant", "epargne"], { required_error: "Le type de compte est requis." }),
  initialDeposit: z.preprocess(
    (val) => (val === "" ? undefined : Number(val)),
    z.number().positive({ message: "Le dépôt initial doit être un nombre positif." }).optional()
  ),
  currency: z.enum(["EUR", "USD", "DZD"], { required_error: "La devise est requise." }),
});

type AccountFormValues = z.infer<typeof accountFormSchema>;

interface BankAccount extends AccountFormValues {
  id: string;
  accountNumber: string;
  balance: number;
  creationDate: string;
}

export default function OuvertureComptePage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const form = useForm<AccountFormValues>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: {
      holderLastName: "",
      holderFirstName: "",
      email: "",
      phone: "",
      initialDeposit: undefined,
    },
  });

  function generateAccountNumber(): string {
    // Simple account number generator for now
    return `LUXR${Date.now().toString().slice(-8)}`;
  }

  async function onSubmit(data: AccountFormValues) {
    if (!isClient) return;

    try {
      const newAccount: BankAccount = {
        id: Date.now().toString(),
        accountNumber: generateAccountNumber(),
        ...data,
        balance: data.initialDeposit || 0,
        creationDate: new Date().toISOString(),
      };

      const existingAccounts: BankAccount[] = JSON.parse(localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY) || '[]');
      localStorage.setItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY, JSON.stringify([...existingAccounts, newAccount]));

      toast({
        title: "Compte Créé avec Succès (Local)",
        description: `Le compte N°${newAccount.accountNumber} pour ${data.holderFirstName} ${data.holderLastName} a été créé.`,
        className: "bg-green-100 text-green-800 border-green-300",
      });
      addNotification("Nouveau Compte Bancaire", `Compte ${newAccount.accountNumber} créé pour ${data.holderFirstName} ${data.holderLastName}.`);
      form.reset();
    } catch (error) {
      console.error("Erreur lors de la sauvegarde du compte:", error);
      toast({
        title: "Erreur de Sauvegarde",
        description: "Une erreur est survenue lors de la création du compte. Vérifiez la console.",
        variant: "destructive",
      });
    }
  }

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <PlusCircle className="mr-3 h-8 w-8" />
          Ouverture de Compte Client
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <Card className="w-full max-w-2xl mx-auto shadow-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Informations du Nouveau Compte</CardTitle>
          <CardDescription>Veuillez remplir tous les champs requis pour créer un nouveau compte bancaire.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="holderLastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Nom du Titulaire</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: TALEB" {...field} className="bg-input border-border text-foreground" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="holderFirstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Prénom du Titulaire</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Ryad Mohamed" {...field} className="bg-input border-border text-foreground" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel className="flex items-center"><CalendarDaysIcon className="mr-2 h-4 w-4 text-primary" />Date de Naissance</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal bg-input border-border text-foreground hover:bg-accent",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: fr })
                            ) : (
                              <span>Choisir une date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) =>
                            date > new Date() || date < new Date("1900-01-01")
                          }
                          initialFocus
                          className="bg-card text-card-foreground"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Mail className="mr-2 h-4 w-4 text-primary" />Adresse Email (Optionnel)</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="Ex: utilisateur@example.com" {...field} className="bg-input border-border text-foreground" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Phone className="mr-2 h-4 w-4 text-primary" />Téléphone (Optionnel)</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: +33 6 00 00 00 00" {...field} className="bg-input border-border text-foreground" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="accountType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Type de Compte</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder="Sélectionner un type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          <SelectItem value="courant">Compte Courant</SelectItem>
                          <SelectItem value="epargne">Compte Épargne</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Devise</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder="Sélectionner une devise" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          <SelectItem value="EUR">EUR (€)</SelectItem>
                          <SelectItem value="USD">USD ($)</SelectItem>
                          <SelectItem value="DZD">DZD (DA)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
               <FormField
                control={form.control}
                name="initialDeposit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Dépôt Initial (Optionnel)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="Ex: 1000" {...field} onChange={event => field.onChange(event.target.value === "" ? undefined : +event.target.value)} className="bg-input border-border text-foreground" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={form.formState.isSubmitting || !isClient}>
                {form.formState.isSubmitting ? 'Création en cours...' : 'Créer le Compte'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Les comptes sont actuellement sauvegardés localement dans votre navigateur.
      </p>
    </main>
  );
}
