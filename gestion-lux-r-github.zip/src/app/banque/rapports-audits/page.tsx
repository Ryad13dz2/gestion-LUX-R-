
"use client";
import Link from 'next/link';
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, FileWarning, ClipboardList, ShieldAlert, UserCheck, SearchX, CalendarDays, FileText, Download, Filter, Users, FileDigit, AlertTriangle, RotateCw } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from "@/lib/utils";
import { format, subDays, startOfMonth, endOfMonth } from "date-fns";
import { fr } from "date-fns/locale";
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';


interface ReportDialogState {
  activity: boolean;
  compliance: boolean;
  accessAudit: boolean;
  suspiciousTx: boolean;
}

interface AccountSelectionDialogState {
  open: boolean;
  selectedAccounts: string[];
}

interface AuditLogFilterDialogState {
  open: boolean;
  filterDateFrom?: Date;
  filterDateTo?: Date;
  filterUser?: string;
  filterActionType?: string;
}


export default function RapportsAuditsPage() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState<ReportDialogState>({
    activity: false,
    compliance: false,
    accessAudit: false,
    suspiciousTx: false,
  });

  const [activityReportDateRange, setActivityReportDateRange] = useState<{from?: Date, to?: Date}>({
    from: startOfMonth(subDays(new Date(), 30)),
    to: endOfMonth(subDays(new Date(), 0)),
  });

  const [accountSelectionDialog, setAccountSelectionDialog] = useState<AccountSelectionDialogState>({
    open: false,
    selectedAccounts: [],
  });

  const [auditLogFilterDialog, setAuditLogFilterDialog] = useState<AuditLogFilterDialogState>({
    open: false,
    filterDateFrom: subDays(new Date(), 7),
    filterDateTo: new Date(),
    filterUser: "",
    filterActionType: "all",
  });

  const simulatedAccountsForSelection = [
    { id: 'all', name: 'Tous les comptes' },
    { id: 'acc1', name: 'Compte Courant - Jean Dupont (ACC001)' },
    { id: 'acc2', name: 'Compte Épargne - Marie Durand (ACC002)' },
    { id: 'acc3', name: 'Compte Entreprise - Tech Solutions (ACC003)' },
    { id: 'acc4', name: 'Compte Joint - Paul & Sophie Martin (ACC004)' },
  ];

  const complianceModules = [
    { id: 'kyc', label: 'Conformité KYC/AML' },
    { id: 'rgpd', label: 'Conformité RGPD' },
    { id: 'fatca', label: 'Conformité FATCA' },
  ];
  const [selectedComplianceModules, setSelectedComplianceModules] = useState<string[]>([]);

  const simulatedAuditLogs = [
    { timestamp: '2024-07-29 10:15:30', user: 'admin_banque', action: 'Connexion Réussie', ip: '192.168.1.10', details: 'Via navigateur Chrome' },
    { timestamp: '2024-07-29 10:16:05', user: 'employe_01', action: 'Consultation Compte 00123', ip: '10.0.0.5', details: 'Client ID: CUST001' },
    { timestamp: '2024-07-29 10:20:45', user: 'admin_banque', action: 'Modification Paramètre Sécurité', ip: '192.168.1.10', details: 'Activation 2FA pour employe_02' },
    { timestamp: '2024-07-28 15:00:12', user: 'employe_03', action: 'Tentative Accès Non Autorisé', ip: '203.0.113.45', details: 'Module: Gestion des Prêts' },
    { timestamp: '2024-07-27 11:30:00', user: 'employe_01', action: 'Ouverture Compte', ip: '10.0.0.5', details: 'Compte N° ACC005 ouvert pour John Doe.' },
    { timestamp: '2024-07-26 18:05:00', user: 'admin_banque', action: 'Déconnexion', ip: '192.168.1.10', details: 'Session terminée' },
  ];

  const [suspiciousTxSensitivity, setSuspiciousTxSensitivity] = useState<string>("medium");


  const handleGenerateReport = (reportType: keyof ReportDialogState) => {
    if (reportType === 'activity') {
      if (!activityReportDateRange.from || !activityReportDateRange.to) {
        toast({
          title: "Période Requise",
          description: "Veuillez sélectionner une date de début et de fin pour le rapport d'activité.",
          variant: "destructive",
        });
        return;
      }

      const doc = new jsPDF();
      const pageHeight = doc.internal.pageSize.height;
      let yPos = 20;

      doc.setFontSize(18);
      doc.text("Rapport d'Activité des Comptes (Simulation)", doc.internal.pageSize.width / 2, yPos, { align: 'center' });
      yPos += 10;
      doc.setFontSize(10);
      doc.text(`Date de Génération: ${format(new Date(), 'dd MMMM yyyy', { locale: fr })}`, 14, yPos);
      yPos += 7;
      doc.text(`Période: Du ${format(activityReportDateRange.from, 'dd/MM/yyyy', { locale: fr })} au ${format(activityReportDateRange.to, 'dd/MM/yyyy', { locale: fr })}`, 14, yPos);
      yPos += 7;
      const accountsForReport = accountSelectionDialog.selectedAccounts.length === 0 || accountSelectionDialog.selectedAccounts.includes('all')
        ? 'Tous les comptes (simulation)'
        : `Comptes: ${accountSelectionDialog.selectedAccounts.map(id => simulatedAccountsForSelection.find(acc => acc.id === id)?.name.split('(')[0].trim() || id).join(', ')} (simulation)`;
      doc.text(accountsForReport, 14, yPos);
      yPos += 10;

      const activities = [
        { date: format(subDays(activityReportDateRange.to, 2), 'dd/MM/yy'), compte: 'ACC001', description: 'Dépôt espèces', montant: '+500.00 EUR', solde: '2,500.00 EUR' },
        { date: format(subDays(activityReportDateRange.to, 5), 'dd/MM/yy'), compte: 'ACC002', description: 'Retrait DAB', montant: '-50.00 EUR', solde: '1,230.50 EUR' },
        { date: format(subDays(activityReportDateRange.to, 7), 'dd/MM/yy'), compte: 'ACC001', description: 'Paiement Facture XYZ', montant: '-75.20 EUR', solde: '2,000.00 EUR' },
        { date: format(subDays(activityReportDateRange.to, 10), 'dd/MM/yy'), compte: 'ACC003', description: 'Virement entrant - SALAIRE', montant: '+1,800.00 EUR', solde: '3,450.00 EUR' },
        { date: format(subDays(activityReportDateRange.to, 12), 'dd/MM/yy'), compte: 'ACC002', description: 'Achat en ligne AMAZON', montant: '-35.99 EUR', solde: '1,280.50 EUR' },
      ];

      const tableColumn = ["Date", "Compte (Simulé)", "Description", "Montant", "Solde Après (Simulé)"];
      const tableRows = activities.map(act => [act.date, act.compte, act.description, act.montant, act.solde]);

      autoTable(doc, {
        head: [tableColumn],
        body: tableRows,
        startY: yPos,
        theme: 'striped',
        headStyles: { fillColor: [34, 139, 34] },
        styles: { fontSize: 9, cellPadding: 1.5 },
        columnStyles: {
            3: { halign: 'right' },
            4: { halign: 'right' },
        },
        didDrawPage: (data) => {
            const pageNum = doc.internal.getCurrentPageInfo().pageNumber;
            doc.setFontSize(8);
            doc.text(`Page ${pageNum}`, data.settings.margin.left, pageHeight - 10);
        }
      });

      doc.save(`rapport_activite_${format(activityReportDateRange.from, 'yyyyMMdd')}_${format(activityReportDateRange.to, 'yyyyMMdd')}.pdf`);
      toast({ title: "Rapport d'Activité Généré", description: "Le rapport PDF (basé sur des données simulées) a été téléchargé.", className: "bg-green-100 text-green-800 border-green-300" });

    } else {
      toast({
        title: `Génération du Rapport (Simulation)`,
        description: `Le ${reportType.replace(/([A-Z])/g, ' $1').trim()} est en cours de génération (simulation). Un fichier PDF/CSV serait normalement produit ici.`,
        className: "bg-blue-100 text-blue-700 border-blue-300",
      });
    }
    setDialogOpen(prev => ({ ...prev, [reportType]: false }));
    if (reportType === 'compliance') setSelectedComplianceModules([]);
  };

  const handleAccountSelectionChange = (accountId: string, checked: boolean | string) => {
    if (typeof checked === 'string') return;

    if (accountId === 'all') {
        setAccountSelectionDialog(prev => ({
            ...prev,
            selectedAccounts: checked ? ['all', ...simulatedAccountsForSelection.filter(a => a.id !== 'all').map(a => a.id)] : []
        }));
    } else {
        setAccountSelectionDialog(prev => {
            let newSelectedAccounts = prev.selectedAccounts.filter(id => id !== 'all');
            if (checked) {
                newSelectedAccounts = [...newSelectedAccounts, accountId];
            } else {
                newSelectedAccounts = newSelectedAccounts.filter(id => id !== accountId);
            }
            // Check if all individual accounts are selected
            const allIndividualSelected = simulatedAccountsForSelection
                .filter(a => a.id !== 'all')
                .every(a => newSelectedAccounts.includes(a.id));

            if (allIndividualSelected) {
                 return { ...prev, selectedAccounts: ['all', ...newSelectedAccounts] };
            }
            return { ...prev, selectedAccounts: newSelectedAccounts };
        });
    }
  };

  const handleApplyAuditLogFilters = () => {
    toast({
      title: "Filtres du Journal d'Audit (Simulation)",
      description: `Les filtres (Période: ${auditLogFilterDialog.filterDateFrom ? format(auditLogFilterDialog.filterDateFrom, "dd/MM/yy") : 'N/A'} - ${auditLogFilterDialog.filterDateTo ? format(auditLogFilterDialog.filterDateTo, "dd/MM/yy") : 'N/A'}, Utilisateur: ${auditLogFilterDialog.filterUser || 'Tous'}, Type: ${auditLogFilterDialog.filterActionType || 'Tous'}) seraient appliqués ici.`,
      className: "bg-blue-100 text-blue-700 border-blue-300",
      duration: 5000,
    });
    setAuditLogFilterDialog(prev => ({ ...prev, open: false }));
  };

  const handleExportAuditLog = () => {
    if (simulatedAuditLogs.length === 0) {
      toast({
        title: "Aucune donnée à exporter",
        description: "Le journal d'audit simulé est vide.",
        variant: "destructive",
      });
      return;
    }

    const headers = ["timestamp", "user", "action", "ip", "details"];
    const csvContent = [
      headers.join(','),
      ...simulatedAuditLogs.map(log =>
        headers.map(header => JSON.stringify((log as any)[header] || "")).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'journal_audit_simulation.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Export CSV Réussi", description: "Le journal d'audit simulé a été téléchargé en CSV." });
    } else {
      toast({ title: "Export CSV Échoué", description: "Votre navigateur ne supporte pas le téléchargement direct.", variant: "destructive" });
    }
  };


  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <FileWarning className="mr-3 h-8 w-8" />
          Rapports et Audits
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Rapport d'Activité des Comptes */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center"><ClipboardList className="mr-2 h-6 w-6 text-primary" />Rapport d'Activité des Comptes</CardTitle>
            <CardDescription>Générez des rapports PDF détaillés sur l'activité des comptes clients sur une période donnée.</CardDescription>
          </CardHeader>
          <CardContent>
            <Dialog open={dialogOpen.activity} onOpenChange={(open) => setDialogOpen(prev => ({ ...prev, activity: open }))}>
              <DialogTrigger asChild>
                <Button className="w-full">Générer ce rapport (PDF)</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="flex items-center"><ClipboardList className="mr-2 h-5 w-5 text-primary"/>Paramètres du Rapport d'Activité</DialogTitle>
                  <DialogDescription>Sélectionnez la période et les comptes. Le PDF généré utilisera des données d'activité simulées.</DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col space-y-1.5">
                      <Label htmlFor="activity-date-from">Du</Label>
                       <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            id="activity-date-from"
                            variant={"outline"}
                            className={cn("justify-start text-left font-normal bg-input", !activityReportDateRange.from && "text-muted-foreground")}
                          >
                            <CalendarDays className="mr-2 h-4 w-4" />
                            {activityReportDateRange.from ? format(activityReportDateRange.from, "PPP", { locale: fr }) : <span>Date de début</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-popover"><Calendar mode="single" selected={activityReportDateRange.from} onSelect={(date) => setActivityReportDateRange(prev => ({...prev, from:date ? date : undefined}))} initialFocus /></PopoverContent>
                      </Popover>
                    </div>
                     <div className="flex flex-col space-y-1.5">
                      <Label htmlFor="activity-date-to">Au</Label>
                       <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            id="activity-date-to"
                            variant={"outline"}
                            className={cn("justify-start text-left font-normal bg-input", !activityReportDateRange.to && "text-muted-foreground")}
                          >
                            <CalendarDays className="mr-2 h-4 w-4" />
                            {activityReportDateRange.to ? format(activityReportDateRange.to, "PPP", { locale: fr }) : <span>Date de fin</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-popover"><Calendar mode="single" selected={activityReportDateRange.to} onSelect={(date) => setActivityReportDateRange(prev => ({...prev, to:date ? date : undefined}))} initialFocus /></PopoverContent>
                      </Popover>
                    </div>
                  </div>
                  <div>
                    <Label>Comptes à inclure</Label>
                     <p className="text-xs text-muted-foreground mb-1">
                        {accountSelectionDialog.selectedAccounts.length === 0 || accountSelectionDialog.selectedAccounts.includes('all')
                          ? "Tous les comptes seront inclus (simulation)."
                          : `Comptes sélectionnés: ${accountSelectionDialog.selectedAccounts.filter(id => id !== 'all').length} (simulation).`}
                     </p>
                    <Button
                        variant="outline"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => setAccountSelectionDialog(prev => ({...prev, open: true}))}
                    >
                        <Users className="mr-2 h-4 w-4" /> Sélectionner des comptes
                    </Button>
                  </div>
                  <div>
                    <Label htmlFor="activity-format">Format du rapport</Label>
                    <Select defaultValue="pdf" disabled>
                      <SelectTrigger id="activity-format" className="bg-input"><SelectValue /></SelectTrigger>
                      <SelectContent className="bg-popover"><SelectItem value="pdf">PDF (Activé)</SelectItem><SelectItem value="csv" disabled>CSV (Bientôt)</SelectItem></SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                   <Button variant="outline" onClick={() => setDialogOpen(prev => ({...prev, activity: false}))}>Annuler</Button>
                  <Button onClick={() => handleGenerateReport('activity')}>Générer le Rapport (PDF)</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Sub-Dialog for Account Selection */}
            <Dialog open={accountSelectionDialog.open} onOpenChange={(open) => setAccountSelectionDialog(prev => ({...prev, open: open}))}>
                <DialogContent className="sm:max-w-md bg-card text-card-foreground">
                    <DialogHeader>
                        <DialogTitle className="flex items-center"><Users className="mr-2 h-5 w-5 text-primary"/>Sélectionner les Comptes</DialogTitle>
                        <DialogDescription>Choisissez les comptes à inclure dans le rapport d'activité. (La sélection n'affecte pas le PDF simulé actuellement)</DialogDescription>
                    </DialogHeader>
                    <ScrollArea className="py-4 max-h-60">
                        <div className="space-y-2">
                            {simulatedAccountsForSelection.map(account => (
                                <div key={account.id} className="flex items-center space-x-2">
                                    <Checkbox
                                        id={`account-${account.id}`}
                                        checked={accountSelectionDialog.selectedAccounts.includes(account.id)}
                                        onCheckedChange={(checked) => handleAccountSelectionChange(account.id, checked)}
                                    />
                                    <Label htmlFor={`account-${account.id}`} className="font-normal">{account.name}</Label>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setAccountSelectionDialog(prev => ({...prev, open: false}))}>Annuler</Button>
                        <Button onClick={() => {
                            toast({ title: "Sélection Simulée Appliquée", description: `${accountSelectionDialog.selectedAccounts.includes('all') || accountSelectionDialog.selectedAccounts.length === 0 ? 'Tous les comptes' : accountSelectionDialog.selectedAccounts.filter(id => id !== 'all').length + ' compte(s)'} "sélectionné(s)" pour le rapport.` });
                            setAccountSelectionDialog(prev => ({...prev, open: false}));
                        }}>Valider la Sélection</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Rapport de Conformité */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center"><ShieldAlert className="mr-2 h-6 w-6 text-primary" />Rapport de Conformité</CardTitle>
            <CardDescription>Évaluez et documentez la conformité de la banque avec les réglementations en vigueur.</CardDescription>
          </CardHeader>
          <CardContent>
            <Dialog open={dialogOpen.compliance} onOpenChange={(open) => setDialogOpen(prev => ({ ...prev, compliance: open }))}>
              <DialogTrigger asChild>
                <Button className="w-full">Générer ce rapport</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="flex items-center"><ShieldAlert className="mr-2 h-5 w-5 text-primary"/>Paramètres du Rapport de Conformité</DialogTitle>
                  <DialogDescription>Sélectionnez les modules de conformité à inclure.</DialogDescription>
                </DialogHeader>
                 <div className="py-4 space-y-4">
                    <Label>Modules de conformité à vérifier :</Label>
                    <div className="space-y-2">
                        {complianceModules.map(module => (
                            <div key={module.id} className="flex items-center space-x-2">
                                <Checkbox
                                    id={`compliance-${module.id}`}
                                    checked={selectedComplianceModules.includes(module.id)}
                                    onCheckedChange={(checked) => {
                                        setSelectedComplianceModules(prev =>
                                            checked ? [...prev, module.id] : prev.filter(id => id !== module.id)
                                        );
                                    }}
                                />
                                <Label htmlFor={`compliance-${module.id}`} className="font-normal">{module.label}</Label>
                            </div>
                        ))}
                    </div>
                     <p className="text-xs text-muted-foreground">Ceci est une simulation des options de sélection.</p>
                 </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(prev => ({...prev, compliance: false}))}>Annuler</Button>
                  <Button onClick={() => handleGenerateReport('compliance')}>Générer (Simulation)</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Journal d'Audit des Accès */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center"><UserCheck className="mr-2 h-6 w-6 text-primary" />Journal d'Audit des Accès</CardTitle>
            <CardDescription>Consultez l'historique des connexions et des actions importantes des utilisateurs.</CardDescription>
          </CardHeader>
          <CardContent>
            <Dialog open={dialogOpen.accessAudit} onOpenChange={(open) => setDialogOpen(prev => ({ ...prev, accessAudit: open }))}>
              <DialogTrigger asChild>
                <Button className="w-full">Consulter le Journal</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-xl bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="flex items-center"><UserCheck className="mr-2 h-5 w-5 text-primary"/>Journal d'Audit (Exemples)</DialogTitle>
                   <DialogDescription>Exemples d'entrées typiques d'un journal d'audit.</DialogDescription>
                </DialogHeader>
                 <ScrollArea className="h-72 mt-4 pr-3 py-2 border rounded-md bg-muted/30">
                    <ul className="space-y-2 text-sm">
                        {simulatedAuditLogs.map((log, index) => (
                            <li key={index} className="p-2 border-b border-border/30 last:border-b-0">
                                <span className="font-medium text-foreground">{log.timestamp}</span> - User: <span className="text-primary">{log.user}</span> - Action: {log.action}
                                {log.ip && <span className="text-xs text-muted-foreground block">IP: {log.ip}</span>}
                                {log.details && <span className="text-xs text-muted-foreground block">Détails: {log.details}</span>}
                            </li>
                        ))}
                    </ul>
                 </ScrollArea>
                 <div className="flex justify-end space-x-2 mt-2">
                    <Button variant="outline" size="sm" onClick={() => setAuditLogFilterDialog(prev => ({ ...prev, open: true }))}>
                        <Filter className="mr-1 h-3 w-3"/> Filtrer
                    </Button>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={handleExportAuditLog}
                    >
                        <Download className="mr-1 h-3 w-3"/> Exporter (CSV)
                    </Button>
                 </div>
                <DialogFooter className="mt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(prev => ({...prev, accessAudit: false}))}>Fermer</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Sub-Dialog for Audit Log Filters */}
            <Dialog open={auditLogFilterDialog.open} onOpenChange={(open) => setAuditLogFilterDialog(prev => ({ ...prev, open: open }))}>
                <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                    <DialogHeader>
                        <DialogTitle className="flex items-center"><Filter className="mr-2 h-5 w-5 text-primary"/>Options de Filtrage du Journal d'Audit</DialogTitle>
                        <DialogDescription>Affinez les résultats du journal d'audit. (Simulation)</DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="audit-date-from">Du</Label>
                                <Popover>
                                <PopoverTrigger asChild>
                                    <Button id="audit-date-from" variant={"outline"} className={cn("justify-start text-left font-normal bg-input", !auditLogFilterDialog.filterDateFrom && "text-muted-foreground")}>
                                    <CalendarDays className="mr-2 h-4 w-4" />
                                    {auditLogFilterDialog.filterDateFrom ? format(auditLogFilterDialog.filterDateFrom, "PPP", { locale: fr }) : <span>Date de début</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0 bg-popover"><Calendar mode="single" selected={auditLogFilterDialog.filterDateFrom} onSelect={(date) => setAuditLogFilterDialog(prev => ({...prev, filterDateFrom: date || undefined}))} initialFocus /></PopoverContent>
                                </Popover>
                            </div>
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="audit-date-to">Au</Label>
                                <Popover>
                                <PopoverTrigger asChild>
                                    <Button id="audit-date-to" variant={"outline"} className={cn("justify-start text-left font-normal bg-input", !auditLogFilterDialog.filterDateTo && "text-muted-foreground")}>
                                    <CalendarDays className="mr-2 h-4 w-4" />
                                    {auditLogFilterDialog.filterDateTo ? format(auditLogFilterDialog.filterDateTo, "PPP", { locale: fr }) : <span>Date de fin</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0 bg-popover"><Calendar mode="single" selected={auditLogFilterDialog.filterDateTo} onSelect={(date) => setAuditLogFilterDialog(prev => ({...prev, filterDateTo: date || undefined}))} initialFocus /></PopoverContent>
                                </Popover>
                            </div>
                        </div>
                        <div>
                            <Label htmlFor="audit-user-filter">Utilisateur</Label>
                            <Input id="audit-user-filter" placeholder="Ex: admin_banque, employe_01" value={auditLogFilterDialog.filterUser} onChange={(e) => setAuditLogFilterDialog(prev => ({ ...prev, filterUser: e.target.value }))} className="bg-input"/>
                        </div>
                        <div>
                            <Label htmlFor="audit-action-type-filter">Type d'action</Label>
                            <Select value={auditLogFilterDialog.filterActionType} onValueChange={(value) => setAuditLogFilterDialog(prev => ({ ...prev, filterActionType: value }))}>
                                <SelectTrigger id="audit-action-type-filter" className="bg-input"><SelectValue placeholder="Tous les types" /></SelectTrigger>
                                <SelectContent className="bg-popover">
                                    <SelectItem value="all">Tous les types</SelectItem>
                                    <SelectItem value="Connexion Réussie">Connexion Réussie</SelectItem>
                                    <SelectItem value="Consultation Compte">Consultation Compte</SelectItem>
                                    <SelectItem value="Modification Paramètre Sécurité">Modification Paramètre Sécurité</SelectItem>
                                    <SelectItem value="Tentative Accès Non Autorisé">Tentative Accès Non Autorisé</SelectItem>
                                    <SelectItem value="Ouverture Compte">Ouverture Compte</SelectItem>
                                    <SelectItem value="Déconnexion">Déconnexion</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setAuditLogFilterDialog(prev => ({ ...prev, open: false }))}>Annuler</Button>
                        <Button onClick={handleApplyAuditLogFilters}>Appliquer les Filtres (Simulation)</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        {/* Rapport Transactions Suspectes */}
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl flex items-center"><SearchX className="mr-2 h-6 w-6 text-primary" />Rapport Transactions Suspectes</CardTitle>
            <CardDescription>Analyse (simulée par IA) pour identifier les transactions potentiellement frauduleuses.</CardDescription>
          </CardHeader>
          <CardContent>
             <Dialog open={dialogOpen.suspiciousTx} onOpenChange={(open) => setDialogOpen(prev => ({ ...prev, suspiciousTx: open }))}>
              <DialogTrigger asChild>
                <Button className="w-full">Analyser et Générer</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
                <DialogHeader>
                  <DialogTitle className="flex items-center"><SearchX className="mr-2 h-5 w-5 text-primary"/>Analyse de Transactions Suspectes (Simulation IA)</DialogTitle>
                  <DialogDescription>Configurez les paramètres pour l'analyse IA (simulation).</DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-1.5">
                      <Label htmlFor="tx-date-range-suspicious">Période d'analyse</Label>
                      <Button id="tx-date-range-suspicious" variant="outline" disabled className="w-full justify-start text-left font-normal bg-input">
                          <CalendarDays className="mr-2 h-4 w-4" /> <span>Derniers 30 jours (Exemple)</span>
                      </Button>
                  </div>
                  <div>
                    <Label htmlFor="suspicious-tx-sensitivity">Niveau de sensibilité de l'IA</Label>
                    <Select value={suspiciousTxSensitivity} onValueChange={setSuspiciousTxSensitivity}>
                      <SelectTrigger id="suspicious-tx-sensitivity" className="bg-input">
                        <SelectValue placeholder="Choisir un niveau..." />
                      </SelectTrigger>
                      <SelectContent className="bg-popover">
                        <SelectItem value="low">Bas (Moins de faux positifs)</SelectItem>
                        <SelectItem value="medium">Moyen (Équilibré)</SelectItem>
                        <SelectItem value="high">Élevé (Plus de détections potentielles)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                      <Checkbox id="include-international-tx" defaultChecked disabled/>
                      <Label htmlFor="include-international-tx" className="font-normal">Inclure les transactions internationales</Label>
                  </div>
                   <p className="text-xs text-muted-foreground">
                      L'IA simulera une analyse basée sur ces paramètres. Les résultats seront fictifs.
                   </p>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(prev => ({...prev, suspiciousTx: false}))}>Annuler</Button>
                  <Button onClick={() => handleGenerateReport('suspiciousTx')}>Lancer l'Analyse (Simulation)</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>

       <Card className="mt-6 bg-muted/30">
        <CardHeader>
            <CardTitle className="text-lg flex items-center"><FileText className="mr-2 h-5 w-5 text-primary" />Fonctionnalités de Rapports et Audits Prévues</CardTitle>
        </CardHeader>
        <CardContent>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Génération de rapports périodiques (activité, conformité) (Rapport d'activité PDF avec données simulées implémenté)</li>
                <li>Journal d'audit détaillé des actions utilisateurs et système (Aperçu simulé implémenté, avec filtre simulé et export CSV simulé)</li>
                <li>Outils d'analyse pour la détection de fraude (potentiellement assisté par IA) (Interface de simulation implémentée)</li>
                <li>Export des rapports en PDF, CSV, et autres formats</li>
                <li>Tableaux de bord personnalisables pour la visualisation des données d'audit</li>
                <li>Alertes de conformité basées sur des règles prédéfinies</li>
            </ul>
        </CardContent>
      </Card>
    </main>
  );
}
