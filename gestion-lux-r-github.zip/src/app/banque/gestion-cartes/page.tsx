
"use client";

import Link from 'next/link';
import React, { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowLeft, CreditCard, PlusCircle, Edit3, Trash2, ShieldAlert, Settings2, ShieldOff, RefreshCcw, History, Banknote, CalendarDays, Search, Filter, ChevronsLeft, ChevronsRight, Download, ArrowUpCircle, ArrowDownCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNotifications } from '@/contexts/NotificationContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format, subDays, addMonths } from 'date-fns';
import { fr } from 'date-fns/locale';


interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
}

interface BankCard {
  id: string;
  accountId: string;
  accountHolderName: string;
  cardNumber: string;
  cardType: "Visa" | "Mastercard" | "Amex";
  expiryDate: string; // MM/YY
  status: "Active" | "Blocked" | "Expired" | "Reported";
  dailySpendingLimit?: number;
  weeklySpendingLimit?: number;
}

interface Transaction {
  id: string;
  date: Date;
  description: string;
  amount: number;
  type: "debit" | "credit";
}

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';
const LOCAL_STORAGE_BANK_CARDS_KEY = 'luxr_bank_cards';

export default function GestionCartesPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isClient, setIsClient] = useState(false);
  
  const [isAssociateCardDialogOpen, setIsAssociateCardDialogOpen] = useState(false);
  const [isEditCardDialogOpen, setIsEditCardDialogOpen] = useState(false);
  const [isManageLimitsDialogOpen, setIsManageLimitsDialogOpen] = useState(false);
  const [isReportCardDialogOpen, setIsReportCardDialogOpen] = useState(false);
  const [isTransactionHistoryDialogOpen, setIsTransactionHistoryDialogOpen] = useState(false);


  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [bankCards, setBankCards] = useState<BankCard[]>([]);
  const [editingCard, setEditingCard] = useState<BankCard | null>(null);
  const [cardForLimits, setCardForLimits] = useState<BankCard | null>(null);
  const [cardToReport, setCardToReport] = useState<BankCard | null>(null);
  const [cardForHistory, setCardForHistory] = useState<BankCard | null>(null);
  const [simulatedTransactions, setSimulatedTransactions] = useState<Transaction[]>([]);


  const [selectedAccountId, setSelectedAccountId] = useState<string | undefined>(undefined);
  const [cardType, setCardType] = useState<BankCard["cardType"] | undefined>(undefined);
  const [customCardNumber, setCustomCardNumber] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');

  // For Edit Dialog
  const [editExpiryMonth, setEditExpiryMonth] = useState('');
  const [editExpiryYear, setEditExpiryYear] = useState('');

  // For Limits Dialog (simulated values)
  const [tempDailyLimit, setTempDailyLimit] = useState<string | undefined>('');
  const [tempWeeklyLimit, setTempWeeklyLimit] = useState<string | undefined>('');


  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      try {
        const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
        if (storedAccounts) {
          const parsedAccounts: BankAccount[] = JSON.parse(storedAccounts);
          if (Array.isArray(parsedAccounts) && parsedAccounts.every(acc => acc && acc.id && acc.accountNumber)) {
            setBankAccounts(parsedAccounts);
          }
        }
      } catch (error) {
        console.error("Error loading bank accounts from localStorage:", error);
        toast({ title: "Erreur", description: "Impossible de charger les comptes bancaires.", variant: "destructive" });
      }

      try {
        const storedCards = localStorage.getItem(LOCAL_STORAGE_BANK_CARDS_KEY);
        if (storedCards) {
          const parsedCards: BankCard[] = JSON.parse(storedCards);
           if (Array.isArray(parsedCards) && parsedCards.every(card => card && card.id && card.cardNumber)) {
            setBankCards(parsedCards);
          }
        }
      } catch (error) {
        console.error("Error loading bank cards from localStorage:", error);
        toast({ title: "Erreur", description: "Impossible de charger les cartes existantes.", variant: "destructive" });
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const generateFakeCardNumber = (type: BankCard["cardType"]): string => {
    let prefix = "";
    switch (type) {
      case "Visa": prefix = "4"; break;
      case "Mastercard": prefix = "5"; break;
      case "Amex": prefix = "3"; break;
      default: prefix = "9"; 
    }
    for (let i = 0; i < 15; i++) {
      prefix += Math.floor(Math.random() * 10);
    }
    return prefix.match(/.{1,4}/g)?.join(' ') || prefix;
  };
  
  const maskCardNumber = (cardNumber: string): string => {
    if (!cardNumber) return "XXXX XXXX XXXX XXXX";
    const cleanedNumber = cardNumber.replace(/\s/g, '');
    const visibleDigits = 4;
    const maskedSection = cleanedNumber.slice(0, -visibleDigits).replace(/\d/g, "X");
    const visibleSection = cleanedNumber.slice(-visibleDigits);
    const fullMasked = (maskedSection + visibleSection).padEnd(16, 'X');
    return fullMasked.match(/.{1,4}/g)?.join(' ') || fullMasked;
  };

  const handleAssociateCardSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedAccountId || !cardType || !expiryMonth || !expiryYear) {
      toast({ title: "Champs requis", description: "Veuillez sélectionner un compte, un type de carte et une date d'expiration.", variant: "destructive" });
      return;
    }

    const account = bankAccounts.find(acc => acc.id === selectedAccountId);
    if (!account) {
      toast({ title: "Erreur", description: "Compte bancaire sélectionné non trouvé.", variant: "destructive" });
      return;
    }
    
    const currentYearLastTwoDigits = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;

    if (parseInt(expiryYear) < currentYearLastTwoDigits || (parseInt(expiryYear) === currentYearLastTwoDigits && parseInt(expiryMonth) < currentMonth)) {
      toast({ title: "Date d'expiration invalide", description: "La date d'expiration ne peut pas être dans le passé.", variant: "destructive" });
      return;
    }

    const newCardNumber = customCardNumber.replace(/\s/g, '').length === 16 ? customCardNumber.replace(/\s/g, '') : generateFakeCardNumber(cardType).replace(/\s/g, '');

    const newCard: BankCard = {
      id: Date.now().toString(),
      accountId: selectedAccountId,
      accountHolderName: `${account.holderFirstName} ${account.holderLastName}`,
      cardNumber: newCardNumber,
      cardType: cardType,
      expiryDate: `${expiryMonth}/${expiryYear}`,
      status: "Active",
      dailySpendingLimit: 500, 
      weeklySpendingLimit: 2000,
    };

    try {
      const updatedCards = [...bankCards, newCard];
      localStorage.setItem(LOCAL_STORAGE_BANK_CARDS_KEY, JSON.stringify(updatedCards));
      setBankCards(updatedCards);
      addNotification("Nouvelle Carte Associée", `Carte ${newCard.cardType} (…${newCard.cardNumber.slice(-4)}) associée au compte ${account.accountNumber}.`);
      toast({ title: "Carte Associée (Simulation Locale)", description: `Une nouvelle carte ${newCard.cardType} a été associée au compte.`, className: "bg-green-100 text-green-800 border-green-300" });
      setIsAssociateCardDialogOpen(false);
      setSelectedAccountId(undefined);
      setCardType(undefined);
      setCustomCardNumber('');
      setExpiryMonth('');
      setExpiryYear('');
    } catch (error) {
      console.error("Error saving card to localStorage:", error);
      toast({ title: "Erreur de Sauvegarde", description: "Impossible d'associer la carte localement.", variant: "destructive" });
    }
  };

  const openEditDialog = (card: BankCard) => {
    setEditingCard(card);
    const [month, year] = card.expiryDate.split('/');
    setEditExpiryMonth(month);
    setEditExpiryYear(year);
    setIsEditCardDialogOpen(true);
  };

  const handleEditCardSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editingCard || !editExpiryMonth || !editExpiryYear) {
      toast({ title: "Champs requis", description: "Une date d'expiration est requise.", variant: "destructive" });
      return;
    }

    const currentYearLastTwoDigits = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;

    if (parseInt(editExpiryYear) < currentYearLastTwoDigits || (parseInt(editExpiryYear) === currentYearLastTwoDigits && parseInt(editExpiryMonth) < currentMonth)) {
      toast({ title: "Date d'expiration invalide", description: "La date d'expiration ne peut pas être dans le passé.", variant: "destructive" });
      return;
    }

    const updatedCards = bankCards.map(card =>
      card.id === editingCard.id ? { ...card, expiryDate: `${editExpiryMonth}/${editExpiryYear}` } : card
    );

    try {
      localStorage.setItem(LOCAL_STORAGE_BANK_CARDS_KEY, JSON.stringify(updatedCards));
      setBankCards(updatedCards);
      toast({ title: "Carte Modifiée (Local)", description: `La date d'expiration de la carte (…${editingCard.cardNumber.slice(-4)}) a été mise à jour.` });
      addNotification("Carte Modifiée", `Expiration de la carte ...${editingCard.cardNumber.slice(-4)} mise à jour.`);
      setIsEditCardDialogOpen(false);
      setEditingCard(null);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de modifier la carte localement.", variant: "destructive" });
    }
  };
  
  const handleDeleteCard = (cardId: string) => {
    const cardToDelete = bankCards.find(c => c.id === cardId);
    if (!cardToDelete) return;

    const updatedCards = bankCards.filter(c => c.id !== cardId);
    try {
      localStorage.setItem(LOCAL_STORAGE_BANK_CARDS_KEY, JSON.stringify(updatedCards));
      setBankCards(updatedCards);
      addNotification("Carte Supprimée", `La carte ${cardToDelete.cardType} (…${cardToDelete.cardNumber.slice(-4)}) a été supprimée.`);
      toast({ title: "Carte Supprimée (Local)", description: "La carte a été supprimée de la liste locale.", variant: "destructive" });
    } catch (error) {
      console.error("Error deleting card from localStorage:", error);
      toast({ title: "Erreur", description: "Impossible de supprimer la carte localement.", variant: "destructive" });
    }
  };

  const handleToggleBlockCard = (cardId: string) => {
    const cardToToggle = bankCards.find(c => c.id === cardId);
    if (!cardToToggle || cardToToggle.status === "Reported") {
        toast({ title: "Action non autorisée", description: "Impossible de modifier le statut d'une carte signalée.", variant: "destructive" });
        return;
    }
    const newStatus = cardToToggle.status === "Active" ? "Blocked" : "Active";
    const updatedCards = bankCards.map(card => 
        card.id === cardId ? { ...card, status: newStatus } : card
    );
    setBankCards(updatedCards);
    localStorage.setItem(LOCAL_STORAGE_BANK_CARDS_KEY, JSON.stringify(updatedCards));
    toast({
      title: `Carte ${newStatus === "Blocked" ? "Bloquée" : "Activée"} (Simulation Locale)`,
      description: `Le statut de la carte (…${cardToToggle.cardNumber.slice(-4)}) a été modifié.`,
    });
    addNotification(
      `Statut Carte Modifié`,
      `Carte ...${cardToToggle.cardNumber.slice(-4)} ${newStatus === "Blocked" ? "bloquée" : "activée"}.`
    );
  };

  const openManageLimitsDialog = (card: BankCard) => {
    setCardForLimits(card);
    setTempDailyLimit(card.dailySpendingLimit?.toString() || '500');
    setTempWeeklyLimit(card.weeklySpendingLimit?.toString() || '2000');
    setIsManageLimitsDialogOpen(true);
  };

  const handleManageLimitsSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    toast({ title: "Gestion des Plafonds (Simulation)", description: `Les plafonds pour la carte (…${cardForLimits?.cardNumber.slice(-4)}) seraient mis à jour ici.` });
    setIsManageLimitsDialogOpen(false);
    setCardForLimits(null);
  };

  const openReportCardDialog = (card: BankCard) => {
    if (card.status === "Reported") {
        toast({ title: "Carte déjà signalée", description: "Cette carte a déjà été signalée.", variant: "default" });
        return;
    }
    setCardToReport(card);
    setIsReportCardDialogOpen(true);
  };

  const handleReportCardSubmit = () => {
    if (!cardToReport) return;
    const updatedCards = bankCards.map(card =>
      card.id === cardToReport.id ? { ...card, status: "Reported" as BankCard["status"] } : card
    );
    try {
      localStorage.setItem(LOCAL_STORAGE_BANK_CARDS_KEY, JSON.stringify(updatedCards));
      setBankCards(updatedCards);
      toast({ title: "Carte Signalée (Local)", description: `La carte (…${cardToReport.cardNumber.slice(-4)}) a été signalée comme perdue/volée.` });
      addNotification("Carte Signalée", `Carte ...${cardToReport.cardNumber.slice(-4)} signalée.`);
      setIsReportCardDialogOpen(false);
      setCardToReport(null);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de signaler la carte localement.", variant: "destructive" });
    }
  };

  const handleRequestRenewal = (card: BankCard) => {
    toast({ title: "Demande de Renouvellement (Simulation)", description: `Une demande de renouvellement pour la carte (…${card.cardNumber.slice(-4)}) serait envoyée.` });
    addNotification("Demande Renouvellement Carte", `Demande pour carte ...${card.cardNumber.slice(-4)}.`);
  };
  
  const openTransactionHistoryDialog = (card: BankCard) => {
    console.log("[Transaction History] Opening for card:", card); 
    setCardForHistory(card);
    const today = new Date();
    const dummyTransactions: Transaction[] = [
      { id: 't1', date: subDays(today, 1), description: "Achat Supermarché LUX", amount: -45.50, type: "debit" },
      { id: 't2', date: subDays(today, 2), description: "Restaurant Le Gourmet", amount: -78.20, type: "debit" },
      { id: 't3', date: subDays(today, 3), description: "Remboursement Amazon", amount: 25.00, type: "credit" },
      { id: 't4', date: subDays(today, 5), description: "Paiement Facture Mobile", amount: -30.00, type: "debit" },
      { id: 't5', date: subDays(today, 7), description: "Virement Reçu - M. Taleb", amount: 250.00, type: "credit" },
      { id: 't6', date: subDays(today, 10), description: "Abonnement Streaming", amount: -12.99, type: "debit" },
    ];
    setSimulatedTransactions(dummyTransactions);
    setIsTransactionHistoryDialogOpen(true);
  };

  const currentFullYear = new Date().getFullYear();
  const yearsForExpiry = Array.from({ length: 10 }, (_, i) => (currentFullYear + i).toString().slice(-2));

  const getStatusColor = (status: BankCard["status"]) => {
    switch (status) {
      case "Active": return "bg-green-100 text-green-700";
      case "Blocked": return "bg-yellow-100 text-yellow-700";
      case "Reported": return "bg-orange-100 text-orange-700";
      case "Expired": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <CreditCard className="mr-3 h-8 w-8" />
          Gestion des Cartes Bancaires
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <div className="mb-6">
        <Dialog open={isAssociateCardDialogOpen} onOpenChange={(open) => {
          setIsAssociateCardDialogOpen(open);
          if (!open) {
            setSelectedAccountId(undefined); setCardType(undefined); setCustomCardNumber(''); setExpiryMonth(''); setExpiryYear('');
          }
        }}>
          <DialogTrigger asChild>
            <Button size="lg">
              <PlusCircle className="mr-2 h-5 w-5" />
              Associer une Nouvelle Carte (Simulation Locale)
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center">
                <PlusCircle className="mr-2 h-6 w-6 text-primary" /> Associer une Nouvelle Carte
              </DialogTitle>
              <DialogDescription>
                Remplissez les informations pour associer une nouvelle carte à un compte. Les données sont sauvegardées localement.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAssociateCardSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
              <div>
                <Label htmlFor="account-select">Compte Bancaire</Label>
                <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                  <SelectTrigger id="account-select" className="w-full bg-input text-foreground">
                    <SelectValue placeholder="Sélectionner un compte" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover text-popover-foreground">
                    {bankAccounts.length > 0 ? (
                      bankAccounts.map(acc => (
                        <SelectItem key={acc.id} value={acc.id}>
                          {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-accounts" disabled>Aucun compte disponible</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="card-type-select">Type de Carte</Label>
                <Select value={cardType} onValueChange={(value) => setCardType(value as BankCard["cardType"])}>
                  <SelectTrigger id="card-type-select" className="w-full bg-input text-foreground">
                    <SelectValue placeholder="Sélectionner un type de carte" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover text-popover-foreground">
                    <SelectItem value="Visa">Visa</SelectItem>
                    <SelectItem value="Mastercard">Mastercard</SelectItem>
                    <SelectItem value="Amex">American Express</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="card-number-input">Numéro de Carte (Optionnel - 16 chiffres)</Label>
                <Input 
                  id="card-number-input" 
                  placeholder="XXXX XXXX XXXX XXXX (sera généré si vide)" 
                  value={customCardNumber}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    const formattedVal = val.match(/.{1,4}/g)?.join(' ') || '';
                    if (formattedVal.replace(/\s/g, '').length <= 16) {
                       setCustomCardNumber(formattedVal.slice(0, 19));
                    }
                  }}
                  className="bg-input text-foreground"
                  maxLength={19}
                />
                <p className="text-xs text-muted-foreground mt-1">Si laissé vide ou invalide (moins de 16 chiffres), un numéro factice sera généré.</p>
              </div>
              <div>
                <Label>Date d'Expiration (MM/YY)</Label>
                <div className="flex gap-2">
                  <Select value={expiryMonth} onValueChange={setExpiryMonth}>
                    <SelectTrigger className="w-1/2 bg-input text-foreground">
                      <SelectValue placeholder="Mois (MM)" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0')).map(month => (
                        <SelectItem key={month} value={month}>{month}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                   <Select value={expiryYear} onValueChange={setExpiryYear}>
                    <SelectTrigger className="w-1/2 bg-input text-foreground">
                      <SelectValue placeholder="Année (YY)" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {yearsForExpiry.map(year => (
                        <SelectItem key={year} value={year}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div className="flex items-center space-x-2 mt-2">
                  <ShieldAlert className="h-4 w-4 text-destructive" />
                  <p className="text-xs text-destructive">Pour des raisons de sécurité, ne saisissez jamais de vraies informations de CVV. Ce champ est omis.</p>
                </div>
              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setIsAssociateCardDialogOpen(false)}>Annuler</Button>
                <Button type="submit">Associer la Carte (Local)</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isClient && bankCards.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bankCards.map(card => (
            <Card key={card.id} className={`shadow-lg bg-card ${card.status === 'Blocked' || card.status === 'Reported' ? 'opacity-70 border-destructive' : ''}`}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg flex items-center text-primary">
                    <CreditCard className="mr-2 h-5 w-5" /> {card.cardType}
                  </CardTitle>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${getStatusColor(card.status)}`}>
                    {card.status}
                  </span>
                </div>
                <CardDescription>Titulaire: {card.accountHolderName}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-lg font-mono tracking-wider">{maskCardNumber(card.cardNumber)}</p>
                <p className="text-sm text-muted-foreground">Expire Fin: {card.expiryDate}</p>
                <div className="text-xs text-muted-foreground">
                    Plafond Quotidien: {card.dailySpendingLimit?.toLocaleString() || 'N/A'} €<br/>
                    Plafond Hebdo: {card.weeklySpendingLimit?.toLocaleString() || 'N/A'} €
                </div>
                <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-border">
                  <Button variant="outline" size="sm" className="flex-grow" onClick={() => openEditDialog(card)}>
                    <Edit3 className="mr-1.5 h-3.5 w-3.5" /> Modifier Exp.
                  </Button>
                  <Button 
                    variant={card.status === "Active" ? "secondary" : "default"} 
                    size="sm" 
                    className="flex-grow" 
                    onClick={() => handleToggleBlockCard(card.id)}
                    disabled={card.status === "Reported"}
                  >
                    <ShieldAlert className="mr-1.5 h-3.5 w-3.5" /> {card.status === "Active" ? "Bloquer" : "Activer"}
                  </Button>
                   <Button variant="outline" size="sm" className="flex-grow" onClick={() => openManageLimitsDialog(card)}>
                    <Settings2 className="mr-1.5 h-3.5 w-3.5" /> Plafonds
                  </Button>
                   <Button 
                    variant="destructive" 
                    size="sm" 
                    className="flex-grow" 
                    onClick={() => openReportCardDialog(card)}
                    disabled={card.status === "Reported"}
                  >
                    <ShieldOff className="mr-1.5 h-3.5 w-3.5" /> Opposition
                  </Button>
                   <Button variant="outline" size="sm" className="flex-grow" onClick={() => handleRequestRenewal(card)}>
                    <RefreshCcw className="mr-1.5 h-3.5 w-3.5" /> Renouveler
                  </Button>
                  <Button variant="outline" size="sm" className="flex-grow" onClick={() => openTransactionHistoryDialog(card)}>
                    <History className="mr-1.5 h-3.5 w-3.5" /> Historique
                  </Button>
                  <Button variant="destructive" size="sm" className="w-full mt-1" onClick={() => handleDeleteCard(card.id)}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Supprimer Carte
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {isClient && bankCards.length === 0 && (
         <div className="flex-grow flex items-center justify-center bg-card p-6 rounded-lg shadow-md">
          <div className="text-center">
            <CreditCard className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-xl text-muted-foreground">Aucune carte bancaire n'est actuellement associée.</p>
            <p className="text-sm text-muted-foreground mt-2">Utilisez le bouton ci-dessus pour associer une nouvelle carte à un compte.</p>
          </div>
        </div>
      )}
      
      {!isClient && (
        <div className="flex-grow flex items-center justify-center">
          <p className="text-xl text-muted-foreground">Chargement de la gestion des cartes...</p>
        </div>
      )}
      
      {/* Edit Card Dialog */}
      {editingCard && (
        <Dialog open={isEditCardDialogOpen} onOpenChange={(open) => {
            setIsEditCardDialogOpen(open); if (!open) setEditingCard(null);
        }}>
          <DialogContent className="sm:max-w-md bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="flex items-center"><Edit3 className="mr-2 h-5 w-5 text-primary" /> Modifier Carte</DialogTitle>
              <DialogDescription>Modifier la date d'expiration de la carte {maskCardNumber(editingCard.cardNumber)}.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleEditCardSubmit} className="space-y-4 py-4">
              <div>
                <Label>Nouvelle Date d'Expiration (MM/YY)</Label>
                <div className="flex gap-2">
                  <Select value={editExpiryMonth} onValueChange={setEditExpiryMonth}>
                    <SelectTrigger className="w-1/2 bg-input text-foreground"><SelectValue placeholder="Mois" /></SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0')).map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={editExpiryYear} onValueChange={setEditExpiryYear}>
                    <SelectTrigger className="w-1/2 bg-input text-foreground"><SelectValue placeholder="Année" /></SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground">
                      {yearsForExpiry.map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setIsEditCardDialogOpen(false); setEditingCard(null); }}>Annuler</Button>
                <Button type="submit">Sauvegarder Expiration</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* Manage Limits Dialog */}
      {cardForLimits && (
        <Dialog open={isManageLimitsDialogOpen} onOpenChange={(open) => {
            setIsManageLimitsDialogOpen(open); if (!open) setCardForLimits(null);
        }}>
          <DialogContent className="sm:max-w-md bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="flex items-center"><Settings2 className="mr-2 h-5 w-5 text-primary" /> Gérer Plafonds</DialogTitle>
              <DialogDescription>Visualiser/Modifier les plafonds de la carte {maskCardNumber(cardForLimits.cardNumber)} (Simulation).</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleManageLimitsSubmit} className="space-y-4 py-4">
              <div>
                <Label htmlFor="dailyLimit">Plafond de Dépense Quotidien (€)</Label>
                <Input id="dailyLimit" type="number" value={tempDailyLimit} onChange={(e) => setTempDailyLimit(e.target.value)} className="bg-input text-foreground" disabled />
              </div>
              <div>
                <Label htmlFor="weeklyLimit">Plafond de Dépense Hebdomadaire (€)</Label>
                <Input id="weeklyLimit" type="number" value={tempWeeklyLimit} onChange={(e) => setTempWeeklyLimit(e.target.value)} className="bg-input text-foreground" disabled />
              </div>
              <p className="text-xs text-muted-foreground">La modification réelle des plafonds sera implémentée ultérieurement.</p>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => {setIsManageLimitsDialogOpen(false); setCardForLimits(null);}}>Annuler</Button>
                <Button type="submit">Sauvegarder Plafonds (Sim.)</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* Report Card Dialog */}
      {cardToReport && (
         <Dialog open={isReportCardDialogOpen} onOpenChange={(open) => {
             setIsReportCardDialogOpen(open); if (!open) setCardToReport(null);
         }}>
          <DialogContent className="sm:max-w-md bg-card text-card-foreground">
            <DialogHeader>
              <DialogTitle className="flex items-center text-destructive"><ShieldOff className="mr-2 h-5 w-5" /> Signaler Carte Perdue/Volée</DialogTitle>
              <DialogDescription>Êtes-vous sûr de vouloir signaler la carte {maskCardNumber(cardToReport.cardNumber)} comme perdue ou volée ? Cette action la bloquera définitivement.</DialogDescription>
            </DialogHeader>
            <DialogFooter className="mt-4">
              <Button type="button" variant="outline" onClick={() => {setIsReportCardDialogOpen(false); setCardToReport(null);}}>Annuler</Button>
              <Button variant="destructive" onClick={handleReportCardSubmit}>Confirmer Opposition</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Transaction History Dialog */}
      {cardForHistory && (
        <Dialog key={cardForHistory.id} open={isTransactionHistoryDialogOpen} onOpenChange={(open) => {
            setIsTransactionHistoryDialogOpen(open); if (!open) setCardForHistory(null);
        }}>
          <DialogContent className="sm:max-w-2xl bg-card text-card-foreground"> {/* Increased width with sm:max-w-2xl */}
            <DialogHeader>
              <DialogTitle className="flex items-center"><History className="mr-2 h-5 w-5 text-primary" /> Historique des Transactions</DialogTitle>
              <DialogDescription>
                Historique simulé pour la carte {maskCardNumber(cardForHistory.cardNumber)}.
                <br/>
                <span className="text-xs text-muted-foreground">(Données réelles à venir avec le module de transactions)</span>
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4 max-h-[70vh] overflow-y-auto"> {/* Increased max height */}
              {/* Simulated Filters */}
              <Card className="p-4 bg-muted/50">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                  <div>
                    <Label htmlFor="tx-date-from">Du (Date)</Label>
                    <Input id="tx-date-from" type="date" disabled className="bg-input/70 cursor-not-allowed"/>
                  </div>
                  <div>
                    <Label htmlFor="tx-date-to">Au (Date)</Label>
                    <Input id="tx-date-to" type="date" disabled className="bg-input/70 cursor-not-allowed"/>
                  </div>
                  <div className="flex flex-col">
                     <Label htmlFor="tx-type">Type de Transaction</Label>
                     <Select disabled>
                        <SelectTrigger id="tx-type" className="bg-input/70 cursor-not-allowed">
                            <SelectValue placeholder="Tous les types" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover">
                            <SelectItem value="all">Tous les types</SelectItem>
                            <SelectItem value="debit">Débit</SelectItem>
                            <SelectItem value="credit">Crédit</SelectItem>
                        </SelectContent>
                     </Select>
                  </div>
                  <Button variant="outline" className="md:col-span-3" disabled>
                    <Filter className="mr-2 h-4 w-4" /> Filtrer (Bientôt)
                  </Button>
                </div>
              </Card>

              {simulatedTransactions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Montant</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {simulatedTransactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell>{format(tx.date, 'dd/MM/yyyy HH:mm', { locale: fr })}</TableCell>
                        <TableCell>{tx.description}</TableCell>
                        <TableCell>
                          {tx.type === 'debit' ? (
                            <span className="flex items-center text-destructive">
                              <ArrowDownCircle className="mr-1.5 h-4 w-4" /> Débit
                            </span>
                          ) : (
                            <span className="flex items-center text-green-600">
                              <ArrowUpCircle className="mr-1.5 h-4 w-4" /> Crédit
                            </span>
                          )}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${tx.type === 'debit' ? 'text-destructive' : 'text-green-600'}`}>
                          {tx.type === 'debit' ? '-' : '+'}
                          {Math.abs(tx.amount).toFixed(2)} €
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-sm text-muted-foreground text-center">Aucune transaction simulée à afficher.</p>
              )}
              {/* Simulated Pagination */}
              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                 <Button variant="outline" size="sm" disabled>
                    <ChevronsLeft className="mr-2 h-4 w-4" /> Précédent
                 </Button>
                 <span className="text-sm text-muted-foreground">Page 1 sur 1 (Simulé)</span>
                 <Button variant="outline" size="sm" disabled>
                    Suivant <ChevronsRight className="ml-2 h-4 w-4" />
                 </Button>
              </div>
               <Button variant="outline" className="w-full mt-4" onClick={() => toast({title: "Export (Simulation)", description: "L'export de l'historique sera bientôt disponible."})}>
                 <Download className="mr-2 h-4 w-4" /> Exporter cet historique (PDF/CSV)
               </Button>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => {setIsTransactionHistoryDialogOpen(false); setCardForHistory(null);}}>Fermer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}


      <Card className="mt-8 bg-muted/30">
        <CardHeader>
            <CardTitle className="text-lg flex items-center">Fonctionnalités de Gestion des Cartes</CardTitle>
        </CardHeader>
        <CardContent>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Association de cartes à des comptes existants (implémenté localement).</li>
                <li>Visualisation des cartes associées (implémenté localement).</li>
                <li>Modification de la date d'expiration (implémenté localement).</li>
                <li>Simulation du blocage/déblocage de cartes (implémenté localement).</li>
                <li>Gestion des oppositions (signalement de carte perdue/volée - implémenté localement, change le statut).</li>
                <li>Suppression de cartes associées (implémenté localement).</li>
                <li>Gestion des plafonds de dépenses (interface de simulation implémentée).</li>
                <li>Demande de renouvellement de carte (simulation par notification implémentée).</li>
                <li>Visualisation de l'historique des transactions par carte (interface de simulation améliorée).</li>
            </ul>
        </CardContent>
      </Card>

    </main>
  );
}
