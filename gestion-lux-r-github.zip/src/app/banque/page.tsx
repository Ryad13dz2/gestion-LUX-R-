
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowLeft, Users, PlusCircle, CreditCard, Landmark, DollarSign, Send, TrendingUp, FileText, History, ListChecks, Percent, Settings, BarChart, ShieldCheck, HelpCircle, Briefcase, FileWarning } from 'lucide-react';
import React, { useState } from 'react';

interface SubFeature {
  id: string;
  title: string;
  description: string;
  icon: JSX.Element;
  href?: string; // Optional href for direct navigation
}

interface FeatureSet {
  category: string;
  categoryIcon: JSX.Element;
  categoryDescription: string;
  subFeatures: SubFeature[];
}

export default function BanquePage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogContent, setDialogContent] = useState({ title: "", description: "" });

  const handleFeatureClick = (feature: SubFeature) => {
    if (feature.href) {
      // Direct navigation will be handled by Link component
      return;
    }
    setDialogContent({
      title: `Fonctionnalité : ${feature.title}`,
      description: `${feature.description} - Cette fonctionnalité est en cours de développement et sera disponible prochainement.`
    });
    setDialogOpen(true);
  };

  const features: FeatureSet[] = [
    {
      category: "Gestion des Comptes Clients",
      categoryIcon: <Landmark className="mr-3 h-7 w-7 text-primary" />,
      categoryDescription: "Créez, consultez et gérez les comptes et cartes de vos clients.",
      subFeatures: [
        { 
          id: "ouverture-compte",
          title: "Ouverture de Compte", 
          description: "Interface dédiée à la création et configuration de nouveaux comptes clients.",
          icon: <PlusCircle className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/ouverture-compte"
        },
        { 
          id: "consultation-comptes",
          title: "Consultation des Comptes", 
          description: "Recherchez, filtrez et visualisez les détails complets de chaque compte client.",
          icon: <Users className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/consultation-comptes"
        },
        { 
          id: "gestion-cartes",
          title: "Gestion des Cartes Bancaires", 
          description: "Associez des cartes, gérez les plafonds, les oppositions et les renouvellements.",
          icon: <CreditCard className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/gestion-cartes"
        },
      ]
    },
    {
      category: "Opérations Bancaires Courantes",
      categoryIcon: <DollarSign className="mr-3 h-7 w-7 text-primary" />,
      categoryDescription: "Effectuez et suivez les transactions quotidiennes avec précision.",
      subFeatures: [
        { 
          id: "enregistrement-depots",
          title: "Enregistrement de Dépôts", 
          description: "Interface pour enregistrer les dépôts d'espèces, chèques ou virements entrants.",
          icon: <TrendingUp className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/enregistrement-depots"
        },
        { 
          id: "traitement-retraits",
          title: "Traitement des Retraits", 
          description: "Interface pour gérer les demandes de retrait d'espèces des clients.",
          icon: <Send className="mr-3 h-6 w-6 text-primary rotate-180" />,
          href: "/banque/traitement-retraits"
        },
        { 
          id: "initiation-virements",
          title: "Initiation de Virements", 
          description: "Effectuez des virements entre comptes internes ou vers des comptes externes.",
          icon: <Send className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/initiation-virements"
        },
      ]
    },
    {
      category: "Consultation et Suivi Financier",
      categoryIcon: <FileText className="mr-3 h-7 w-7 text-primary" />,
      categoryDescription: "Suivez l'activité des comptes et générez des documents financiers.",
      subFeatures: [
        { 
          id: "historique-transactions",
          title: "Historique des Transactions", 
          description: "Consultez l'historique détaillé de toutes les opérations d'un compte.",
          icon: <History className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/historique-transactions"
        },
        { 
          id: "generation-releves",
          title: "Génération de Relevés", 
          description: "Produisez des relevés de compte périodiques ou à la demande.",
          icon: <ListChecks className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/generation-releves"
        },
        { 
          id: "suivi-prets",
          title: "Suivi des Prêts et Crédits", 
          description: "Gérez les prêts accordés, les échéanciers et les statuts de paiement.",
          icon: <Percent className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/suivi-prets"
        },
      ]
    },
     {
      category: "Outils, Analyse et Sécurité",
      categoryIcon: <Settings className="mr-3 h-7 w-7 text-primary" />,
      categoryDescription: "Accédez à des outils, des analyses financières et aux paramètres de sécurité.",
      subFeatures: [
        { 
          id: "convertisseur-devises",
          title: "Convertisseur de Devises", 
          description: "Outil pour convertir des montants entre différentes devises.",
          icon: <BarChart className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/convertisseur-devises"
        },
        { 
          id: "analyse-budgetaire",
          title: "Analyse Budgétaire", 
          description: "Visualisez les revenus et dépenses par catégorie pour un compte.",
          icon: <Briefcase className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/analyse-budgetaire"
        },
        { 
          id: "alertes-securite",
          title: "Alertes et Sécurité", 
          description: "Configurez les alertes (soldes bas, transactions) et gérez la sécurité.",
          icon: <ShieldCheck className="mr-3 h-6 w-6 text-primary" />,
          href: "/banque/alertes-securite"
        },
         { 
          id: "rapports-audits",
          title: "Rapports et Audits", 
          description: "Générez des rapports pour l'audit et la conformité réglementaire.",
          icon: <FileWarning className="mr-3 h-6 w-6 text-primary" />, 
          href: "/banque/rapports-audits"
        },
      ]
    }
  ];

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold text-primary">LUX-R Bank</h1>
        <Button variant="outline" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Accueil LUX-R
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
        {features.map((featureSet) => (
          <Card key={featureSet.category} className="shadow-xl hover:shadow-primary/20 transition-shadow duration-300 bg-card flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center">
                {React.cloneElement(featureSet.categoryIcon)}
                {featureSet.category}
              </CardTitle>
              <CardDescription className="text-base pt-1">{featureSet.categoryDescription}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 flex-grow">
              {featureSet.subFeatures.map((subFeature) => (
                <Link href={subFeature.href || "#"} key={subFeature.id} passHref legacyBehavior>
                  <a 
                    onClick={() => !subFeature.href && handleFeatureClick(subFeature)} 
                    className="block p-4 rounded-lg bg-muted/30 hover:bg-muted/60 cursor-pointer transition-colors border border-border/50 hover:border-primary/30"
                  >
                    <div className="flex items-center text-lg font-semibold text-foreground mb-1">
                      {React.cloneElement(subFeature.icon, {className: "mr-3 h-6 w-6"})}
                      {subFeature.title}
                    </div>
                    <p className="text-sm text-muted-foreground ml-9">{subFeature.description}</p>
                  </a>
                </Link>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <HelpCircle className="mr-2 h-5 w-5 text-primary" />
              {dialogContent.title}
            </DialogTitle>
            <DialogDescription className="pt-2">
              {dialogContent.description}
              <br /><br />
              <span className="text-xs text-muted-foreground">Note : Cette page dédiée sera développée dans une prochaine étape.</span>
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>

      <footer className="mt-auto pt-10 text-center text-sm text-muted-foreground">
        LUX-R Bank &copy; {new Date().getFullYear()} - Solutions financières innovantes
      </footer>
    </main>
  );
}
