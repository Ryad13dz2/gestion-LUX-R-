
"use client";

import Link from 'next/link';
import React, { useState, useEffect } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, TrendingDown, Banknote, CalendarIcon, User, FileSignature, Send, Coins } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useNotifications } from '@/contexts/NotificationContext';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';

const LOCAL_STORAGE_BANK_ACCOUNTS_KEY = 'luxr_bank_accounts';

interface BankAccount {
  id: string;
  accountNumber: string;
  holderLastName: string;
  holderFirstName: string;
  dateOfBirth: string;
  email?: string;
  phone?: string;
  accountType: "courant" | "epargne";
  initialDeposit?: number;
  currency: "EUR" | "USD" | "DZD";
  balance: number;
  creationDate: string;
}

const withdrawalFormSchema = z.object({
  accountId: z.string({ required_error: "Veuillez sélectionner un compte." }),
  withdrawalAmount: z.preprocess(
    (val) => (val === "" ? undefined : parseFloat(String(val))),
    z.number({ invalid_type_error: "Montant invalide" }).positive({ message: "Le montant du retrait doit être positif." })
  ),
  withdrawalType: z.enum(["especes_guichet", "virement_sortant", "cheque_emis"], { required_error: "Le type de retrait est requis." }),
  withdrawalDate: z.date({ required_error: "La date du retrait est requise." }),
  reference: z.string().optional().or(z.literal('')),
  description: z.string().optional().or(z.literal('')),
});

type WithdrawalFormValues = z.infer<typeof withdrawalFormSchema>;

export default function TraitementRetraitsPage() {
  const { toast } = useToast();
  const { addNotification } = useNotifications();
  const [isClient, setIsClient] = useState(false);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);

  useEffect(() => {
    setIsClient(true);
    if (typeof window !== 'undefined') {
      try {
        const storedAccounts = localStorage.getItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY);
        if (storedAccounts) {
          setBankAccounts(JSON.parse(storedAccounts));
        }
      } catch (error) {
        console.error("Erreur de chargement des comptes bancaires:", error);
        toast({ title: "Erreur", description: "Impossible de charger les comptes clients.", variant: "destructive" });
      }
    }
  }, [toast]);

  const form = useForm<WithdrawalFormValues>({
    resolver: zodResolver(withdrawalFormSchema),
    defaultValues: {
      withdrawalAmount: "" as unknown as undefined,
      reference: "",
      description: "",
    },
  });

  const getCurrencySymbol = (currencyCode: string | undefined) => {
    if (!currencyCode) return '';
    switch (currencyCode) {
      case 'EUR': return '€';
      case 'USD': return '$';
      case 'DZD': return 'DA';
      default: return currencyCode;
    }
  };

  async function onSubmit(data: WithdrawalFormValues) {
    if (!isClient) return;

    const selectedAccount = bankAccounts.find(acc => acc.id === data.accountId);
    if (!selectedAccount) {
      toast({ title: "Erreur", description: "Compte sélectionné non trouvé.", variant: "destructive" });
      return;
    }

    if (selectedAccount.balance < data.withdrawalAmount) {
      toast({
        title: "Solde Insuffisant",
        description: `Le solde du compte (${selectedAccount.balance.toFixed(2)} ${getCurrencySymbol(selectedAccount.currency)}) est insuffisant pour effectuer ce retrait de ${data.withdrawalAmount.toFixed(2)} ${getCurrencySymbol(selectedAccount.currency)}.`,
        variant: "destructive",
        duration: 7000,
      });
      return;
    }

    try {
      const updatedBalance = selectedAccount.balance - data.withdrawalAmount;
      const updatedAccount = { ...selectedAccount, balance: updatedBalance };

      const updatedAccountsList = bankAccounts.map(acc =>
        acc.id === data.accountId ? updatedAccount : acc
      );

      localStorage.setItem(LOCAL_STORAGE_BANK_ACCOUNTS_KEY, JSON.stringify(updatedAccountsList));
      setBankAccounts(updatedAccountsList);

      toast({
        title: "Retrait Enregistré avec Succès (Local)",
        description: `Retrait de ${data.withdrawalAmount.toFixed(2)} ${getCurrencySymbol(selectedAccount.currency)} du compte N°${selectedAccount.accountNumber}. Nouveau solde: ${updatedBalance.toFixed(2)} ${getCurrencySymbol(selectedAccount.currency)}.`,
        className: "bg-green-100 text-green-800 border-green-300",
        duration: 7000,
      });
      addNotification(
        "Retrait Enregistré",
        `Retrait de ${data.withdrawalAmount.toFixed(2)} ${getCurrencySymbol(selectedAccount.currency)} du compte ${selectedAccount.accountNumber}.`
      );
      form.reset({
        accountId: undefined,
        withdrawalAmount: "" as unknown as undefined,
        withdrawalType: undefined,
        withdrawalDate: undefined,
        reference: "",
        description: "",
      });
    } catch (error) {
      console.error("Erreur lors de l'enregistrement du retrait:", error);
      toast({
        title: "Erreur de Sauvegarde",
        description: "Une erreur est survenue lors de l'enregistrement du retrait.",
        variant: "destructive",
      });
    }
  }

  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <TrendingDown className="mr-3 h-8 w-8" />
          Traitement des Retraits
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      {isClient && bankAccounts.length === 0 && (
        <Alert variant="destructive" className="mb-6">
          <Info className="h-4 w-4" />
          <AlertTitle>Aucun Compte Client Disponible</AlertTitle>
          <AlertDescription>
            Vous devez d'abord <Link href="/banque/ouverture-compte" className="underline">créer au moins un compte client</Link> avant de pouvoir enregistrer un retrait.
          </AlertDescription>
        </Alert>
      )}

      <Card className="w-full max-w-2xl mx-auto shadow-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Détails du Retrait</CardTitle>
          <CardDescription>Remplissez les informations pour enregistrer un nouveau retrait. Le solde du compte sera mis à jour localement.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="accountId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><User className="mr-2 h-4 w-4 text-primary" />Compte Bancaire du Client</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""} disabled={bankAccounts.length === 0}>
                      <FormControl>
                        <SelectTrigger className="bg-input border-border text-foreground">
                          <SelectValue placeholder={bankAccounts.length > 0 ? "Sélectionner un compte" : "Aucun compte disponible"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-popover text-popover-foreground border-border">
                        {bankAccounts.map(acc => (
                          <SelectItem key={acc.id} value={acc.id}>
                            {acc.holderFirstName} {acc.holderLastName} - N°: {acc.accountNumber} (Solde: {acc.balance.toFixed(2)} {getCurrencySymbol(acc.currency)})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="withdrawalAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Banknote className="mr-2 h-4 w-4 text-primary" />Montant du Retrait</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Ex: 100.00" {...field} className="bg-input border-border text-foreground" step="0.01" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="withdrawalType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center"><Coins className="mr-2 h-4 w-4 text-primary" />Type de Retrait</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger className="bg-input border-border text-foreground">
                            <SelectValue placeholder="Choisir un type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover text-popover-foreground border-border">
                          <SelectItem value="especes_guichet">Espèces (Guichet/DAB)</SelectItem>
                          <SelectItem value="virement_sortant">Virement Sortant</SelectItem>
                          <SelectItem value="cheque_emis">Chèque Émis</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="withdrawalDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel className="flex items-center"><CalendarIcon className="mr-2 h-4 w-4 text-primary" />Date du Retrait</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal bg-input border-border text-foreground hover:bg-accent",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: fr })
                            ) : (
                              <span>Choisir une date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date > new Date() || date < new Date("2000-01-01")}
                          initialFocus
                          className="bg-card text-card-foreground"
                          defaultMonth={field.value || new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><FileSignature className="mr-2 h-4 w-4 text-primary" />Référence / Bénéficiaire (Optionnel)</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: N° de chèque, Nom du bénéficiaire" {...field} className="bg-input border-border text-foreground" />
                    </FormControl>
                    <FormDescription>Utile pour le suivi (ex: nom du bénéficiaire, ID de virement).</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center"><FileSignature className="mr-2 h-4 w-4 text-primary" />Description / Note (Optionnel)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Ex: Retrait pour achat matériel" {...field} className="bg-input border-border text-foreground" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={form.formState.isSubmitting || !isClient || bankAccounts.length === 0}
              >
                {form.formState.isSubmitting ? 'Enregistrement en cours...' : 'Enregistrer le Retrait'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Les retraits et les soldes sont actuellement sauvegardés localement dans votre navigateur.
      </p>
    </main>
  );
}
