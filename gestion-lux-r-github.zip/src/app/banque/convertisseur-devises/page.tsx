
"use client";

import Link from 'next/link';
import React, { useState, FormEvent, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, BarChart, Repeat } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

type CurrencyInfo = {
  code: string;
  name: string;
  symbol: string;
};

const currencies: CurrencyInfo[] = [
  { code: "EUR", name: "Euro", symbol: "€" },
  { code: "USD", name: "US Dollar", symbol: "$" },
  { code: "DZD", name: "Algerian Dinar", symbol: "DA" },
  { code: "GBP", name: "British Pound", symbol: "£" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥" },
  { code: "CAD", name: "Canadian Dollar", symbol: "CA$" },
  { code: "AUD", name: "Australian Dollar", symbol: "A$" },
  { code: "CHF", name: "Swiss Franc", symbol: "CHF" },
  { code: "CNY", name: "Chinese Yuan", symbol: "CN¥" },
  { code: "INR", name: "Indian Rupee", symbol: "₹" },
  { code: "BRL", name: "Brazilian Real", symbol: "R$" },
  { code: "RUB", name: "Russian Ruble", symbol: "₽" },
  { code: "ZAR", name: "South African Rand", symbol: "R" },
  { code: "MXN", name: "Mexican Peso", symbol: "MX$" },
  { code: "SGD", name: "Singapore Dollar", symbol: "S$" },
  { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$" },
  { code: "NOK", name: "Norwegian Krone", symbol: "kr" },
  { code: "SEK", name: "Swedish Krona", symbol: "kr" },
  { code: "DKK", name: "Danish Krone", symbol: "kr" },
  { code: "PLN", name: "Polish Złoty", symbol: "zł" },
  { code: "TRY", name: "Turkish Lira", symbol: "₺" },
  { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$" },
  { code: "THB", name: "Thai Baht", symbol: "฿" },
  { code: "KRW", name: "South Korean Won", symbol: "₩" },
  { code: "ILS", name: "Israeli New Shekel", symbol: "₪" },
  { code: "AED", name: "UAE Dirham", symbol: "د.إ" },
  { code: "SAR", name: "Saudi Riyal", symbol: "﷼" },
  { code: "MYR", name: "Malaysian Ringgit", symbol: "RM" },
  { code: "PHP", name: "Philippine Peso", symbol: "₱" },
  { code: "IDR", name: "Indonesian Rupiah", symbol: "Rp" },
  { code: "CZK", name: "Czech Koruna", symbol: "Kč" },
  { code: "HUF", name: "Hungarian Forint", symbol: "Ft" },
  { code: "RON", name: "Romanian Leu", symbol: "lei" },
  { code: "BGN", name: "Bulgarian Lev", symbol: "лв" },
  { code: "ISK", name: "Icelandic Króna", symbol: "kr" },
  { code: "COP", name: "Colombian Peso", symbol: "COP$" },
  { code: "CLP", name: "Chilean Peso", symbol: "CLP$" },
  { code: "ARS", name: "Argentine Peso", symbol: "$AR" },
  { code: "VND", name: "Vietnamese Đồng", symbol: "₫" },
  { code: "EGP", name: "Egyptian Pound", symbol: "E£" },
  { code: "NGN", name: "Nigerian Naira", symbol: "₦" },
  { code: "KES", name: "Kenyan Shilling", symbol: "KSh" },
  { code: "GHS", name: "Ghanaian Cedi", symbol: "GH₵" },
  { code: "UAH", name: "Ukrainian Hryvnia", symbol: "₴" },
  { code: "QAR", name: "Qatari Riyal", symbol: "ر.ق" },
  { code: "OMR", name: "Omani Rial", symbol: "ر.ع." },
  { code: "KWD", name: "Kuwaiti Dinar", symbol: "د.ك" },
  { code: "BHD", name: "Bahraini Dinar", symbol: ".د.ب" },
  { code: "PKR", name: "Pakistani Rupee", symbol: "₨" },
  { code: "LKR", name: "Sri Lankan Rupee", symbol: "රු" },
  { code: "BDT", name: "Bangladeshi Taka", symbol: "৳" },
  { code: "MAD", name: "Moroccan Dirham", symbol: "MAD" },
  { code: "TND", name: "Tunisian Dinar", symbol: "DT" },
];

const CORE_CURRENCIES = ["EUR", "USD", "DZD", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY"];

// RATES_AGAINST_EUR[currencyCode] = how many units of currencyCode for 1 EUR
const RATES_AGAINST_EUR: Record<string, number> = {
  EUR: 1,
  USD: 1.08,
  DZD: 145.50,
  GBP: 0.85,
  JPY: 160.00,
  CAD: 1.47,
  AUD: 1.62,
  CHF: 0.96,
  CNY: 7.80,
};

// For any non-core currency, 1 unit of "Other" currency = OTHER_CURRENCY_TO_EUR_RATE EUR
const OTHER_CURRENCY_TO_EUR_RATE = 0.02; // So, 1 EUR = 1 / 0.02 = 50 units of "Other" currency

// Pre-calculate core-to-core rates for direct lookup
// SIMULATED_RATES_TABLE[A][B] = how many units of B for 1 unit of A
const SIMULATED_RATES_TABLE: Record<string, Record<string, number>> = {};
CORE_CURRENCIES.forEach(from => {
  SIMULATED_RATES_TABLE[from] = {};
  CORE_CURRENCIES.forEach(to => {
    if (from === to) {
      SIMULATED_RATES_TABLE[from][to] = 1;
    } else {
      // To convert 1 unit of 'from' currency to 'to' currency:
      // 1. Convert 'from' to EUR: 1 'from' = (1 / RATES_AGAINST_EUR[from]) EUR
      // 2. Convert these EUR to 'to': (1 / RATES_AGAINST_EUR[from]) EUR * RATES_AGAINST_EUR[to] 'to' units
      SIMULATED_RATES_TABLE[from][to] = RATES_AGAINST_EUR[to] / RATES_AGAINST_EUR[from];
    }
  });
});


export default function ConvertisseurDevisesPage() {
  const { toast } = useToast();
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("EUR");
  const [toCurrency, setToCurrency] = useState<string>("USD");
  const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
  const [usedRate, setUsedRate] = useState<string>("");

  const getCurrencyDisplayInfo = (currencyCode: string | undefined): CurrencyInfo => {
    if (!currencyCode) return { code: "", name: "N/A", symbol: "" };
    return currencies.find(c => c.code === currencyCode) || { code: currencyCode, name: currencyCode, symbol: currencyCode };
  };

  const handleConversion = (event?: FormEvent<HTMLFormElement>) => {
    event?.preventDefault();
    const numericAmount = parseFloat(amount);

    if (isNaN(numericAmount) || numericAmount <= 0) {
      toast({
        title: "Montant Invalide",
        description: "Veuillez entrer un montant positif à convertir.",
        variant: "destructive",
      });
      setConvertedAmount(null);
      setUsedRate("");
      return;
    }

    let finalRate = 1;
    let isHighlySimulated = false;

    const fromIsCore = CORE_CURRENCIES.includes(fromCurrency);
    const toIsCore = CORE_CURRENCIES.includes(toCurrency);

    if (fromCurrency === toCurrency) {
      finalRate = 1;
    } else if (fromIsCore && toIsCore) {
      finalRate = SIMULATED_RATES_TABLE[fromCurrency]?.[toCurrency] || 1;
    } else {
      // Generic conversion path via EUR for any non-core currency
      isHighlySimulated = true;
      let amountInEur;

      // Step 1: Convert fromCurrency to EUR
      if (fromIsCore) {
        // 1 unit of fromCurrency = (1 / RATES_AGAINST_EUR[fromCurrency]) EUR
        amountInEur = numericAmount * (1 / (RATES_AGAINST_EUR[fromCurrency] || 1));
      } else { // fromCurrency is "Other"
        amountInEur = numericAmount * OTHER_CURRENCY_TO_EUR_RATE; // 1 "Other" = 0.02 EUR
      }

      // Step 2: Convert EUR to toCurrency
      let resultInToCurrency;
      if (toIsCore) {
        // 1 EUR = RATES_AGAINST_EUR[toCurrency] units of toCurrency
        resultInToCurrency = amountInEur * (RATES_AGAINST_EUR[toCurrency] || 1);
      } else { // toCurrency is "Other"
        // 1 EUR = (1 / OTHER_CURRENCY_TO_EUR_RATE) units of "Other"
        resultInToCurrency = amountInEur * (1 / OTHER_CURRENCY_TO_EUR_RATE);
      }
      setConvertedAmount(resultInToCurrency);
      if (numericAmount !== 0) { // Avoid division by zero if amount is 0 (though validated earlier)
        finalRate = resultInToCurrency / numericAmount;
      } else {
        finalRate = 0; // Or handle as an error
      }
    }
    
    if (fromCurrency !== toCurrency && !(fromIsCore && toIsCore && isHighlySimulated)) { // ensure convertedAmount is set if not done by the highlySimulated path
       setConvertedAmount(numericAmount * finalRate);
    }


    if (isHighlySimulated) {
      setUsedRate(`Conversion illustrative : 1 ${fromCurrency} ≈ ${finalRate.toFixed(4)} ${toCurrency}`);
      toast({
        title: "Taux Hautement Simulé",
        description: `La conversion impliquant ${getCurrencyDisplayInfo(fromCurrency).name} ou ${getCurrencyDisplayInfo(toCurrency).name} est à des fins de démonstration uniquement.`,
        variant: "default",
        duration: 5000,
      });
    } else if (fromCurrency === toCurrency) {
      setConvertedAmount(numericAmount);
      setUsedRate(`1 ${fromCurrency} = 1 ${toCurrency}`);
    } else {
      setUsedRate(`1 ${fromCurrency} = ${finalRate.toFixed(4)} ${toCurrency}`);
    }
  };
  
  const handleSwapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
    // Optionally, trigger conversion immediately after swap
    // handleConversion(); // Uncomment if immediate conversion is desired
  };


  return (
    <main className="flex flex-col min-h-screen bg-background text-foreground p-4 md:p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <BarChart className="mr-3 h-8 w-8" />
          Convertisseur de Devises Étendu
        </h1>
        <Button variant="outline" asChild>
          <Link href="/banque">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la Gestion Bancaire
          </Link>
        </Button>
      </div>

      <Card className="w-full max-w-lg mx-auto shadow-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Outil de Conversion Mondial</CardTitle>
          <CardDescription>Convertissez entre plus de 50 devises. Taux simulés (illustratifs pour certaines paires).</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleConversion} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="amount-input">Montant à Convertir</Label>
              <Input
                id="amount-input"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Ex: 100"
                className="bg-input text-foreground text-lg"
                step="any"
              />
            </div>

            <div className="flex items-center justify-between space-x-2 sm:space-x-4">
              <div className="flex-1 space-y-2">
                <Label htmlFor="from-currency-select">De (Source)</Label>
                <Select value={fromCurrency} onValueChange={(value) => setFromCurrency(value as string)}>
                  <SelectTrigger id="from-currency-select" className="bg-input text-foreground">
                    <SelectValue placeholder="Choisir devise" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover text-popover-foreground max-h-60">
                    {currencies.map(curr => (
                      <SelectItem key={curr.code} value={curr.code}>
                        {curr.code} ({curr.symbol}) - {curr.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="mt-7 self-center"
                onClick={handleSwapCurrencies}
                aria-label="Inverser les devises"
              >
                <Repeat className="h-5 w-5 text-primary" />
              </Button>

              <div className="flex-1 space-y-2">
                <Label htmlFor="to-currency-select">À (Cible)</Label>
                <Select value={toCurrency} onValueChange={(value) => setToCurrency(value as string)}>
                  <SelectTrigger id="to-currency-select" className="bg-input text-foreground">
                    <SelectValue placeholder="Choisir devise" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover text-popover-foreground max-h-60">
                     {currencies.map(curr => (
                      <SelectItem key={curr.code} value={curr.code}>
                        {curr.code} ({curr.symbol}) - {curr.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button type="submit" className="w-full">
              Convertir
            </Button>
          </form>

          {convertedAmount !== null && (
            <div className="mt-8 p-6 bg-muted rounded-lg shadow-inner">
              <h3 className="text-lg font-semibold text-primary mb-2">Résultat de la Conversion :</h3>
              <p className="text-3xl font-bold text-foreground">
                {getCurrencyDisplayInfo(toCurrency).symbol} {convertedAmount.toFixed(2)}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Équivaut à {parseFloat(amount).toFixed(2)} {getCurrencyDisplayInfo(fromCurrency).symbol} ({getCurrencyDisplayInfo(fromCurrency).name})
              </p>
              {usedRate && (
                <p className="text-xs text-muted-foreground mt-3 pt-3 border-t border-border">
                  Taux de change utilisé (simulation) : {usedRate}
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      <p className="text-center text-xs text-muted-foreground mt-8">
        Note : Les taux de change utilisés sont simulés. Pour les paires de devises moins courantes, la conversion est hautement illustrative et à des fins de démonstration uniquement.
      </p>
    </main>
  );
}

