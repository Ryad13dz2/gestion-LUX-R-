
import type {Metadata} from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { NotificationProvider } from '@/contexts/NotificationContext';
import { cn } from '@/lib/utils';

const inter = Inter({
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'LUX-R',
  description: 'Gestion de Bibliothèque et Comptes Bancaires',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body className={cn(
          inter.className,
          "bg-background text-foreground"
        )}
      >
        <NotificationProvider>
          {children}
        </NotificationProvider>
        <Toaster />
      </body>
    </html>
  );
}
