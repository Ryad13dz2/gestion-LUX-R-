'use server';

// This file can be used for Next.js Server Actions.
// Add your server-side functions here.
