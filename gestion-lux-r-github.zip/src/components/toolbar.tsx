"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Pencil, Eraser, Palette, Wand2, Trash2, Save, ZoomIn, ZoomOut, Minus, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

export type Tool = 'pencil' | 'eraser';
export type Color = string; // Hex color string

interface ToolbarProps {
  currentTool: Tool;
  currentColor: Color;
  lineWidth: number;
  onToolChange: (tool: Tool) => void;
  onColorChange: (color: Color) => void;
  onLineWidthChange: (width: number) => void;
  onAiCleanup: () => void;
  isCleaningAi: boolean;
  onClearCanvas: () => void;
  onSaveDrawing: () => void;
}

const availableColors: Color[] = ['#000000', '#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#4B0082', '#8F00FF']; // Black, Red, Blue, Green, Yellow, Indigo, Violet

const Toolbar: React.FC<ToolbarProps> = ({
  currentTool,
  currentColor,
  lineWidth,
  onToolChange,
  onColorChange,
  onLineWidthChange,
  onAiCleanup,
  isCleaningAi,
  onClearCanvas,
  onSaveDrawing,
}) => {
  return (
    <TooltipProvider>
      <div className="flex items-center gap-2 p-3 bg-card shadow-md rounded-lg border border-border">
        {/* Tool Selection */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={currentTool === 'pencil' ? 'secondary' : 'outline'}
              size="icon"
              onClick={() => onToolChange('pencil')}
              aria-label="Pencil Tool"
              className={cn(currentTool === 'pencil' && "ring-2 ring-primary")}
            >
              <Pencil className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Pencil</TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={currentTool === 'eraser' ? 'secondary' : 'outline'}
              size="icon"
              onClick={() => onToolChange('eraser')}
              aria-label="Eraser Tool"
              className={cn(currentTool === 'eraser' && "ring-2 ring-primary")}
            >
              <Eraser className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Eraser</TooltipContent>
        </Tooltip>

        {/* Color Picker Popover */}
        <Popover>
          <PopoverTrigger asChild>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" aria-label="Color Picker">
                  <Palette className="h-5 w-5" />
                  <div className="w-3 h-3 rounded-full ml-1 border border-foreground" style={{ backgroundColor: currentColor }} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Select Color (Currently: {currentColor})</TooltipContent>
            </Tooltip>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2">
            <div className="grid grid-cols-4 gap-1">
              {availableColors.map((color) => (
                <Button
                  key={color}
                  variant="outline"
                  size="icon"
                  className={cn("w-8 h-8", currentColor === color && "ring-2 ring-primary")}
                  style={{ backgroundColor: color }}
                  onClick={() => onColorChange(color)}
                  aria-label={`Select color ${color}`}
                />
              ))}
              {/* Custom Color Input */}
               <Input
                  type="color"
                  value={currentColor}
                  onChange={(e) => onColorChange(e.target.value)}
                  className="w-8 h-8 p-0 border-none cursor-pointer"
                  title="Custom color picker"
                />
            </div>
          </PopoverContent>
        </Popover>

        {/* Line Width Slider */}
         <div className="flex items-center gap-2 ml-2">
          <Label htmlFor="lineWidth" className="text-sm font-medium">Width:</Label>
           <Tooltip>
             <TooltipTrigger asChild>
              <Button variant="outline" size="icon" onClick={() => onLineWidthChange(Math.max(1, lineWidth -1))} disabled={lineWidth <=1}>
                <Minus className="h-4 w-4"/>
              </Button>
             </TooltipTrigger>
             <TooltipContent>Decrease Line Width</TooltipContent>
           </Tooltip>
          <Input
            id="lineWidth"
            type="range"
            min="1"
            max="50"
            value={lineWidth}
            onChange={(e) => onLineWidthChange(parseInt(e.target.value))}
            className="w-24 h-auto cursor-pointer"
            aria-label={`Line width ${lineWidth}px`}
          />
          <span className="text-sm w-6 text-right">{lineWidth}</span>
           <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="icon" onClick={() => onLineWidthChange(Math.min(50, lineWidth + 1))} disabled={lineWidth >=50}>
                <Plus className="h-4 w-4"/>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Increase Line Width</TooltipContent>
           </Tooltip>
        </div>


        {/* AI Cleanup */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="icon" onClick={onAiCleanup} disabled={isCleaningAi} aria-label="AI Cleanup">
              {isCleaningAi ? <Loader2 className="h-5 w-5 animate-spin" /> : <Wand2 className="h-5 w-5" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>AI Cleanup Drawing (Experimental)</TooltipContent>
        </Tooltip>
        
        {/* Clear Canvas */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="destructive" size="icon" onClick={onClearCanvas} aria-label="Clear Canvas">
              <Trash2 className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Clear Canvas</TooltipContent>
        </Tooltip>

        {/* Save Drawing */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline" size="icon" onClick={onSaveDrawing} aria-label="Save Drawing">
              <Save className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Save Drawing (Local Download)</TooltipContent>
        </Tooltip>

      </div>
    </TooltipProvider>
  );
};

export default Toolbar;
