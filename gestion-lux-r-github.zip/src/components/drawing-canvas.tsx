"use client";

import React, { useRef, useEffect, useImperativeHandle, forwardRef, useState } from 'react';
import type { Tool, Color } from './toolbar';

interface DrawingCanvasProps {
  width: number;
  height: number;
  tool: Tool;
  color: Color;
  lineWidth: number;
  className?: string;
}

export interface DrawingCanvasRef {
  getCanvas: () => HTMLCanvasElement | null;
  clearCanvas: () => void;
  loadImage: (dataUrl: string) => void;
}

const DrawingCanvas = forwardRef<DrawingCanvasRef, DrawingCanvasProps>(
  ({ width, height, tool, color, lineWidth, className }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);

    useEffect(() => {
      if (canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          // Set initial background to white
          ctx.fillStyle = '#FFFFFF'; // Canvas background color
          ctx.fillRect(0, 0, width, height);
          setContext(ctx);
        }
      }
    }, [width, height]);

    useEffect(() => {
      if (context) {
        context.strokeStyle = color;
        context.lineWidth = lineWidth;
        context.lineCap = 'round';
        context.lineJoin = 'round';
      }
    }, [color, lineWidth, context]);

    useImperativeHandle(ref, () => ({
      getCanvas: () => canvasRef.current,
      clearCanvas: () => {
        if (context && canvasRef.current) {
          context.fillStyle = '#FFFFFF'; // Ensure background is white on clear
          context.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }
      },
      loadImage: (dataUrl: string) => {
        if (context && canvasRef.current) {
          const image = new Image();
          image.onload = () => {
            context.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
             context.fillStyle = '#FFFFFF'; 
             context.fillRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
            context.drawImage(image, 0, 0);
          };
          image.src = dataUrl;
        }
      }
    }));

    const getMousePosition = (event: React.MouseEvent<HTMLCanvasElement>): { x: number; y: number } => {
      const rect = canvasRef.current!.getBoundingClientRect();
      // Consider potential CSS scaling if any (though not typical for canvas drawing)
      const scaleX = canvasRef.current!.width / rect.width;
      const scaleY = canvasRef.current!.height / rect.height;
      return {
        x: (event.clientX - rect.left) * scaleX,
        y: (event.clientY - rect.top) * scaleY,
      };
    };
    
    const startDrawing = (event: React.MouseEvent<HTMLCanvasElement>) => {
      if (!context) return;
      const { x, y } = getMousePosition(event);
      context.beginPath();
      context.moveTo(x, y);
      setIsDrawing(true);
    };

    const draw = (event: React.MouseEvent<HTMLCanvasElement>) => {
      if (!isDrawing || !context) return;
      const { x, y } = getMousePosition(event);
      
      if (tool === 'pencil') {
        context.strokeStyle = color;
        context.lineWidth = lineWidth;
      } else if (tool === 'eraser') {
        context.strokeStyle = '#FFFFFF'; // Eraser color (canvas background)
        context.lineWidth = lineWidth * 2; // Make eraser a bit thicker
      }
      
      context.lineTo(x, y);
      context.stroke();
    };

    const stopDrawing = () => {
      if (!context) return;
      context.closePath();
      setIsDrawing(false);
    };

    return (
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseOut={stopDrawing} // Stop drawing if mouse leaves canvas
        className={className}
        style={{ touchAction: 'none' }} // Improves touch interaction on some devices
      />
    );
  }
);

DrawingCanvas.displayName = 'DrawingCanvas';
export default DrawingCanvas;
