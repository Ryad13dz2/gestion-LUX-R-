
/**
 * @fileOverview Schémas Zod et types TypeScript pour la recherche de livres.
 *
 * - SearchOnlineBooksInputSchema - Le schéma Zod pour l'entrée de la recherche de livres.
 * - SearchedBookSchema - Le schéma Zod pour un livre trouvé.
 * - SearchOnlineBooksOutputSchema - Le schéma Zod pour la sortie de la recherche de livres.
 * - SearchOnlineBooksInput - Le type pour l'entrée de la recherche de livres.
 * - SearchedBook - Le type pour un livre trouvé.
 * - SearchOnlineBooksOutput - Le type pour la sortie de la recherche de livres.
 */

import { z } from 'genkit';

// --- Schema Definitions ---
export const SearchOnlineBooksInputSchema = z.object({
  query: z.string().min(1).describe('The search query for books (e.g., title, author, ISBN).'),
});

export const SearchedBookSchema = z.object({
  id: z.string().optional().describe('A unique identifier for the book from the online source. This can be omitted if not available.'),
  title: z.string().optional().describe('The title of the book.'),
  authors: z.array(z.string()).optional().describe('A list of authors for the book.'),
  publishedDate: z.string().optional().describe('The publication date of the book (e.g., "2023", "2023-06-15").'),
  description: z.string().optional().describe('A short description or synopsis of the book.'),
  thumbnailUrl: z.string().url().optional().describe('A URL to the book cover thumbnail image.'),
  isbn13: z.string().optional().describe('The ISBN-13 identifier of the book.'),
  isbn10: z.string().optional().describe('The ISBN-10 identifier of the book.'),
  publisher: z.string().optional().describe('The publisher of the book.'),
  pageCount: z.number().int().positive().optional().describe('The number of pages in the book.'),
  categories: z.array(z.string()).optional().describe('A list of categories or genres for the book.'),
});

export const SearchOnlineBooksOutputSchema = z.object({
  items: z.array(SearchedBookSchema).describe('A list of books found matching the query.'),
});

// --- Type Definitions ---
export type SearchOnlineBooksInput = z.infer<typeof SearchOnlineBooksInputSchema>;
export type SearchedBook = z.infer<typeof SearchedBookSchema>;
export type SearchOnlineBooksOutput = z.infer<typeof SearchOnlineBooksOutputSchema>;

