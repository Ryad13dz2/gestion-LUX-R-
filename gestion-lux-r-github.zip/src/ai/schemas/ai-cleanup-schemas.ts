/**
 * @fileOverview Zod schemas and TypeScript types for the AI drawing cleanup feature.
 *
 * - AiCleanupInputSchema - Zod schema for the AI cleanup input.
 * - AiCleanupOutputSchema - Zod schema for the AI cleanup output.
 * - AiCleanupInput - TypeScript type for the AI cleanup input.
 * - AiCleanupOutput - TypeScript type for the AI cleanup output.
 */
import { z } from 'genkit';

export const AiCleanupInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "The drawing image as a data URI. Must include a MIME type (e.g., 'image/png') and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AiCleanupInput = z.infer<typeof AiCleanupInputSchema>;

export const AiCleanupOutputSchema = z.object({
  cleanedImageDataUri: z
    .string()
    .describe(
      "The cleaned drawing image as a data URI, in the same format as the input."
    ),
});
export type AiCleanupOutput = z.infer<typeof AiCleanupOutputSchema>;
