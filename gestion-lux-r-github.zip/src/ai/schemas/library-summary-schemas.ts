
/**
 * @fileOverview Schémas Zod et types TypeScript pour le résumé de l'activité de la bibliothèque par l'IA.
 *
 * - LibrarySummaryInputSchema - Le schéma Zod pour l'entrée de la demande de résumé.
 * - LibrarySummaryOutputSchema - Le schéma Zod pour la sortie du résumé généré par l'IA.
 * - LibrarySummaryInput - Le type pour l'entrée de la demande de résumé.
 * - LibrarySummaryOutput - Le type pour la sortie du résumé généré par l'IA.
 */

import { z } from 'genkit';

// --- Schema Definitions ---
export const LibrarySummaryInputSchema = z.object({
  query: z.string().min(1).describe("La question ou la demande de l'utilisateur pour l'IA concernant l'activité de la bibliothèque."),
});

export const LibrarySummaryOutputSchema = z.object({
  summary: z.string().describe("Le résumé textuel de l'activité de la bibliothèque généré par l'IA."),
});

// --- Type Definitions ---
export type LibrarySummaryInput = z.infer<typeof LibrarySummaryInputSchema>;
export type LibrarySummaryOutput = z.infer<typeof LibrarySummaryOutputSchema>;
