
/**
 * @fileOverview Schémas Zod et types TypeScript pour les conseils de gestion de bibliothèque par l'IA.
 *
 * - LibraryTipInputSchema - Le schéma Zod pour l'entrée de la demande de conseil.
 * - LibraryTipOutputSchema - Le schéma Zod pour la sortie du conseil généré par l'IA.
 * - LibraryTipInput - Le type pour l'entrée de la demande de conseil.
 * - LibraryTipOutput - Le type pour la sortie du conseil généré par l'IA.
 */

import { z } from 'genkit';

// --- Schema Definitions ---
export const LibraryTipInputSchema = z.object({
  topic: z.string().optional().describe("Sujet optionnel pour le conseil de gestion de bibliothèque."),
});

export const LibraryTipOutputSchema = z.object({
  tip: z.string().describe("Le conseil de gestion de bibliothèque généré par l'IA."),
});

// --- Type Definitions ---
export type LibraryTipInput = z.infer<typeof LibraryTipInputSchema>;
export type LibraryTipOutput = z.infer<typeof LibraryTipOutputSchema>;
