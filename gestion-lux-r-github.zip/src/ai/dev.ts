
import { config } from 'dotenv';
config();

// LUX-R specific flows
import '@/ai/flows/search-books-flow.ts';
import '@/ai/flows/summarize-library-flow.ts';
import '@/ai/flows/get-library-tip-flow.ts';
