'use server';
/**
 * @fileOverview A Genkit flow for cleaning up user drawings using AI.
 *
 * - aiCleanUpDrawing - Main function to call the AI cleanup flow.
 * - AiCleanupInput - Input type for the flow (imported).
 * - AiCleanupOutput - Output type for the flow (imported).
 */

import { ai } from '@/ai/genkit';
import {
  AiCleanupInputSchema,
  AiCleanupOutputSchema,
  type AiCleanupInput,
  type AiCleanupOutput,
} from '@/ai/schemas/ai-cleanup-schemas';

export async function aiCleanUpDrawing(input: AiCleanupInput): Promise<AiCleanupOutput> {
  console.log('[AI CLEANUP FLOW] Called with input.');
  return aiCleanupFlow(input);
}

const cleanupPrompt = ai.definePrompt({
  name: 'aiDrawingCleanupPrompt',
  input: { schema: AiCleanupInputSchema },
  output: { schema: AiCleanupOutputSchema },
  // IMPORTANT: Only googleai/gemini-2.0-flash-exp model is able to generate images.
  model: 'googleai/gemini-2.0-flash-exp', 
  config: {
    responseModalities: ['TEXT', 'IMAGE'], // MUST provide both TEXT and IMAGE
     safetySettings: [ // Relax safety settings for creative content if needed
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
    ],
  },
  prompt: `You are an AI assistant that cleans up user-drawn images.
Your task is to take the provided drawing and enhance it by:
1. Smoothing rough lines and edges.
2. Correcting minor imperfections in shapes.
3. Making the drawing look more polished and neat, while preserving the original intent and style of the drawing.
Do not add new elements or drastically change the subject matter. Focus on refinement.

Return the cleaned image.

Original Drawing:
{{media url=imageDataUri}}`,
});

const aiCleanupFlow = ai.defineFlow(
  {
    name: 'aiCleanupFlow',
    inputSchema: AiCleanupInputSchema,
    outputSchema: AiCleanupOutputSchema,
  },
  async (input) => {
    console.log('[AI CLEANUP FLOW] Starting flow execution.');
    
    // Call the prompt which implicitly handles image generation/manipulation
    const { media, output } = await ai.generate({
        model: 'googleai/gemini-2.0-flash-exp',
        prompt: [
            {media: {url: input.imageDataUri}},
            {text: `Clean up this drawing: smooth rough lines and edges, correct minor imperfections in shapes. Make the drawing look more polished and neat, while preserving the original intent and style. Do not add new elements or drastically change the subject matter. Focus on refinement.`},
        ],
        config: {
            responseModalities: ['TEXT', 'IMAGE'],
             safetySettings: [ 
              { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE'},
              { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_MEDIUM_AND_ABOVE'},
              { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE'},
              { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE'},
            ],
        },
    });

    if (media && media.url) {
      console.log('[AI CLEANUP FLOW] Successfully generated cleaned image.');
      return { cleanedImageDataUri: media.url };
    } else if (output?.cleanedImageDataUri) {
        // Fallback if the model places it in the structured output directly (less likely with direct ai.generate for images)
         console.log('[AI CLEANUP FLOW] Image URI found in structured output.');
        return { cleanedImageDataUri: output.cleanedImageDataUri };
    }
    
    console.error('[AI CLEANUP FLOW] Failed to generate cleaned image. No media URL returned.');
    throw new Error('AI cleanup failed to return an image.');
  }
);
