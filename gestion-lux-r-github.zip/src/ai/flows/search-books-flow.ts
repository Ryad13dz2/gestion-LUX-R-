
'use server';
/**
 * @fileOverview A flow for searching books online using an AI model.
 *
 * - searchOnlineBooks - A function to search for books based on a query.
 * - SearchOnlineBooksInput - The input type for the searchOnlineBooks function. (Imported)
 * - SearchOnlineBooksOutput - The return type for the searchOnlineBooks function. (Imported)
 */

import {ai} from '@/ai/genkit';
import {
  SearchOnlineBooksInputSchema,
  SearchOnlineBooksOutputSchema,
  type SearchOnlineBooksInput,
  type SearchOnlineBooksOutput,
} from '@/ai/schemas/book-search-schemas';


// Function to be called from the client
export async function searchOnlineBooks(input: SearchOnlineBooksInput): Promise<SearchOnlineBooksOutput> {
  console.log(`[SERVER FLOW] searchOnlineBooks called with query: "${input.query}"`);
  return searchBooksFlow(input);
}

// Define the prompt for the AI model
const searchBooksPrompt = ai.definePrompt({
  name: 'searchBooksPrompt',
  input: { schema: SearchOnlineBooksInputSchema },
  output: { schema: SearchOnlineBooksOutputSchema },
  prompt: `Tu es une API de recherche de livres experte.
Ta tâche est de trouver des informations sur des livres basées sur la requête de l'utilisateur.
Tu dois retourner un objet JSON. Cet objet JSON doit avoir une seule clé nommée "items".
La valeur de "items" doit être une liste (un tableau JavaScript) d'objets. Chaque objet représente un livre.
Trouve un maximum de 3 livres. Si aucun livre n'est trouvé, retourne IMPÉRATIVEMENT une liste vide pour "items" (c'est-à-dire, "items": []).

Pour chaque livre dans la liste "items", inclus les champs suivants.
SI UNE INFORMATION N'EST PAS DISPONIBLE POUR UN CHAMP OPTIONNEL, OMETS COMPLÈTEMENT LE CHAMP DE L'OBJET JSON POUR CE LIVRE. NE METS PAS de valeur null ou de chaîne vide pour les champs optionnels si l'information n'est pas trouvée.
- title (string, optionnel mais fortement recommandé) : Le titre du livre. Essaye de toujours fournir un titre.
- authors (liste de strings, optionnel) : Les auteurs du livre. Si aucun, tu peux omettre ce champ ou fournir [].
- publishedDate (string, ex: "2023" ou "2023-06-15", optionnel) : La date de publication.
- description (string, optionnel) : Une brève description.
- thumbnailUrl (string URL VALIDE, optionnel) : L'URL de l'image de couverture. Fais de ton mieux pour trouver une URL d'image réelle et pertinente. Si tu ne trouves pas d'image, OMETS ce champ. Ne fournis pas de placeholder comme "https://placehold.co".
- isbn13 (string, optionnel mais fortement recommandé) : L'ISBN-13 du livre. Essaye de toujours fournir un ISBN si possible.
- publisher (string, optionnel) : L'éditeur du livre.
- pageCount (nombre entier positif, optionnel) : Le nombre de pages.
- categories (liste de strings, optionnel) : Les catégories ou genres du livre. Si aucun, tu peux omettre ce champ ou fournir [].

Assure-toi que chaque livre a au moins un "title" ou un "isbn13". Il est très important que la sortie soit un JSON valide.

Requête de recherche : {{{query}}}

Exemple de structure de réponse attendue (pour un livre trouvé, certains champs optionnels peuvent être omis) :
{
  "items": [
    {
      "title": "Le Petit Prince",
      "authors": ["Antoine de Saint-Exupéry"],
      "publishedDate": "1943",
      "description": "Un conte philosophique sous l'apparence d'un conte pour enfants.",
      "thumbnailUrl": "https://upload.wikimedia.org/wikipedia/fr/thumb/a/a4/Le_Petit_Prince_couverture.jpg/220px-Le_Petit_Prince_couverture.jpg",
      "isbn13": "978-2070612750",
      "publisher": "Gallimard Jeunesse",
      "pageCount": 96,
      "categories": ["Conte philosophique", "Littérature jeunesse"]
    }
  ]
}

Exemple si aucun livre n'est trouvé :
{
  "items": []
}
`,
});


// The Genkit Flow
const searchBooksFlow = ai.defineFlow(
  {
    name: 'searchBooksFlow',
    inputSchema: SearchOnlineBooksInputSchema,
    outputSchema: SearchOnlineBooksOutputSchema,
  },
  async (input) => {
    console.log(`[SEARCH BOOKS FLOW] Performing AI-powered book search for query: "${input.query}"`);

    try {
      const { output } = await searchBooksPrompt(input);
      
      // Log the raw output from the AI model for debugging purposes
      console.log("[SEARCH BOOKS FLOW] Raw AI output:", JSON.stringify(output, null, 2));

      if (!output) {
        console.warn("[SEARCH BOOKS FLOW] AI prompt returned null or undefined output. Query was:", input.query);
        return { items: [] };
      }
      
      // Validate the structure of the output
      if (Array.isArray(output.items)) {
        // Further ensure each item has at least a title or some identifier if possible
        const validItems = output.items.filter(item => item && (item.title || item.isbn13));
        if (validItems.length < output.items.length) {
          console.warn(`[SEARCH BOOKS FLOW] Some items returned by AI were filtered out due to missing essential data or being null. Original count: ${output.items.length}, Valid count: ${validItems.length}. Original items:`, JSON.stringify(output.items));
        }
         console.log(`[SEARCH BOOKS FLOW] AI prompt successfully returned ${validItems.length} valid items for query: "${input.query}". Items:`, JSON.stringify(validItems, null, 2));
        return { items: validItems };
      }
      
      // If output.items is not an array, or some other structural issue
      console.warn("[SEARCH BOOKS FLOW] AI prompt did not return a valid output structure with an 'items' array. Output received:", JSON.stringify(output, null, 2), "Query was:", input.query);
      return { items: [] }; // Return an empty array if the structure is not correct
    } catch (error) {
      console.error("[SEARCH BOOKS FLOW] Error during AI book search flow for query:", input.query, "Error:", error);
      // Return an empty array in case of error to maintain schema compliance
      return { items: [] };
    }
  }
);
