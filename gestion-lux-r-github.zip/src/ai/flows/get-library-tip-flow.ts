
'use server';
/**
 * @fileOverview Un flow Genkit pour générer un conseil de gestion de bibliothèque.
 *
 * - getLibraryTip - Fonction principale pour obtenir un conseil de l'IA.
 * - LibraryTipInput - Type d'entrée (importé).
 * - LibraryTipOutput - Type de sortie (importé).
 */

import {ai} from '@/ai/genkit';
import {
  LibraryTipInputSchema,
  LibraryTipOutputSchema,
  type LibraryTipInput,
  type LibraryTipOutput,
} from '@/ai/schemas/library-tip-schemas';

// Fonction à appeler depuis le client
export async function getLibraryTip(input?: LibraryTipInput): Promise<LibraryTipOutput> {
  console.log("[GET LIBRARY TIP FUNCTION] Appel du libraryTipFlow avec input:", input || {});
  return libraryTipFlow(input || {});
}

// Définition du prompt pour l'IA
const libraryTipPrompt = ai.definePrompt({
  name: 'libraryTipPrompt',
  input: { schema: LibraryTipInputSchema },
  output: { schema: LibraryTipOutputSchema },
  prompt: `Donne-moi un conseil de gestion de bibliothèque. Le conseil doit être une seule phrase.`,
});

// Le Flow Genkit
const libraryTipFlow = ai.defineFlow(
  {
    name: 'libraryTipFlow',
    inputSchema: LibraryTipInputSchema,
    outputSchema: LibraryTipOutputSchema,
  },
  async (input) => {
    console.log(`[LIBRARY TIP FLOW] Début du flow. Input:`, input);

    try {
      console.log(`[LIBRARY TIP FLOW] Appel de libraryTipPrompt...`);
      const { output } = await libraryTipPrompt(input);
      console.log(`[LIBRARY TIP FLOW] Output brut de libraryTipPrompt:`, JSON.stringify(output, null, 2));
      
      if (output && output.tip && typeof output.tip === 'string' && output.tip.trim() !== '') {
        console.log(`[LIBRARY TIP FLOW] Conseil généré par l'IA: "${output.tip}"`);
        return { tip: output.tip };
      }
      
      console.warn("[LIBRARY TIP FLOW] L'IA n'a pas retourné un conseil valide ou un conseil vide. Output reçu:", JSON.stringify(output, null, 2));
      return { tip: "Pensez à organiser régulièrement des événements pour dynamiser votre bibliothèque et attirer de nouveaux lecteurs." }; // Conseil par défaut
    } catch (error) {
      console.error("[LIBRARY TIP FLOW] Erreur lors de la génération du conseil par l'IA:", error);
      return { tip: "Une erreur est survenue lors de la tentative de génération du conseil. Veuillez vérifier la configuration." };
    }
  }
);
