
'use server';
/**
 * @fileOverview Un flow Genkit pour générer un résumé de l'activité de la bibliothèque en utilisant une IA.
 *
 * - summarizeLibraryActivity - Fonction principale pour obtenir un résumé de l'IA.
 * - LibrarySummaryInput - Type d'entrée (importé).
 * - LibrarySummaryOutput - Type de sortie (importé).
 */

import {ai} from '@/ai/genkit';
import {
  LibrarySummaryInputSchema,
  LibrarySummaryOutputSchema,
  type LibrarySummaryInput,
  type LibrarySummaryOutput,
} from '@/ai/schemas/library-summary-schemas';

// Fonction à appeler depuis le client
export async function summarizeLibraryActivity(input: LibrarySummaryInput): Promise<LibrarySummaryOutput> {
  return librarySummaryFlow(input);
}

// Définition du prompt pour l'IA
const librarySummaryPrompt = ai.definePrompt({
  name: 'librarySummaryPrompt',
  input: { schema: LibrarySummaryInputSchema },
  output: { schema: LibrarySummaryOutputSchema },
  prompt: `Tu es un assistant IA expert en gestion de bibliothèque.
L'utilisateur va te poser une question ou te demander un résumé concernant l'activité de la bibliothèque.
Actuellement, tu n'as pas accès aux données réelles et en temps réel de la bibliothèque (livres, lecteurs, emprunts).
Ta tâche est de générer un résumé textuel plausible et informatif basé sur la requête de l'utilisateur et une compréhension générale du fonctionnement d'une bibliothèque.
Essaie d'inclure des aspects typiques comme : une estimation du nombre de livres, le type de livres populaires, l'activité des lecteurs, les emprunts récents, ou des suggestions d'amélioration.
Sois créatif mais garde un ton professionnel.

Requête de l'utilisateur : {{{query}}}

Génère un résumé pertinent et utile.
`,
});

// Le Flow Genkit
const librarySummaryFlow = ai.defineFlow(
  {
    name: 'librarySummaryFlow',
    inputSchema: LibrarySummaryInputSchema,
    outputSchema: LibrarySummaryOutputSchema,
  },
  async (input) => {
    console.log(`[LIBRARY SUMMARY FLOW] Demande de résumé IA pour la requête : "${input.query}"`);

    try {
      const { output } = await librarySummaryPrompt(input);
      
      if (output && typeof output.summary === 'string') {
        console.log(`[LIBRARY SUMMARY FLOW] Résumé généré par l'IA.`);
        return { summary: output.summary };
      }
      
      console.warn("[LIBRARY SUMMARY FLOW] L'IA n'a pas retourné un résumé valide. Output reçu:", JSON.stringify(output, null, 2));
      return { summary: "Désolé, je n'ai pas pu générer de résumé pour le moment. Veuillez réessayer." };
    } catch (error) {
      console.error("[LIBRARY SUMMARY FLOW] Erreur lors de la génération du résumé par l'IA:", error);
      return { summary: "Une erreur est survenue lors de la tentative de génération du résumé. Veuillez réessayer." };
    }
  }
);
